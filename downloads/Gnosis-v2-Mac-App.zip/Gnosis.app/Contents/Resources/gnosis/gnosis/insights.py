"""Local insights: counts, recurring topics, and an on-demand reflection."""
from __future__ import annotations

import re
import time
from collections import Counter
from datetime import datetime, timedelta

from .llm.ollama import OllamaError
from .memory.retrieval import STOP

_EXTRA_STOP = set("""like really think want need make going made one two get using use used also
still much many well way thing things something anything lot good new""".split())


def compute(ctx) -> dict:
    db = ctx.db
    now = time.time()
    counts = ctx.memory.counts()
    convs = db.scalar("SELECT COUNT(*) FROM conversations", default=0)
    msgs = db.scalar("SELECT COUNT(*) FROM messages", default=0)
    # activity: memories + user messages per day, last 28 days
    since = now - 28 * 86400
    days = {}
    for i in range(28):
        d = (datetime.now() - timedelta(days=27 - i)).strftime("%Y-%m-%d")
        days[d] = 0
    for r in db.query("SELECT created FROM memories WHERE created>?", (since,)):
        days[datetime.fromtimestamp(r[0]).strftime("%Y-%m-%d")] = \
            days.get(datetime.fromtimestamp(r[0]).strftime("%Y-%m-%d"), 0) + 1
    for r in db.query("SELECT created FROM messages WHERE role='user' AND created>?", (since,)):
        k = datetime.fromtimestamp(r[0]).strftime("%Y-%m-%d")
        days[k] = days.get(k, 0) + 1
    # recurring topics from the user's own words
    words = Counter()
    for r in db.query("SELECT content FROM messages WHERE role='user' ORDER BY id DESC LIMIT 400"):
        words.update(_terms(r[0]))
    for r in db.query("SELECT title, content FROM memories WHERE kind='note' "
                      "ORDER BY id DESC LIMIT 300"):
        words.update(_terms(r[0] + " " + r[1][:600]))
    topics = [{"term": w, "count": c} for w, c in words.most_common(24) if c >= 2][:14]
    recent = [{"id": r["id"], "title": r["title"], "kind": r["kind"], "updated": r["updated"]}
              for r in db.query("SELECT id, title, kind, updated FROM memories "
                                "ORDER BY updated DESC LIMIT 6")]
    cloud = db.query("SELECT ts, detail FROM audit WHERE kind='cloud_send' ORDER BY id DESC LIMIT 20")
    return {"memories": counts, "conversations": convs, "messages": msgs,
            "activity": [{"day": k, "n": v} for k, v in days.items()],
            "topics": topics, "recent": recent,
            "privacy": {"cloud_sends": db.scalar(
                "SELECT COUNT(*) FROM audit WHERE kind='cloud_send'", default=0),
                "last_cloud_send": cloud[0]["ts"] if cloud else None},
            "index": ctx.indexer.progress()}


def _terms(text):
    for w in re.findall(r"[A-Za-z][A-Za-z'\-]{3,}", (text or "").lower()):
        if w not in STOP and w not in _EXTRA_STOP:
            yield w


def reflect(ctx) -> str:
    """Ask the local model for themes, open loops and suggestions."""
    db = ctx.db
    notes = [f"- {r['title']}: {r['content'][:300]}" for r in db.query(
        "SELECT title, content FROM memories WHERE kind='note' ORDER BY updated DESC LIMIT 25")]
    said = [f"- {r['content'][:240]}" for r in db.query(
        "SELECT content FROM messages WHERE role='user' ORDER BY id DESC LIMIT 25")]
    if len(notes) + len(said) < 3:
        return ("There isn't enough to reflect on yet. Chat with Gnosis and add a few "
                "memories, then try again.")
    name = ctx.settings.get("profile").get("name") or "the user"
    prompt = (f"You are Gnosis, {name}'s private assistant. Below are {name}'s recent notes and "
              "messages. Write a brief reflection with three short sections:\n"
              "**Themes** — what keeps coming up.\n**Open loops** — things they said they need "
              "to do, decide or follow up on.\n**Worth a thought** — one or two perceptive, "
              "kind suggestions.\nBe specific, quote their own words where useful, and don't invent "
              "anything.\n\nNOTES\n" + "\n".join(notes) + "\n\nRECENT MESSAGES\n" + "\n".join(said))
    models = ctx.settings.get("models")
    try:
        return ctx.ollama.chat([{"role": "user", "content": prompt}], models["chat"],
                               options={"temperature": 0.3, "num_ctx": min(models["num_ctx"], 8192)},
                               timeout=300).strip()
    except OllamaError as e:
        raise
