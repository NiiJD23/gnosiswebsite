"""Where Gnosis keeps its data.

The data directory lives in the operating system's per-user application-data
location, deliberately *outside* Documents/OneDrive/iCloud folders: cloud-sync
clients lock and corrupt live SQLite files.  Override with GNOSIS_HOME.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path


def default_home() -> Path:
    env = os.environ.get("GNOSIS_HOME")
    if env:
        return Path(env).expanduser()
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / "Gnosis"
    if sys.platform.startswith("win"):
        base = os.environ.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local")
        return Path(base) / "Gnosis"
    base = os.environ.get("XDG_DATA_HOME") or str(Path.home() / ".local" / "share")
    return Path(base) / "gnosis"


class Paths:
    def __init__(self, home: str | os.PathLike | None = None):
        self.home = Path(home).expanduser() if home else default_home()
        self.uploads = self.home / "uploads"
        self.backups = self.home / "backups"
        self.db = self.home / "gnosis.db"
        for d in (self.home, self.uploads, self.backups):
            d.mkdir(parents=True, exist_ok=True)
        try:
            os.chmod(self.home, 0o700)
        except OSError:
            pass
