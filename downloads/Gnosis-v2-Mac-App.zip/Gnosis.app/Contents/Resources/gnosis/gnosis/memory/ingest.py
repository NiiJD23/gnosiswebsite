"""Turn any uploaded file into searchable text (documents, images, audio…).

Every extractor is lazily imported so a missing optional library only affects
that one file type, with a clear message.
"""
from __future__ import annotations

import json
import mimetypes
import re
from pathlib import Path

MAX_CHARS = 2_000_000


class IngestError(Exception):
    pass


TEXT_EXT = {".txt", ".md", ".markdown", ".csv", ".tsv", ".log", ".yaml", ".yml", ".ini",
            ".toml", ".xml", ".py", ".js", ".ts", ".tsx", ".jsx", ".java", ".c", ".cpp",
            ".h", ".cs", ".go", ".rs", ".rb", ".php", ".sh", ".sql", ".tex", ".bib",
            ".css", ".srt", ".vtt", ".ics", ".vcf", ".eml", ".rst", ".org", ".conf"}
IMAGE_EXT = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tif", ".tiff", ".webp", ".heic"}
AUDIO_EXT = {".mp3", ".wav", ".m4a", ".aac", ".flac", ".ogg", ".opus", ".mp4", ".mov",
             ".webm", ".mkv", ".m4v"}


def guess_mime(name: str) -> str:
    return mimetypes.guess_type(name)[0] or "application/octet-stream"


def _decode(raw: bytes) -> str:
    for enc in ("utf-8-sig", "utf-16") if raw[:2] in (b"\xff\xfe", b"\xfe\xff") else ("utf-8-sig",):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            pass
    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError:
        return raw.decode("cp1252", "replace")


def _need(pkg, extra=""):
    return IngestError(f"Reading this file type needs the “{pkg}” package. "
                       f"Run: pip install {pkg} {extra}".strip())


def _pdf(path: Path) -> str:
    try:
        import pdfplumber
    except ImportError:
        raise _need("pdfplumber")
    parts, empty_pages = [], []
    try:
        with pdfplumber.open(str(path)) as pdf:
            for i, page in enumerate(pdf.pages, 1):
                t = (page.extract_text() or "").strip()
                if len(t) < 25:
                    empty_pages.append((i, page))
                parts.append((i, t))
            if empty_pages:                      # scanned pages → OCR if available
                try:
                    import pytesseract
                    for i, page in empty_pages[:60]:
                        img = page.to_image(resolution=200).original
                        parts[i - 1] = (i, pytesseract.image_to_string(img).strip())
                except Exception:
                    pass
    except Exception as e:
        raise IngestError(f"Couldn’t open this PDF ({e.__class__.__name__}). "
                          "It may be encrypted or damaged.")
    out = [f"[Page {i}]\n{t}" for i, t in parts if t]
    if not out:
        raise IngestError("No readable text found in this PDF (it looks scanned). "
                          "Install OCR support: brew install tesseract, then pip install pytesseract.")
    return "\n\n".join(out)


def _docx(path: Path) -> str:
    try:
        import docx
    except ImportError:
        raise _need("python-docx")
    d = docx.Document(str(path))
    out = []
    for p in d.paragraphs:
        t = p.text.strip()
        if not t:
            continue
        style = (p.style.name or "") if p.style is not None else ""
        if style.lower().startswith("heading"):
            out.append(f"\n# {t}\n")
        elif style.lower() == "title":
            out.append(f"# {t}\n")
        else:
            out.append(t)
    for tbl in d.tables:
        for row in tbl.rows:
            cells = [c.text.strip() for c in row.cells]
            if any(cells):
                out.append(" | ".join(cells))
    return "\n".join(out)


def _pptx(path: Path) -> str:
    try:
        from pptx import Presentation
    except ImportError:
        raise _need("python-pptx")
    out = []
    for i, slide in enumerate(Presentation(str(path)).slides, 1):
        texts = []
        for sh in slide.shapes:
            if sh.has_text_frame:
                texts.append(sh.text_frame.text.strip())
        if slide.has_notes_slide:
            n = slide.notes_slide.notes_text_frame.text.strip()
            if n:
                texts.append("Notes: " + n)
        if any(texts):
            out.append(f"[Slide {i}]\n" + "\n".join(t for t in texts if t))
    return "\n\n".join(out)


def _xlsx(path: Path) -> str:
    try:
        import openpyxl
    except ImportError:
        raise _need("openpyxl")
    wb = openpyxl.load_workbook(str(path), read_only=True, data_only=True)
    out = []
    for ws in wb.worksheets:
        rows = []
        for n, row in enumerate(ws.iter_rows(values_only=True)):
            if n >= 5000:
                rows.append("… (truncated)")
                break
            cells = ["" if v is None else str(v) for v in row]
            if any(cells):
                rows.append(" | ".join(cells))
        if rows:
            out.append(f"[Sheet {ws.title}]\n" + "\n".join(rows))
    return "\n\n".join(out)


def _html(raw: bytes) -> str:
    try:
        from bs4 import BeautifulSoup
    except ImportError:
        raise _need("beautifulsoup4")
    soup = BeautifulSoup(_decode(raw), "html.parser")
    for t in soup(["script", "style", "noscript", "svg"]):
        t.decompose()
    title = soup.title.get_text(strip=True) if soup.title else ""
    text = re.sub(r"\n{3,}", "\n\n", soup.get_text("\n"))
    return (f"# {title}\n\n" if title else "") + text.strip()


def _rtf(raw: bytes) -> str:
    try:
        from striprtf.striprtf import rtf_to_text
    except ImportError:
        raise _need("striprtf")
    return rtf_to_text(_decode(raw))


def _image(path: Path) -> str:
    try:
        import pytesseract
        from PIL import Image
    except ImportError:
        raise IngestError("Reading text from images needs OCR: pip install pytesseract pillow "
                          "and install Tesseract (brew install tesseract / "
                          "winget install UB-Mannheim.TesseractOCR).")
    try:
        text = pytesseract.image_to_string(Image.open(str(path))).strip()
    except pytesseract.TesseractNotFoundError:
        raise IngestError("Tesseract OCR isn’t installed. Mac: brew install tesseract. "
                          "Windows: winget install UB-Mannheim.TesseractOCR.")
    except Exception as e:
        raise IngestError(f"Couldn’t read this image ({e.__class__.__name__}).")
    if not text:
        raise IngestError("No readable text found in this image. It is stored, "
                          "and you can add a description by editing the memory.")
    return text


_whisper = None


def _audio(path: Path) -> str:
    global _whisper
    try:
        from faster_whisper import WhisperModel
    except ImportError:
        raise IngestError("Transcribing audio needs: pip install faster-whisper "
                          "(downloads a small speech model once, then works offline).")
    try:
        if _whisper is None:
            _whisper = WhisperModel("base", compute_type="int8")
        segments, _info = _whisper.transcribe(str(path), vad_filter=True)
        text = " ".join(s.text.strip() for s in segments).strip()
    except Exception as e:
        raise IngestError(f"Couldn’t transcribe this recording ({e.__class__.__name__}: {e}).")
    if not text:
        raise IngestError("No speech was detected in this recording.")
    return text


def extract(path: Path, filename: str) -> str:
    """Return plain text for *path*; raise IngestError with a helpful message."""
    ext = Path(filename).suffix.lower()
    if ext == ".pdf":
        text = _pdf(path)
    elif ext == ".docx":
        text = _docx(path)
    elif ext == ".pptx":
        text = _pptx(path)
    elif ext in (".xlsx", ".xlsm"):
        text = _xlsx(path)
    elif ext in IMAGE_EXT:
        text = _image(path)
    elif ext in AUDIO_EXT:
        text = _audio(path)
    elif ext in (".doc", ".xls", ".ppt"):
        raise IngestError(f"Old Office format ({ext}). Save it as "
                          f"{ext}x (or PDF) and upload again.")
    else:
        raw = path.read_bytes()[:25_000_000]
        if ext in (".html", ".htm", ".xhtml"):
            text = _html(raw)
        elif ext == ".rtf":
            text = _rtf(raw)
        elif ext == ".json":
            s = _decode(raw)
            try:
                text = json.dumps(json.loads(s), indent=2, ensure_ascii=False)
            except ValueError:
                text = s
        elif ext in TEXT_EXT or b"\x00" not in raw[:4096]:
            text = _decode(raw)
        else:
            raise IngestError("This file type can’t be read as text. It is stored safely "
                              "and can be downloaded, but it isn’t searchable.")
    text = re.sub(r"[ \t]+\n", "\n", text).strip()
    if not text:
        raise IngestError("The file contained no readable text.")
    return text[:MAX_CHARS]
