"""Hybrid retrieval: BM25 (SQLite FTS5) + vector similarity, fused with
Reciprocal Rank Fusion.  Degrades gracefully to keyword-only."""
from __future__ import annotations

import re
import threading
import time

import numpy as np

from ..llm.ollama import OllamaError
from .indexer import query_prefix

STOP = set("""a an and are as at be but by do does did for from had has have he her his how i if in
into is it its me my of on or our she so than that the their them then there these they this to
too us was we were what when where which who whom why will with you your about can could would
should just please tell give show let know get got also any some more most very been being am
hey hi hello thanks thank ok okay yes no not don dont""".split())

RRF_K = 60


def tokens(q: str):
    out, seen = [], set()
    for t in re.findall(r"[\w']+", (q or "").lower()):
        t = t.strip("'")
        if len(t) > 1 and t not in STOP and t not in seen:
            seen.add(t)
            out.append(t)
    return out[:14]


class Retriever:
    def __init__(self, db, ollama, settings):
        self.db, self.ollama, self.settings = db, ollama, settings
        self._cache = None          # (epoch, model, ids, matrix)
        self._lock = threading.Lock()
        self._embed_down_until = 0.0
        self.last_mode = "keyword"

    # -- keyword -------------------------------------------------------------
    def _fts(self, toks, limit=30, conv_exclude=None):
        if not toks:
            return []
        if self.db.has_fts:
            q = " OR ".join('"' + t.replace('"', "") + '"' for t in toks)
            sql = ("SELECT c.id FROM chunks_fts f JOIN chunks c ON c.id=f.rowid "
                   "WHERE chunks_fts MATCH ? ")
            args = [q]
            if conv_exclude:
                sql += "AND (c.conv_id IS NULL OR c.conv_id != ?) "
                args.append(conv_exclude)
            sql += "ORDER BY bm25(chunks_fts, 1.0, 0.4) LIMIT ?"
            args.append(limit)
            try:
                return [r["id"] for r in self.db.query(sql, args)]
            except Exception:
                return []
        # Fallback without FTS5: crude term-overlap scoring.
        scored = []
        for r in self.db.query("SELECT id, conv_id, text, header FROM chunks"):
            if conv_exclude and r["conv_id"] == conv_exclude:
                continue
            blob = (r["header"] + " " + r["text"]).lower()
            s = sum(blob.count(t) for t in toks)
            if s:
                scored.append((s, r["id"]))
        scored.sort(reverse=True)
        return [i for _, i in scored[:limit]]

    # -- vectors -------------------------------------------------------------
    def _matrix(self, model):
        epoch = self.db.epoch
        c = self._cache
        if c and c[0] == epoch and c[1] == model:
            return c[2], c[3]
        with self._lock:
            rows = self.db.query("SELECT id, emb FROM chunks WHERE emb IS NOT NULL AND emb_model=?",
                                 (model,))
            if not rows:
                self._cache = (epoch, model, [], None)
                return [], None
            dim = len(rows[0]["emb"]) // 4
            ok = [r for r in rows if len(r["emb"]) == dim * 4]
            mat = np.frombuffer(b"".join(r["emb"] for r in ok), dtype=np.float32).reshape(len(ok), dim)
            self._cache = (epoch, model, [r["id"] for r in ok], mat)
            return self._cache[2], self._cache[3]

    def _vector(self, query, limit=30, conv_exclude=None):
        model = self.settings.get("models")["embed"]
        if time.time() < self._embed_down_until:
            return []
        ids, mat = self._matrix(model)
        if mat is None or not len(ids):
            return []
        try:
            qv = self.ollama.embed([query_prefix(model) + query], model, timeout=20)[0]
        except OllamaError:
            self._embed_down_until = time.time() + 45
            return []
        q = np.asarray(qv, dtype=np.float32)
        if q.shape[0] != mat.shape[1]:
            return []
        q /= (np.linalg.norm(q) or 1.0)
        sims = mat @ q
        order = np.argsort(-sims)[: limit * 2]
        top = float(sims[order[0]])
        floor = max(0.30, top - 0.22)
        out = []
        for i in order:
            if float(sims[i]) < floor:
                break
            out.append(ids[int(i)])
        if conv_exclude and out:
            bad = {r["id"] for r in self.db.query(
                f"SELECT id FROM chunks WHERE conv_id=? AND id IN ({','.join('?' * len(out))})",
                [conv_exclude, *out])}
            out = [i for i in out if i not in bad]
        return out[:limit]

    # -- public --------------------------------------------------------------
    def search(self, query: str, k=8, per_source=3, conv_exclude=None, use_vectors=True):
        toks = tokens(query)
        words = len(re.findall(r"\w+", query or ""))
        if not toks and words < 3:
            return []
        kw = self._fts(toks, conv_exclude=conv_exclude)
        vec = self._vector(query, conv_exclude=conv_exclude) if (use_vectors and words >= 2) else []
        self.last_mode = "hybrid" if vec else "keyword"
        score: dict[int, float] = {}
        for lst in (kw, vec):
            for rank, cid in enumerate(lst):
                score[cid] = score.get(cid, 0.0) + 1.0 / (RRF_K + rank + 1)
        if not score:
            return []
        ids = sorted(score, key=score.get, reverse=True)[: k * 4]
        rows = {r["id"]: r for r in self.db.query(
            f"SELECT c.*, m.title mtitle, m.kind mkind, m.updated mupdated, "
            f"v.title ctitle, v.updated cupdated FROM chunks c "
            f"LEFT JOIN memories m ON c.ref_type='memory' AND m.id=c.ref_id "
            f"LEFT JOIN conversations v ON c.ref_type='message' AND v.id=c.conv_id "
            f"WHERE c.id IN ({','.join('?' * len(ids))})", ids)}
        hits, per = [], {}
        for cid in ids:
            r = rows.get(cid)
            if not r:
                continue
            key = (r["ref_type"], r["ref_id"])
            if per.get(key, 0) >= per_source:
                continue
            per[key] = per.get(key, 0) + 1
            is_mem = r["ref_type"] == "memory"
            hits.append({
                "chunk_id": cid, "ref_type": r["ref_type"], "ref_id": r["ref_id"],
                "conv_id": r["conv_id"], "kind": r["mkind"] if is_mem else "chat",
                "title": (r["mtitle"] if is_mem else r["ctitle"]) or "Untitled",
                "header": r["header"], "text": r["text"], "score": score[cid],
                "date": (r["mupdated"] if is_mem else r["cupdated"]),
            })
            if len(hits) >= k:
                break
        return hits
