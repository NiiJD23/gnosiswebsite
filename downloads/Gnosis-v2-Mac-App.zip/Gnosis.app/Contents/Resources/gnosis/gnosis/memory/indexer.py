"""Background embedding worker.

Saving is never blocked on embeddings: text is searchable by keyword at once,
and this thread fills in vectors whenever Ollama and the embedding model are
available — incrementally, only for chunks that lack a vector for the current
embedding model."""
from __future__ import annotations

import threading
import time

import numpy as np

from ..llm.ollama import OllamaError

BATCH = 16


def doc_prefix(model: str) -> str:
    return "search_document: " if model.lower().startswith("nomic") else ""


def query_prefix(model: str) -> str:
    return "search_query: " if model.lower().startswith("nomic") else ""


def pack(vec) -> bytes:
    a = np.asarray(vec, dtype=np.float32)
    n = float(np.linalg.norm(a)) or 1.0
    return (a / n).tobytes()


class Indexer:
    def __init__(self, db, ollama, settings):
        self.db, self.ollama, self.settings = db, ollama, settings
        self._ev = threading.Event()
        self._stop = False
        self._retry_at = 0.0
        self.last_error = ""
        self.busy = False
        self._t = threading.Thread(target=self._run, name="gnosis-indexer", daemon=True)

    def start(self):
        if not self._t.is_alive():
            self._t.start()
        return self

    def stop(self):
        self._stop = True
        self._ev.set()

    def kick(self, force=False):
        if force or self._retry_at - time.time() < 5:
            self._retry_at = 0.0
        self._ev.set()

    def model(self) -> str:
        return self.settings.get("models")["embed"]

    def progress(self) -> dict:
        m = self.model()
        total = self.db.scalar("SELECT COUNT(*) FROM chunks", default=0)
        done = self.db.scalar("SELECT COUNT(*) FROM chunks WHERE emb IS NOT NULL AND emb_model=?",
                              (m,), default=0)
        return {"total": total, "embedded": done, "pending": total - done,
                "busy": self.busy, "error": self.last_error, "model": m}

    def run_once(self) -> int:
        """Embed one batch; returns how many chunks were processed."""
        m = self.model()
        rows = self.db.query(
            "SELECT id, header, text FROM chunks WHERE emb IS NULL OR emb_model IS NOT ? "
            "ORDER BY id LIMIT ?", (m, BATCH))
        if not rows:
            return 0
        pre = doc_prefix(m)
        texts = [pre + ((r["header"] + "\n") if r["header"] else "") + r["text"] for r in rows]
        vecs = self.ollama.embed(texts, m)
        if len(vecs) != len(rows):
            raise OllamaError("Embedding service returned an unexpected result.")
        with self.db.tx():
            self.db.conn().executemany(
                "UPDATE chunks SET emb=?, emb_model=? WHERE id=?",
                [(pack(v), m, r["id"]) for v, r in zip(vecs, rows)])
        self.db.bump()
        return len(rows)

    def _run(self):
        while not self._stop:
            self._ev.wait(timeout=30)
            self._ev.clear()
            if self._stop:
                return
            if time.time() < self._retry_at:
                continue
            self.busy = True
            try:
                while not self._stop and self.run_once():
                    pass
                self.last_error = ""
            except OllamaError as e:
                self.last_error = e.message
                self._retry_at = time.time() + 60      # back off; keyword search still works
            except Exception as e:                      # pragma: no cover
                self.last_error = f"{e.__class__.__name__}: {e}"
                self._retry_at = time.time() + 60
            finally:
                self.busy = False
