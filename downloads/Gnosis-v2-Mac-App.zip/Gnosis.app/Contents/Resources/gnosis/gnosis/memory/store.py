"""Memory CRUD: notes, files, links.  Search text is chunked at save time so
retrieval works immediately; embeddings are filled in later by the indexer."""
from __future__ import annotations

import ipaddress
import os
import re
import socket
import time
import urllib.error
import urllib.request
import uuid
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlparse

from . import ingest
from .chunker import chunk_text

MAX_UPLOAD = 200 * 1024 * 1024


def _norm(s: str) -> str:
    return re.sub(r"\W+", " ", (s or "").lower()).strip()


def auto_title(text: str, n=64) -> str:
    first = re.sub(r"\s+", " ", (text or "").strip().split("\n", 1)[0]).strip(" -•*#>")
    if len(first) <= n:
        return first or "Untitled"
    cut = first[:n].rsplit(" ", 1)[0]
    return (cut or first[:n]) + "…"


class MemoryStore:
    def __init__(self, db, paths, indexer=None):
        self.db, self.paths, self.indexer = db, paths, indexer
        self._pool = ThreadPoolExecutor(max_workers=2, thread_name_prefix="gnosis-ingest")

    # -- serialisation -----------------------------------------------------
    @staticmethod
    def _row(r, full=False, snippet=220):
        d = {k: r[k] for k in ("id", "kind", "title", "filename", "mime", "size", "url",
                               "tags", "pinned", "status", "error", "origin",
                               "created", "updated")}
        d["pinned"] = bool(d["pinned"])
        d["tags"] = [t for t in (d["tags"] or "").split(",") if t]
        content = r["content"] or ""
        d["chars"] = len(content)
        d["snippet"] = re.sub(r"\s+", " ", content[:snippet * 2]).strip()[:snippet]
        d["downloadable"] = bool(r["stored_as"])
        if full:
            d["content"] = content
        return d

    def _kick(self):
        self.db.bump()
        if self.indexer:
            self.indexer.kick()

    # -- chunks ------------------------------------------------------------
    def _rechunk(self, mid: int, title: str, content: str):
        with self.db.tx():
            self.db.execute("DELETE FROM chunks WHERE ref_type='memory' AND ref_id=?", (mid,))
            head_title = title or ""
            rows = [("memory", mid, None, i, h, t)
                    for i, (h, t) in enumerate(chunk_text(head_title, content))]
            if rows:
                self.db.conn().executemany(
                    "INSERT INTO chunks(ref_type, ref_id, conv_id, idx, header, text) "
                    "VALUES (?,?,?,?,?,?)", rows)
        self._kick()

    # -- create ------------------------------------------------------------
    def add_note(self, content: str, title: str = "", tags=None, origin="user",
                 pinned=False, dedupe=True):
        content = (content or "").strip()
        if not content:
            raise ValueError("Write something to remember first.")
        if dedupe:
            key = _norm(content)
            for r in self.db.query("SELECT id, content FROM memories WHERE kind='note' "
                                   "ORDER BY id DESC LIMIT 400"):
                if _norm(r["content"]) == key:
                    return self.get(r["id"]), False
        now = time.time()
        title = (title or "").strip() or auto_title(content)
        cur = self.db.execute(
            "INSERT INTO memories(kind,title,content,tags,pinned,origin,status,created,updated,size) "
            "VALUES ('note',?,?,?,?,?,'ready',?,?,?)",
            (title, content, ",".join(tags or []), int(pinned), origin, now, now, len(content)))
        mid = cur.lastrowid
        self._rechunk(mid, title, content)
        return self.get(mid), True

    def add_link(self, url: str, title: str = "", note: str = "", fetch=False):
        url = (url or "").strip()
        if "://" not in url and re.match(r"^[A-Za-z][A-Za-z0-9+.\-]*:(?!\d+(?:/|$))", url):
            raise ValueError("Only http and https web addresses can be saved.")
        try:
            p = urlparse(url if "://" in url else "https://" + url)
            _ = p.port
        except ValueError:
            raise ValueError("That doesn’t look like a web address.")
        if p.scheme not in ("http", "https") or not p.hostname or " " in url:
            raise ValueError("That doesn’t look like a web address.")
        url = p.geturl()
        now = time.time()
        title = (title or "").strip() or p.hostname + (p.path if p.path != "/" else "")
        content = (note or "").strip()
        cur = self.db.execute(
            "INSERT INTO memories(kind,title,content,url,origin,status,created,updated,size) "
            "VALUES ('link',?,?,?,'user','ready',?,?,?)",
            (title, content or url, url, now, now, len(content)))
        mid = cur.lastrowid
        self._rechunk(mid, title, (content + "\n" + url).strip())
        if fetch:
            self._pool.submit(self._fetch_job, mid)
        return self.get(mid)

    def add_file(self, stream, filename: str):
        """Persist an uploaded file and queue text extraction."""
        filename = os.path.basename(filename or "upload").strip() or "upload"
        ext = re.sub(r"[^.\w]", "", os.path.splitext(filename)[1].lower())[:12]
        stored = uuid.uuid4().hex + ext
        dest = self.paths.uploads / stored
        size = 0
        with open(dest, "wb") as f:
            while True:
                buf = stream.read(1024 * 1024)
                if not buf:
                    break
                size += len(buf)
                if size > MAX_UPLOAD:
                    f.close()
                    dest.unlink(missing_ok=True)
                    raise ValueError("That file is larger than 200 MB.")
                f.write(buf)
        now = time.time()
        cur = self.db.execute(
            "INSERT INTO memories(kind,title,filename,stored_as,mime,size,origin,status,created,updated) "
            "VALUES ('file',?,?,?,?,?,'user','processing',?,?)",
            (filename, filename, stored, ingest.guess_mime(filename), size, now, now))
        mid = cur.lastrowid
        self._pool.submit(self._process_job, mid)
        return self.get(mid)

    # -- background jobs ---------------------------------------------------
    def _process_job(self, mid: int):
        r = self.db.one("SELECT * FROM memories WHERE id=?", (mid,))
        if not r or not r["stored_as"]:
            return
        path = self.paths.uploads / r["stored_as"]
        try:
            text = ingest.extract(path, r["filename"])
            self.db.execute("UPDATE memories SET content=?, status='ready', error=NULL, "
                            "updated=? WHERE id=?", (text, time.time(), mid))
            self._rechunk(mid, r["title"], text)
        except ingest.IngestError as e:
            self._fail(mid, r, str(e))
        except Exception as e:                     # never let a worker die silently
            self._fail(mid, r, f"Unexpected error while reading this file: {e.__class__.__name__}")

    def _fail(self, mid, r, msg):
        self.db.execute("UPDATE memories SET status='failed', error=?, updated=? WHERE id=?",
                        (msg, time.time(), mid))
        # keep the filename searchable even when text extraction failed
        self._rechunk(mid, r["title"], r["filename"] or r["title"])

    def reprocess(self, mid: int):
        self.db.execute("UPDATE memories SET status='processing', error=NULL WHERE id=?", (mid,))
        self._pool.submit(self._process_job, mid)
        return self.get(mid)

    def wait_idle(self, timeout=30):
        """Test helper: wait until no memory is 'processing'."""
        end = time.time() + timeout
        while time.time() < end:
            if not self.db.scalar("SELECT COUNT(*) FROM memories WHERE status='processing'", default=0):
                return True
            time.sleep(0.05)
        return False

    # -- link fetching (user-initiated; blocks private networks) ------------
    @staticmethod
    def _public_host(host: str):
        for info in socket.getaddrinfo(host, None):
            ip = ipaddress.ip_address(info[4][0])
            if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved \
                    or ip.is_multicast:
                raise ValueError("That address points to a private network, so it was not fetched.")

    def _fetch_job(self, mid: int):
        r = self.db.one("SELECT * FROM memories WHERE id=?", (mid,))
        if not r or not r["url"]:
            return
        try:
            self._public_host(urlparse(r["url"]).hostname)
            req = urllib.request.Request(r["url"], headers={"User-Agent": "Gnosis/2 (personal assistant)"})
            with urllib.request.urlopen(req, timeout=20) as resp:
                ctype = resp.headers.get("Content-Type", "")
                raw = resp.read(3_000_000)
            if "html" in ctype or raw[:200].lstrip().lower().startswith((b"<!doctype", b"<html")):
                text = ingest._html(raw)
            else:
                text = ingest._decode(raw)
            keep = (r["content"] if r["content"] and r["content"] != r["url"] else "")
            text = (keep + "\n\n" + text).strip()[:300_000]
            self.db.execute("UPDATE memories SET content=?, error=NULL, updated=?, size=? WHERE id=?",
                            (text, time.time(), len(text), mid))
            self._rechunk(mid, r["title"], text + "\n" + r["url"])
        except Exception as e:
            msg = str(e) if isinstance(e, ValueError) else f"Couldn’t fetch the page ({e.__class__.__name__})."
            self.db.execute("UPDATE memories SET error=?, updated=? WHERE id=?", (msg, time.time(), mid))

    def fetch_link(self, mid: int):
        r = self.db.one("SELECT kind FROM memories WHERE id=?", (mid,))
        if not r or r["kind"] != "link":
            raise KeyError(mid)
        self._pool.submit(self._fetch_job, mid)
        return self.get(mid)

    # -- read / update / delete ---------------------------------------------
    def get(self, mid: int, full=False):
        r = self.db.one("SELECT * FROM memories WHERE id=?", (mid,))
        return self._row(r, full) if r else None

    def list(self, kind=None, q=None, limit=200, offset=0, status=None):
        sql, args = "SELECT * FROM memories WHERE 1=1", []
        if kind in ("note", "file", "link"):
            sql += " AND kind=?"
            args.append(kind)
        if status:
            sql += " AND status=?"
            args.append(status)
        if q:
            like = "%" + q.replace("%", r"\%").replace("_", r"\_") + "%"
            sql += " AND (title LIKE ? ESCAPE '\\' OR content LIKE ? ESCAPE '\\' OR tags LIKE ? ESCAPE '\\')"
            args += [like, like, like]
        sql += " ORDER BY pinned DESC, updated DESC LIMIT ? OFFSET ?"
        args += [max(1, min(500, limit)), max(0, offset)]
        return [self._row(r) for r in self.db.query(sql, args)]

    def counts(self):
        out = {"note": 0, "file": 0, "link": 0}
        for r in self.db.query("SELECT kind, COUNT(*) n FROM memories GROUP BY kind"):
            out[r["kind"]] = r["n"]
        out["total"] = sum(out.values())
        return out

    def update(self, mid: int, title=None, content=None, tags=None, pinned=None):
        r = self.db.one("SELECT * FROM memories WHERE id=?", (mid,))
        if not r:
            raise KeyError(mid)
        new_title = r["title"] if title is None else (str(title).strip() or r["title"])
        new_content = r["content"] if content is None else str(content)
        if r["kind"] == "note" and not new_content.strip():
            raise ValueError("A note can’t be empty. Delete it instead.")
        new_tags = r["tags"] if tags is None else ",".join(
            t.strip().replace(",", " ") for t in tags if str(t).strip())
        new_pin = r["pinned"] if pinned is None else int(bool(pinned))
        self.db.execute("UPDATE memories SET title=?, content=?, tags=?, pinned=?, updated=?, size=? "
                        "WHERE id=?", (new_title, new_content, new_tags, new_pin,
                                       time.time(), len(new_content), mid))
        if new_title != r["title"] or new_content != r["content"]:
            self._rechunk(mid, new_title, new_content)
        return self.get(mid)

    def delete(self, mid: int) -> bool:
        r = self.db.one("SELECT stored_as FROM memories WHERE id=?", (mid,))
        if not r:
            return False
        with self.db.tx():
            self.db.execute("DELETE FROM chunks WHERE ref_type='memory' AND ref_id=?", (mid,))
            self.db.execute("DELETE FROM memories WHERE id=?", (mid,))
        if r["stored_as"]:
            (self.paths.uploads / os.path.basename(r["stored_as"])).unlink(missing_ok=True)
        self.db.bump()
        return True

    def file_path(self, mid: int):
        r = self.db.one("SELECT stored_as, filename, mime, kind, title, content FROM memories WHERE id=?", (mid,))
        if not r:
            return None
        if r["stored_as"]:
            p = self.paths.uploads / os.path.basename(r["stored_as"])
            if p.exists():
                return {"path": p, "name": r["filename"] or r["title"], "mime": r["mime"]}
        return None

    def pinned_context(self, max_chars=1200):
        out, used = [], 0
        for r in self.db.query("SELECT title, content FROM memories WHERE pinned=1 "
                               "AND status='ready' ORDER BY updated DESC"):
            t = (r["content"] or "").strip()
            if not t:
                continue
            if used + len(t) > max_chars:
                t = t[:max(0, max_chars - used)]
            if not t:
                break
            out.append((r["title"], t))
            used += len(t)
        return out
