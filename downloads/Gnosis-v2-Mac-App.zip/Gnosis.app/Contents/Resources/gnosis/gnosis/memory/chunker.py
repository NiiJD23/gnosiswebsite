"""Split text into overlapping, context-labelled chunks for retrieval."""
from __future__ import annotations

import re

TARGET = 900
MAX = 1300
OVERLAP = 140

_MARK = re.compile(r"^\[(Page|Slide|Sheet) ([^\]]+)\]$")
_HEAD = re.compile(r"^#{1,6}\s+(.+?)\s*$")
_SENT = re.compile(r"(?<=[.!?])\s+(?=[A-Z0-9“\"'(])")


def _pieces(text: str):
    """Yield (kind, text) where kind is 'mark' | 'head' | 'body'."""
    for block in re.split(r"\n\s*\n", text.replace("\r\n", "\n")):
        block = block.strip()
        if not block:
            continue
        lines = block.split("\n")
        body = []
        for ln in lines:
            s = ln.strip()
            m, h = _MARK.match(s), _HEAD.match(s)
            if m or h:
                if body:
                    yield "body", "\n".join(body)
                    body = []
                if m:
                    yield "mark", f"{m.group(1)} {m.group(2)}"
                else:
                    yield "head", h.group(1)
                    body.append(s)  # keep the heading text inside the chunk too
            else:
                body.append(ln)
        if body:
            yield "body", "\n".join(body)


def _split_long(p: str):
    if len(p) <= MAX:
        return [p]
    out, cur = [], ""
    for s in _SENT.split(p):
        while len(s) > MAX:               # no sentence boundary: hard split on spaces
            cut = s.rfind(" ", 0, TARGET)
            cut = cut if cut > 200 else TARGET
            if cur:
                out.append(cur)
                cur = ""
            out.append(s[:cut])
            s = s[cut:].lstrip()
        if len(cur) + len(s) + 1 > TARGET and cur:
            out.append(cur)
            cur = s
        else:
            cur = (cur + " " + s).strip()
    if cur:
        out.append(cur)
    return out


def _tail(text: str, n=OVERLAP) -> str:
    if len(text) <= n:
        return ""
    t = text[-n:]
    sp = t.find(" ")
    return t[sp + 1:] if 0 <= sp < n // 2 else t


def chunk_text(title: str, text: str):
    """Return [(header, chunk_text)].  Header = 'Title › section/page'."""
    text = (text or "").strip()
    if not text:
        return []
    title = (title or "").strip()
    section = ""
    chunks: list[tuple[str, str]] = []
    cur, cur_section = "", ""

    def header(sec):
        return f"{title} › {sec}" if title and sec else (title or sec)

    def flush():
        nonlocal cur
        if cur.strip():
            chunks.append((header(cur_section), cur.strip()))
        cur = ""

    for kind, piece in _pieces(text):
        if kind == "mark":
            flush()
            section = piece
            continue
        if kind == "head":
            section = piece if not section.startswith(("Page", "Slide", "Sheet")) \
                else f"{section} · {piece}"
        for part in _split_long(piece):
            if not cur:
                cur_section = section
            if cur and len(cur) + len(part) + 2 > TARGET:
                prev = cur
                flush()
                cur_section = section
                cur = (_tail(prev) + "\n\n" + part).strip() if _tail(prev) else part
            else:
                cur = (cur + "\n\n" + part) if cur else part
    flush()
    return chunks
