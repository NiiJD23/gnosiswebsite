"""Learning from conversation.

Two mechanisms, deliberately different in trust level:
  1. Explicit capture ("remember that …") — deterministic, instant, saved at once.
  2. Suggestions — the model proposes durable facts it noticed; the user
     accepts or dismisses them.  Nothing is silently memorised.
"""
from __future__ import annotations

import json
import re
import time

from ..llm.ollama import OllamaError

_VERB = (r"(?:remember|note(?:\s+down)?|save|store|memori[sz]e|keep\s+in\s+mind|"
         r"don'?t\s+forget|add(?:\s+this)?\s+to\s+(?:my\s+)?(?:memory|notes)|log)")
_PRE = re.compile(
    rf"^\s*(?:(?:hey|ok(?:ay)?|gnosis)[,\s]+)?(?:(?:can|could|would|will)\s+you\s+)?"
    rf"(?:please\s+)?{_VERB}(?:\s+(?:that|this|it))?"
    rf"(?:\s+(?:to|in|into)\s+(?:my\s+)?(?:memory|notes))?\s*[:,\-–]?\s*(?P<fact>.+?)\s*$",
    re.I | re.S)
_POST = re.compile(
    r"^\s*(?P<fact>.{8,}?)[,.;]?\s*(?:please\s+)?(?:remember|save|note)\s+(?:that|this|it)"
    r"(?:\s+(?:to|in)\s+(?:my\s+)?memory)?\s*[.!]?\s*$", re.I | re.S)


def detect_capture(text: str):
    """Return the fact to save if the message is an explicit save request."""
    t = (text or "").strip()
    if not t or t.endswith("?"):
        return None
    m = _PRE.match(t) or _POST.match(t)
    if not m:
        return None
    fact = m.group("fact").strip().strip('"“”')
    if len(fact) < 6 or re.match(r"^(me|to\b)", fact, re.I) and len(fact) < 14:
        return None
    return fact


_PERSONAL = re.compile(
    r"\b(i am|i'm|i was|i have|i've|i had|i work|i live|i moved|i prefer|i like|i love|i hate|"
    r"i want|i need|i plan|i'm planning|i got|i started|i finished|i joined|i graduated|"
    r"my (?:wife|husband|partner|son|daughter|mum|mom|dad|brother|sister|boss|manager|"
    r"team|job|role|company|business|birthday|goal|plan|phd|thesis|supervisor|client|"
    r"house|car|dog|cat|salary|address|email|number|favourite|favorite)|we (?:are|have|moved|"
    r"decided|plan)|our (?:son|daughter|baby|house|team|company))\b", re.I)


def looks_personal(text: str) -> bool:
    t = (text or "").strip()
    return 25 <= len(t) <= 1800 and not t.endswith("?") and bool(_PERSONAL.search(t))


def _jaccard(a: str, b: str) -> float:
    A, B = set(re.findall(r"\w+", a.lower())), set(re.findall(r"\w+", b.lower()))
    return len(A & B) / len(A | B) if A and B else 0.0


_PROMPT = (
    "Extract lasting personal facts about the USER from the message below — things worth "
    "remembering months from now (relationships, roles, goals, preferences, decisions, "
    "dates, projects). Ignore small talk, questions, and anything temporary. Write each fact "
    "as one short third-person sentence starting with the user's name or 'The user'. "
    'Reply ONLY with JSON: {"facts": ["…"]}. If nothing qualifies reply {"facts": []}.\n\n'
    "Message:\n")


def extract_facts(ollama, model, text, name="") -> list[str]:
    msg = _PROMPT + text.strip()[:1800]
    if name:
        msg = msg.replace("the user's name or 'The user'", f"'{name}'")
    try:
        raw = ollama.chat([{"role": "user", "content": msg}], model,
                          options={"temperature": 0, "num_ctx": 4096}, fmt="json", timeout=90)
        data = json.loads(raw)
    except (OllamaError, ValueError):
        return []
    facts = data.get("facts") if isinstance(data, dict) else None
    out = []
    for f in facts or []:
        f = re.sub(r"\s+", " ", str(f)).strip()
        if 12 <= len(f) <= 240:
            out.append(f)
    return out[:4]


class Learner:
    def __init__(self, db, ollama, settings):
        self.db, self.ollama, self.settings = db, ollama, settings

    def _known(self):
        rows = self.db.query("SELECT text FROM suggestions")
        rows2 = self.db.query("SELECT content FROM memories WHERE kind='note' "
                              "ORDER BY id DESC LIMIT 300")
        return [r[0] for r in rows] + [r[0] for r in rows2]

    def suggest_from(self, conv_id: int, text: str) -> int:
        """Run in a background thread after a reply.  Returns suggestions added."""
        if not looks_personal(text):
            return 0
        models = self.settings.get("models")
        name = self.settings.get("profile").get("name", "")
        facts = extract_facts(self.ollama, models["chat"], text, name)
        known, added = self._known(), 0
        for f in facts:
            if any(_jaccard(f, k) >= 0.6 for k in known):
                continue
            self.db.execute("INSERT INTO suggestions(text, conv_id, created) VALUES (?,?,?)",
                            (f, conv_id, time.time()))
            known.append(f)
            added += 1
        return added

    def pending(self):
        return [dict(r) for r in self.db.query(
            "SELECT id, text, conv_id, created FROM suggestions WHERE status='pending' "
            "ORDER BY id DESC LIMIT 50")]
