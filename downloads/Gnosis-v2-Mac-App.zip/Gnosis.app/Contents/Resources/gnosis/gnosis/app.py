"""Flask application: JSON API + static single-page UI, bound to localhost."""
from __future__ import annotations

import json
import os
import time
from pathlib import Path

from flask import Flask, Response, jsonify, request, send_file, stream_with_context
from werkzeug.exceptions import HTTPException

from . import __version__, insights
from .context import Context
from .llm.cloud import CloudError
from .llm.ollama import OllamaError
from .privacy import backup, security

STATIC = Path(__file__).resolve().parent.parent / "static"


def create_app(ctx: Context | None = None, home=None, port=5177) -> Flask:
    ctx = ctx or Context(home)
    app = Flask(__name__, static_folder=str(STATIC), static_url_path="/static")
    app.config["MAX_CONTENT_LENGTH"] = 400 * 1024 * 1024
    app.config["PORT"] = port
    app.config["CTX"] = ctx
    security.install(app, lambda: app.config["PORT"])

    # ------------------------------------------------------------- helpers
    def body() -> dict:
        d = request.get_json(silent=True)
        return d if isinstance(d, dict) else {}

    def err(msg, status=400, **extra):
        return jsonify(error=msg, **extra), status

    @app.errorhandler(OllamaError)
    def _ollama(e):
        return err(e.message, 503, code=e.code, action=e.action)

    @app.errorhandler(CloudError)
    def _cloud(e):
        return err(e.message, 502, code="cloud_error")

    @app.errorhandler(backup.BackupError)
    def _bk(e):
        return err(str(e), 400)

    @app.errorhandler(ValueError)
    def _val(e):
        return err(str(e), 400)

    @app.errorhandler(KeyError)
    def _key(e):
        return err(str(e.args[0]) if e.args and isinstance(e.args[0], str) else "Not found", 404)

    @app.errorhandler(PermissionError)
    def _perm(e):
        return err(str(e), 403, code="not_allowed")

    @app.errorhandler(HTTPException)
    def _http(e):
        return err(e.description or e.name, e.code or 500)

    @app.errorhandler(Exception)
    def _any(e):
        app.logger.exception("Unhandled error")
        return err("Something went wrong inside Gnosis. Details are in the terminal window.", 500)

    # --------------------------------------------------------------- pages
    @app.get("/")
    def index():
        html = (STATIC / "index.html").read_text(encoding="utf-8")
        html = html.replace("__GNOSIS_TOKEN__", app.config["GNOSIS_TOKEN"])
        return Response(html, mimetype="text/html")

    @app.get("/favicon.ico")
    def favicon():
        return send_file(STATIC / "favicon.svg", mimetype="image/svg+xml")

    # -------------------------------------------------------------- status
    @app.get("/api/status")
    def status():
        m = ctx.settings.get("models")
        return jsonify(
            version=__version__,
            ollama=ctx.ollama.status(m["chat"], m["embed"]),
            models=m,
            index=ctx.indexer.progress(),
            search_mode=ctx.retriever.last_mode,
            memories=ctx.memory.counts(),
            suggestions=len(ctx.learner.pending()),
            cloud={"enabled": ctx.settings.get("cloud")["enabled"],
                   "has_key": bool(ctx.secrets.get("anthropic")),
                   "key_hint": ctx.secrets.hint("anthropic"),
                   "key_storage": ctx.secrets.backend},
            home=str(ctx.paths.home))

    # ------------------------------------------------------------ settings
    @app.get("/api/settings")
    def get_settings():
        return jsonify(ctx.settings.all())

    @app.put("/api/settings")
    def put_settings():
        return jsonify(ctx.settings.update(body()))

    @app.put("/api/secrets/cloud-key")
    def set_key():
        key = str(body().get("key", "")).strip()
        if len(key) < 12 or any(c.isspace() for c in key):
            raise ValueError("That doesn’t look like an API key.")
        ctx.secrets.set("anthropic", key)
        return jsonify(ok=True, hint=ctx.secrets.hint("anthropic"), storage=ctx.secrets.backend)

    @app.delete("/api/secrets/cloud-key")
    def del_key():
        ctx.secrets.delete("anthropic")
        return jsonify(ok=True)

    @app.post("/api/models/pull")
    def pull():
        model = str(body().get("model", "")).strip()
        if not model or len(model) > 100:
            raise ValueError("Which model?")

        def gen():
            try:
                for ev in ctx.ollama.pull_stream(model):
                    yield json.dumps(ev) + "\n"
                ctx.indexer.kick(force=True)
                yield json.dumps({"status": "success"}) + "\n"
            except OllamaError as e:
                yield json.dumps({"error": e.message}) + "\n"
        return Response(stream_with_context(gen()), mimetype="application/x-ndjson")

    # -------------------------------------------------------- conversations
    @app.get("/api/conversations")
    def list_convs():
        return jsonify(ctx.convs.list(q=request.args.get("q") or None))

    @app.post("/api/conversations")
    def new_conv():
        return jsonify(ctx.convs.create(str(body().get("title") or "New chat")[:120])), 201

    @app.delete("/api/conversations")
    def delete_all_convs():
        if body().get("confirm") != "DELETE":
            raise ValueError("Confirmation missing.")
        return jsonify(deleted=ctx.convs.delete_all())

    @app.get("/api/conversations/<int:cid>")
    def get_conv(cid):
        c = ctx.convs.get(cid)
        if not c:
            raise KeyError("That chat no longer exists.")
        return jsonify(**c, messages_list=ctx.convs.messages(cid))

    @app.patch("/api/conversations/<int:cid>")
    def patch_conv(cid):
        b = body()
        if not ctx.convs.get(cid):
            raise KeyError("That chat no longer exists.")
        if "title" in b:
            ctx.convs.rename(cid, b["title"])
        if "pinned" in b:
            ctx.convs.pin(cid, b["pinned"])
        return jsonify(ctx.convs.get(cid))

    @app.delete("/api/conversations/<int:cid>")
    def del_conv(cid):
        if not ctx.convs.delete(cid):
            raise KeyError("That chat no longer exists.")
        return jsonify(ok=True)

    @app.post("/api/conversations/<int:cid>/clear")
    def clear_conv(cid):
        if not ctx.convs.get(cid):
            raise KeyError("That chat no longer exists.")
        ctx.convs.clear(cid)
        return jsonify(ok=True)

    # ----------------------------------------------------------------- chat
    @app.post("/api/chat")
    def chat():
        b = body()
        cid = b.get("conv_id")
        cid = int(cid) if isinstance(cid, (int, str)) and str(cid).isdigit() else None

        def gen():
            try:
                for ev in ctx.engine.stream(cid, b.get("text", ""), bool(b.get("regenerate"))):
                    yield json.dumps(ev) + "\n"
            except Exception as e:                     # last line of defence
                app.logger.exception("chat stream failed")
                yield json.dumps({"type": "error", "code": "internal",
                                  "message": f"Something went wrong ({e.__class__.__name__})."}) + "\n"
        return Response(stream_with_context(gen()), mimetype="application/x-ndjson",
                        headers={"X-Accel-Buffering": "no"})

    @app.post("/api/chat/cloud/preview")
    def cloud_preview():
        b = body()
        cid = b.get("conv_id")
        return jsonify(ctx.engine.cloud_prepare(int(cid) if cid else None, b.get("text", ""),
                                                b.get("include_memory")))

    @app.post("/api/chat/cloud/send")
    def cloud_send():
        return jsonify(ctx.engine.cloud_send(str(body().get("payload_id", ""))))

    # --------------------------------------------------------------- memory
    @app.get("/api/memories")
    def list_mem():
        a = request.args
        return jsonify(items=ctx.memory.list(kind=a.get("kind"), q=a.get("q") or None,
                                             limit=int(a.get("limit", 200)),
                                             offset=int(a.get("offset", 0))),
                       counts=ctx.memory.counts())

    @app.post("/api/memories")
    def add_mem():
        b = body()
        mem, _ = ctx.memory.add_note(b.get("content", ""), b.get("title", ""), b.get("tags"),
                                     pinned=bool(b.get("pinned")), dedupe=False)
        return jsonify(mem), 201

    @app.post("/api/memories/link")
    def add_link():
        b = body()
        return jsonify(ctx.memory.add_link(b.get("url", ""), b.get("title", ""), b.get("note", ""),
                                           fetch=bool(b.get("fetch")))), 201

    @app.post("/api/memories/upload")
    def upload():
        files = request.files.getlist("files") or request.files.getlist("file")
        if not files:
            raise ValueError("Choose at least one file.")
        out = [ctx.memory.add_file(f.stream, f.filename or "upload") for f in files]
        return jsonify(items=out), 201

    @app.get("/api/memories/<int:mid>")
    def get_mem(mid):
        m = ctx.memory.get(mid, full=True)
        if not m:
            raise KeyError("That memory no longer exists.")
        return jsonify(m)

    @app.patch("/api/memories/<int:mid>")
    def patch_mem(mid):
        b = body()
        return jsonify(ctx.memory.update(mid, b.get("title"), b.get("content"),
                                         b.get("tags"), b.get("pinned")))

    @app.delete("/api/memories/<int:mid>")
    def del_mem(mid):
        if not ctx.memory.delete(mid):
            raise KeyError("That memory no longer exists.")
        return jsonify(ok=True)

    @app.get("/api/memories/<int:mid>/download")
    def dl_mem(mid):
        f = ctx.memory.file_path(mid)
        if f:
            return send_file(f["path"], as_attachment=True, download_name=f["name"],
                             mimetype=f["mime"] or "application/octet-stream")
        m = ctx.memory.get(mid, full=True)
        if not m:
            raise KeyError("That memory no longer exists.")
        name = (m["title"] or "memory")[:60].replace("/", "-") + ".md"
        text = f"# {m['title']}\n\n{m['content']}\n"
        return Response(text, mimetype="text/markdown", headers={
            "Content-Disposition": f"attachment; filename*=UTF-8''{__import__('urllib.parse').parse.quote(name)}"})

    @app.post("/api/memories/<int:mid>/reprocess")
    def reprocess(mid):
        if not ctx.memory.get(mid):
            raise KeyError("That memory no longer exists.")
        return jsonify(ctx.memory.reprocess(mid))

    @app.post("/api/memories/<int:mid>/fetch")
    def fetch(mid):
        return jsonify(ctx.memory.fetch_link(mid))

    @app.get("/api/search")
    def search():
        q = request.args.get("q", "")
        hits = ctx.retriever.search(q, k=12)
        for h in hits:
            h["text"] = h["text"][:400]
        return jsonify(hits=hits, mode=ctx.retriever.last_mode)

    # ---------------------------------------------------------- suggestions
    @app.get("/api/suggestions")
    def suggestions():
        return jsonify(items=ctx.learner.pending())

    @app.post("/api/suggestions/<int:sid>/accept")
    def accept(sid):
        r = ctx.db.one("SELECT * FROM suggestions WHERE id=? AND status='pending'", (sid,))
        if not r:
            raise KeyError("That suggestion is gone.")
        text = str(body().get("text") or r["text"]).strip()
        mem, _ = ctx.memory.add_note(text, origin="suggestion")
        ctx.db.execute("UPDATE suggestions SET status='accepted' WHERE id=?", (sid,))
        return jsonify(mem)

    @app.post("/api/suggestions/<int:sid>/dismiss")
    def dismiss(sid):
        ctx.db.execute("UPDATE suggestions SET status='dismissed' WHERE id=?", (sid,))
        return jsonify(ok=True)

    # ------------------------------------------------------------- insights
    @app.get("/api/insights")
    def get_insights():
        return jsonify(insights.compute(ctx))

    @app.post("/api/insights/reflect")
    def reflect():
        return jsonify(text=insights.reflect(ctx))

    @app.get("/api/privacy/log")
    def privacy_log():
        rows = ctx.db.query("SELECT ts, kind, detail FROM audit ORDER BY id DESC LIMIT 100")
        return jsonify(items=[{"ts": r["ts"], "kind": r["kind"],
                               "detail": json.loads(r["detail"] or "{}")} for r in rows])

    # --------------------------------------------------------------- backup
    @app.post("/api/backup/export")
    def export():
        blob = backup.export_bytes(ctx.db, ctx.paths, str(body().get("password", "")))
        name = time.strftime("gnosis-backup-%Y%m%d-%H%M.gnosis")
        return Response(blob, mimetype="application/octet-stream", headers={
            "Content-Disposition": f'attachment; filename="{name}"'})

    @app.post("/api/backup/import")
    def import_():
        f = request.files.get("file")
        if not f:
            raise ValueError("Choose a backup file.")
        res = backup.import_bytes(ctx.db, ctx.paths, f.read(), request.form.get("password", ""),
                                  on_restore=lambda: ctx.indexer.kick(force=True))
        return jsonify(res)

    @app.post("/api/data/wipe")
    def wipe():
        if body().get("confirm") != "DELETE":
            raise ValueError("Confirmation missing.")
        with ctx.db.tx():
            for t in ("chunks", "messages", "conversations", "memories", "suggestions", "audit"):
                ctx.db.execute(f"DELETE FROM {t}")
        for p in ctx.paths.uploads.glob("*"):
            if p.is_file():
                p.unlink(missing_ok=True)
        ctx.db.bump()
        return jsonify(ok=True)

    return app
