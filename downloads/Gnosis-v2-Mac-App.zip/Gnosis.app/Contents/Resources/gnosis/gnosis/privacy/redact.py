"""Reversible pseudonymisation for anything that may leave the device.

Detected identifiers and user-listed terms are swapped for stable placeholders
([EMAIL_1], [TERM_2] …) before sending, and swapped back in the reply, so the
cloud model never sees the real values but the answer still reads naturally.
"""
from __future__ import annotations

import re

_EMAIL = re.compile(r"[A-Za-z0-9._%+'’\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}")
_URL = re.compile(r"\bhttps?://[^\s<>\"')]+", re.I)
_IP = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")
_POSTCODE = re.compile(r"\b[A-Z]{1,2}\d[A-Z\d]?\s*\d[A-Z]{2}\b", re.I)
_NINO = re.compile(r"\b[A-CEGHJ-PR-TW-Z]{2}\s?\d{2}\s?\d{2}\s?\d{2}\s?[A-D]\b", re.I)
_IBAN = re.compile(r"\b[A-Z]{2}\d{2}(?:\s?[A-Z0-9]{4}){2,7}(?:\s?[A-Z0-9]{1,4})?\b")
_CARD = re.compile(r"\b(?:\d[ -]?){13,19}\b")
_PHONE = re.compile(r"(?<![\w.])(?:\+\d{1,3}[\s.-]?|0)\(?\d{2,5}\)?[\s.-]?\d{3,4}[\s.-]?\d{3,4}(?![\w])")


def _luhn(num: str) -> bool:
    d = [int(c) for c in num if c.isdigit()]
    if not 13 <= len(d) <= 19:
        return False
    s = 0
    for i, x in enumerate(reversed(d)):
        if i % 2:
            x *= 2
            if x > 9:
                x -= 9
        s += x
    return s % 10 == 0


def _digits(s):
    return sum(c.isdigit() for c in s)


# (label, regex, validator) in priority order
DETECTORS = [
    ("EMAIL", _EMAIL, None),
    ("URL", _URL, None),
    ("NINO", _NINO, None),
    ("IBAN", _IBAN, lambda s: _digits(s) >= 4 and len(re.sub(r"\s", "", s)) >= 15),
    ("CARD", _CARD, _luhn),
    ("IP", _IP, lambda s: all(int(p) < 256 for p in s.split("."))),
    ("POSTCODE", _POSTCODE, None),
    ("PHONE", _PHONE, lambda s: 9 <= _digits(s) <= 15),
]


class Redactor:
    def __init__(self, terms=(), name=""):
        names = []
        if name:
            names = [name] + [p for p in re.split(r"\s+", name) if len(p) >= 3]
        self.terms = [(t, "NAME" if t in names else "TERM")
                      for t in dict.fromkeys([*names, *[t for t in terms if t and t.strip()]])]
        self.mapping: dict[str, str] = {}      # placeholder -> original
        self._rev: dict[tuple, str] = {}
        self._count: dict[str, int] = {}

    def _ph(self, label, value):
        key = (label, value.lower())
        if key in self._rev:
            return self._rev[key]
        self._count[label] = self._count.get(label, 0) + 1
        ph = f"[{label}_{self._count[label]}]"
        self._rev[key] = ph
        self.mapping[ph] = value
        return ph

    def redact(self, text: str) -> str:
        if not text:
            return text
        spans = []                              # (start, end, label, prio)
        for prio, (term, label) in enumerate(self.terms):
            for m in re.finditer(r"(?<!\w)" + re.escape(term.strip()) + r"(?!\w)", text, re.I):
                spans.append((m.start(), m.end(), label, prio))
        base = len(self.terms)
        for i, (label, rx, ok) in enumerate(DETECTORS):
            for m in rx.finditer(text):
                if ok is None or ok(m.group(0)):
                    spans.append((m.start(), m.end(), label, base + i))
        # resolve overlaps: lowest prio number wins, then longer span
        spans.sort(key=lambda s: (s[3], -(s[1] - s[0])))
        taken: list[tuple[int, int, str]] = []
        for s, e, label, _ in spans:
            if all(e <= ts or s >= te for ts, te, _ in taken):
                taken.append((s, e, label))
        taken.sort()
        out, pos = [], 0
        for s, e, label in taken:
            out.append(text[pos:s])
            out.append(self._ph(label, text[s:e]))
            pos = e
        out.append(text[pos:])
        return "".join(out)

    def restore(self, text: str) -> str:
        if not text or not self.mapping:
            return text
        def sub(m):
            key = "[" + m.group(1).upper() + "_" + m.group(2) + "]"
            return self.mapping.get(key, m.group(0))
        return re.sub(r"\[([A-Za-z]+)_(\d+)\]", sub, text)

    def summary(self) -> list[dict]:
        return [{"placeholder": p, "original": o} for p, o in self.mapping.items()]
