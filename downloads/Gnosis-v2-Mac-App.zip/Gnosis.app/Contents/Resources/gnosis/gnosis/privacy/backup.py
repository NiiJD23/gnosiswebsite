"""Encrypted export/import — move Gnosis to a new laptop.

File format:  b"GNOSIS2\\n" | 16-byte salt | Fernet token
Key: PBKDF2-HMAC-SHA256, 600k iterations.  Payload: gzip-tar of a consistent
database snapshot and the uploads folder.  API keys are never included.
"""
from __future__ import annotations

import base64
import io
import os
import shutil
import tarfile
import tempfile
import time
from pathlib import Path

from cryptography.fernet import Fernet, InvalidToken
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

MAGIC = b"GNOSIS2\n"
ITER = 600_000


class BackupError(Exception):
    pass


def _key(password: str, salt: bytes) -> bytes:
    kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt, iterations=ITER)
    return base64.urlsafe_b64encode(kdf.derive(password.encode()))


def export_bytes(db, paths, password: str) -> bytes:
    if len(password or "") < 8:
        raise BackupError("Choose a password of at least 8 characters.")
    with tempfile.TemporaryDirectory() as tmp:
        snap = Path(tmp) / "gnosis.db"
        db.checkpoint_copy(str(snap))
        buf = io.BytesIO()
        with tarfile.open(fileobj=buf, mode="w:gz") as tar:
            tar.add(snap, arcname="gnosis.db")
            for f in sorted(paths.uploads.glob("*")):
                if f.is_file():
                    tar.add(f, arcname=f"uploads/{f.name}")
        salt = os.urandom(16)
        return MAGIC + salt + Fernet(_key(password, salt)).encrypt(buf.getvalue())


def _safe_members(tar: tarfile.TarFile):
    for m in tar.getmembers():
        n = m.name
        if not (m.isfile() and (n == "gnosis.db" or
                                (n.startswith("uploads/") and "/" not in n[8:] and n[8:]))):
            continue                       # ignore links, dirs, anything unexpected
        if ".." in n or n.startswith("/") or "\\" in n:
            continue
        yield m


def import_bytes(db, paths, blob: bytes, password: str, on_restore=None) -> dict:
    if not blob.startswith(MAGIC) or len(blob) < len(MAGIC) + 40:
        raise BackupError("That doesn’t look like a Gnosis backup file.")
    salt = blob[len(MAGIC): len(MAGIC) + 16]
    try:
        plain = Fernet(_key(password, salt)).decrypt(blob[len(MAGIC) + 16:])
    except InvalidToken:
        raise BackupError("Wrong password, or the file is damaged.")
    with tempfile.TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        with tarfile.open(fileobj=io.BytesIO(plain), mode="r:gz") as tar:
            members = list(_safe_members(tar))
            if not any(m.name == "gnosis.db" for m in members):
                raise BackupError("The backup doesn’t contain a database.")
            for m in members:
                src = tar.extractfile(m)
                dst = tmp / m.name
                dst.parent.mkdir(parents=True, exist_ok=True)
                with open(dst, "wb") as out:
                    shutil.copyfileobj(src, out)
        # keep a safety copy of what we are about to replace
        safety = paths.backups / f"before-import-{int(time.time())}.db"
        try:
            db.checkpoint_copy(str(safety))
        except Exception:
            pass
        db.release()
        for suffix in ("-wal", "-shm"):
            Path(str(paths.db) + suffix).unlink(missing_ok=True)
        shutil.copyfile(tmp / "gnosis.db", paths.db)
        n = 0
        if (tmp / "uploads").exists():
            for f in (tmp / "uploads").iterdir():
                shutil.copyfile(f, paths.uploads / f.name)
                n += 1
        db.reopen_all()
        if on_restore:
            on_restore()
    return {"files": n, "safety_copy": safety.name}
