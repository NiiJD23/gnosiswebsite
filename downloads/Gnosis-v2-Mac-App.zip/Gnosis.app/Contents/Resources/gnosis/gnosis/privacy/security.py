"""Hardening for a localhost web app.

* A per-run random token must accompany every /api call (blocks CSRF from
  other web pages — they cannot read our HTML to learn the token).
* The Host header must be 127.0.0.1/localhost on our port (blocks DNS rebinding).
* Strict CSP, no framing, no sniffing, no referrer, no caching of API data.
"""
from __future__ import annotations

import hmac
import secrets

from flask import jsonify, request

CSP = ("default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self' data: blob:; "
       "font-src 'self'; connect-src 'self'; media-src 'self' blob:; "
       "frame-ancestors 'none'; base-uri 'none'; form-action 'self'")


def install(app, port_fn):
    app.config["GNOSIS_TOKEN"] = secrets.token_urlsafe(32)

    @app.before_request
    def _guard():
        host = (request.host or "").lower()
        name, _, port = host.rpartition(":") if ":" in host else (host, "", "")
        allowed = {"127.0.0.1", "localhost", "[::1]"}
        if name not in allowed or (port and port != str(port_fn())):
            return jsonify(error="Forbidden host"), 403
        if request.path.startswith("/api/"):
            tok = request.headers.get("X-Gnosis-Token", "")
            if not hmac.compare_digest(tok, app.config["GNOSIS_TOKEN"]):
                return jsonify(error="Missing or invalid session token. Reload the page."), 403
            origin = request.headers.get("Origin")
            if origin and origin.split("://", 1)[-1].lower() not in (
                    f"127.0.0.1:{port_fn()}", f"localhost:{port_fn()}", f"[::1]:{port_fn()}"):
                return jsonify(error="Cross-origin request blocked"), 403

    @app.after_request
    def _headers(resp):
        resp.headers["Content-Security-Policy"] = CSP
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["X-Frame-Options"] = "DENY"
        resp.headers["Referrer-Policy"] = "no-referrer"
        resp.headers["Cross-Origin-Resource-Policy"] = "same-origin"
        if request.path.startswith("/api/") or request.path == "/":
            resp.headers["Cache-Control"] = "no-store"
        return resp
