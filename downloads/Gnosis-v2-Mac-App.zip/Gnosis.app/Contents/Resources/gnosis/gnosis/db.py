"""SQLite layer: one connection per thread, WAL, FTS5 full-text index."""
from __future__ import annotations

import contextlib
import sqlite3
import threading
import time

SCHEMA_VERSION = 2

_BASE = """
CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);

CREATE TABLE IF NOT EXISTS conversations(
  id INTEGER PRIMARY KEY,
  title TEXT NOT NULL DEFAULT 'New chat',
  pinned INTEGER NOT NULL DEFAULT 0,
  created REAL NOT NULL,
  updated REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS messages(
  id INTEGER PRIMARY KEY,
  conv_id INTEGER NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  role TEXT NOT NULL,
  content TEXT NOT NULL,
  sources TEXT,
  meta TEXT,
  created REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS msgs_conv ON messages(conv_id, id);

CREATE TABLE IF NOT EXISTS memories(
  id INTEGER PRIMARY KEY,
  kind TEXT NOT NULL,                -- note | file | link
  title TEXT NOT NULL DEFAULT '',
  content TEXT NOT NULL DEFAULT '',
  filename TEXT,                     -- original name (display only)
  stored_as TEXT,                    -- basename inside uploads/
  mime TEXT,
  size INTEGER NOT NULL DEFAULT 0,
  url TEXT,
  tags TEXT NOT NULL DEFAULT '',
  pinned INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'ready',   -- processing | ready | failed
  error TEXT,
  origin TEXT NOT NULL DEFAULT 'user',    -- user | chat | suggestion | import
  created REAL NOT NULL,
  updated REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS mem_kind ON memories(kind, updated);

CREATE TABLE IF NOT EXISTS chunks(
  id INTEGER PRIMARY KEY,
  ref_type TEXT NOT NULL,            -- memory | message
  ref_id INTEGER NOT NULL,
  conv_id INTEGER,
  idx INTEGER NOT NULL DEFAULT 0,
  header TEXT NOT NULL DEFAULT '',
  text TEXT NOT NULL,
  emb BLOB,
  emb_model TEXT
);
CREATE INDEX IF NOT EXISTS chunks_ref ON chunks(ref_type, ref_id);
CREATE INDEX IF NOT EXISTS chunks_conv ON chunks(conv_id);

CREATE TABLE IF NOT EXISTS suggestions(
  id INTEGER PRIMARY KEY,
  text TEXT NOT NULL,
  conv_id INTEGER,
  status TEXT NOT NULL DEFAULT 'pending',   -- pending | accepted | dismissed
  created REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS audit(
  id INTEGER PRIMARY KEY,
  ts REAL NOT NULL,
  kind TEXT NOT NULL,
  detail TEXT
);
"""

_FTS = """
CREATE VIRTUAL TABLE IF NOT EXISTS chunks_fts USING fts5(
  text, header, content='chunks', content_rowid='id',
  tokenize='porter unicode61 remove_diacritics 2'
);
CREATE TRIGGER IF NOT EXISTS chunks_ai AFTER INSERT ON chunks BEGIN
  INSERT INTO chunks_fts(rowid, text, header) VALUES (new.id, new.text, new.header);
END;
CREATE TRIGGER IF NOT EXISTS chunks_ad AFTER DELETE ON chunks BEGIN
  INSERT INTO chunks_fts(chunks_fts, rowid, text, header) VALUES ('delete', old.id, old.text, old.header);
END;
CREATE TRIGGER IF NOT EXISTS chunks_au AFTER UPDATE OF text, header ON chunks BEGIN
  INSERT INTO chunks_fts(chunks_fts, rowid, text, header) VALUES ('delete', old.id, old.text, old.header);
  INSERT INTO chunks_fts(rowid, text, header) VALUES (new.id, new.text, new.header);
END;
"""


class DB:
    """Thread-safe-ish wrapper: each thread gets its own connection."""

    def __init__(self, path):
        self.path = str(path)
        self._tl = threading.local()
        self._gen = 0
        self._all = []
        self._all_lock = threading.Lock()
        self.epoch = 0           # bumped whenever searchable content changes
        self.has_fts = False
        self._migrate()

    # -- connections -----------------------------------------------------
    def conn(self) -> sqlite3.Connection:
        c = getattr(self._tl, "c", None)
        if c is None or getattr(self._tl, "gen", -1) != self._gen:
            if c is not None:
                with contextlib.suppress(Exception):
                    c.close()
                with self._all_lock:
                    if c in self._all:
                        self._all.remove(c)
            c = sqlite3.connect(self.path, timeout=30, isolation_level=None,
                                check_same_thread=False)
            c.row_factory = sqlite3.Row
            c.execute("PRAGMA journal_mode=WAL")
            c.execute("PRAGMA synchronous=NORMAL")
            c.execute("PRAGMA foreign_keys=ON")
            c.execute("PRAGMA busy_timeout=30000")
            self._tl.c, self._tl.gen, self._tl.depth = c, self._gen, 0
            with self._all_lock:
                self._all.append(c)
        return c

    def release(self):
        """Close this thread's connection and invalidate all others (before a restore)."""
        c = getattr(self._tl, "c", None)
        if c is not None:
            with contextlib.suppress(Exception):
                c.execute("PRAGMA wal_checkpoint(TRUNCATE)")
            with contextlib.suppress(Exception):
                c.close()
            self._tl.c = None
        self._gen += 1
        with self._all_lock:                       # other threads' connections too
            conns, self._all = self._all, []
        for other in conns:
            with contextlib.suppress(Exception):
                other.close()

    def reopen_all(self):
        """Open fresh connections on the (restored) file."""
        self._gen += 1
        self.epoch += 1
        self._migrate()

    def bump(self):
        self.epoch += 1

    # -- helpers ---------------------------------------------------------
    def execute(self, sql, params=()):
        return self.conn().execute(sql, params)

    def query(self, sql, params=()):
        return self.conn().execute(sql, params).fetchall()

    def one(self, sql, params=()):
        return self.conn().execute(sql, params).fetchone()

    def scalar(self, sql, params=(), default=None):
        r = self.one(sql, params)
        return r[0] if r is not None and r[0] is not None else default

    @contextlib.contextmanager
    def tx(self):
        c = self.conn()
        depth = getattr(self._tl, "depth", 0)
        if depth == 0:
            c.execute("BEGIN IMMEDIATE")
        self._tl.depth = depth + 1
        try:
            yield c
        except BaseException:
            self._tl.depth -= 1
            if self._tl.depth == 0:
                c.execute("ROLLBACK")
            raise
        else:
            self._tl.depth -= 1
            if self._tl.depth == 0:
                c.execute("COMMIT")

    def checkpoint_copy(self, dest: str):
        """Consistent snapshot using SQLite's online backup API."""
        import sqlite3 as s
        dst = s.connect(dest)
        try:
            self.conn().backup(dst)
        finally:
            dst.close()

    def log(self, kind: str, detail: str = ""):
        self.execute("INSERT INTO audit(ts, kind, detail) VALUES (?,?,?)",
                     (time.time(), kind, detail))

    # -- migrations ------------------------------------------------------
    def _migrate(self):
        c = self.conn()
        c.executescript(_BASE)
        try:
            c.executescript(_FTS)
            self.has_fts = True
        except sqlite3.OperationalError:
            self.has_fts = False
        c.execute("INSERT OR REPLACE INTO meta(key, value) VALUES ('schema', ?)",
                  (str(SCHEMA_VERSION),))
        # Rebuild FTS if its content table is out of step (e.g. after restore).
        if self.has_fts:
            n_chunks = c.execute("SELECT COUNT(*) FROM chunks").fetchone()[0]
            n_fts = c.execute("SELECT COUNT(*) FROM chunks_fts_docsize").fetchone()[0] \
                if self._table_exists("chunks_fts_docsize") else -1
            if n_chunks != n_fts:
                c.execute("INSERT INTO chunks_fts(chunks_fts) VALUES ('rebuild')")

    def _table_exists(self, name):
        return self.conn().execute(
            "SELECT 1 FROM sqlite_master WHERE name=?", (name,)).fetchone() is not None
