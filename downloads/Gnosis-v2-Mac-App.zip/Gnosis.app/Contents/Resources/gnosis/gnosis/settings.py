"""User settings (non-secret) stored as JSON blobs in SQLite."""
from __future__ import annotations

import copy
import json
import os
from urllib.parse import urlparse

DEFAULTS = {
    "profile": {"name": "", "about": "", "role": "", "location": "", "links": []},
    "appearance": {"theme": "system"},
    "advisory": {"style": "", "priorities": [], "tone": "balanced"},
    "models": {"chat": "llama3.1:8b", "embed": "nomic-embed-text",
               "num_ctx": 8192, "temperature": 0.4},
    "ollama_host": "",
    "cloud": {"enabled": False, "model": "claude-sonnet-5-5",
              "redact_terms": [], "include_memory": False},
    "ui": {"sidebar_open": True},
}

TONES = {"balanced", "concise", "warm", "formal", "coach"}


def _str(v, n):
    return str(v or "").strip()[:n]


def _clean(section: str, value):
    """Validate/normalise one settings section."""
    base = DEFAULTS[section]
    if section == "ollama_host":
        v = _str(value, 200)
        if v:
            if "://" not in v:
                v = "http://" + v
            p = urlparse(v)
            if p.scheme not in ("http", "https") or not p.hostname:
                raise ValueError("Ollama address must look like http://127.0.0.1:11434")
            v = v.rstrip("/")
        return v
    if not isinstance(value, dict):
        raise ValueError(f"{section} must be an object")
    out = copy.deepcopy(base)
    for k in base:
        if k in value:
            out[k] = value[k]
    if section == "profile":
        for k in ("name", "role", "location"):
            out[k] = _str(out[k], 120)
        out["about"] = _str(out["about"], 4000)
        links = []
        for item in (out["links"] or [])[:30]:
            if isinstance(item, dict):
                label, url = _str(item.get("label"), 60), _str(item.get("url"), 300)
                if url:
                    links.append({"label": label, "url": url})
        out["links"] = links
    elif section == "appearance":
        out["theme"] = out["theme"] if out["theme"] in ("light", "dark", "system") else "system"
    elif section == "advisory":
        out["style"] = _str(out["style"], 2000)
        out["tone"] = out["tone"] if out["tone"] in TONES else "balanced"
        out["priorities"] = [_str(p, 60) for p in (out["priorities"] or [])[:20] if _str(p, 60)]
    elif section == "models":
        out["chat"] = _str(out["chat"], 100) or base["chat"]
        out["embed"] = _str(out["embed"], 100) or base["embed"]
        try:
            out["num_ctx"] = max(2048, min(131072, int(out["num_ctx"])))
        except (TypeError, ValueError):
            out["num_ctx"] = base["num_ctx"]
        try:
            out["temperature"] = max(0.0, min(1.5, float(out["temperature"])))
        except (TypeError, ValueError):
            out["temperature"] = base["temperature"]
    elif section == "cloud":
        out["enabled"] = bool(out["enabled"])
        out["include_memory"] = bool(out["include_memory"])
        out["model"] = _str(out["model"], 100) or base["model"]
        out["redact_terms"] = [_str(t, 80) for t in (out["redact_terms"] or [])[:200]
                               if _str(t, 80)]
    elif section == "ui":
        out["sidebar_open"] = bool(out["sidebar_open"])
    return out


class Settings:
    def __init__(self, db):
        self.db = db

    def get(self, section: str):
        row = self.db.one("SELECT value FROM settings WHERE key=?", (section,))
        base = copy.deepcopy(DEFAULTS[section])
        if row:
            try:
                val = json.loads(row["value"])
                if isinstance(base, dict) and isinstance(val, dict):
                    base.update(val)
                    return base
                return val
            except ValueError:
                pass
        return base

    def all(self) -> dict:
        return {k: self.get(k) for k in DEFAULTS}

    def update(self, patch: dict) -> dict:
        for section, value in (patch or {}).items():
            if section not in DEFAULTS:
                continue
            clean = _clean(section, value if section == "ollama_host" else
                           {**self.get(section), **(value if isinstance(value, dict) else {})}
                           if isinstance(value, dict) else value)
            self.db.execute("INSERT OR REPLACE INTO settings(key, value) VALUES (?,?)",
                            (section, json.dumps(clean)))
        return self.all()

    # convenience ------------------------------------------------------
    def ollama_host(self) -> str:
        return (self.get("ollama_host") or os.environ.get("GNOSIS_OLLAMA_HOST")
                or "http://127.0.0.1:11434").rstrip("/")
