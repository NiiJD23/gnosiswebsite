"""The conversation brain: prompt assembly, memory retrieval, streaming,
explicit memory capture, background learning, and the cloud-escalation flow."""
from __future__ import annotations

import json
import re
import threading
import time
import uuid
from datetime import datetime

from ..llm import cloud as cloudmod
from ..llm.ollama import OllamaError
from ..memory.learn import detect_capture
from ..memory.store import auto_title
from ..privacy.redact import Redactor

TONES = {
    "balanced": "",
    "concise": "Keep answers short and to the point unless asked for depth.",
    "warm": "Be warm and encouraging while staying honest.",
    "formal": "Use a formal, professional register.",
    "coach": "Act as a coach: ask one sharp question when it would help the user think, "
             "and push gently on weak reasoning.",
}


def est_tokens(s: str) -> int:
    return len(s) // 3 + 1


class ChatEngine:
    def __init__(self, ctx):
        self.c = ctx
        self._pending: dict[str, dict] = {}

    # ------------------------------------------------------------------ prompt
    def _now(self) -> str:
        n = datetime.now().astimezone()
        return n.strftime("%A %d %B %Y, %H:%M ") + (n.tzname() or "")

    def system_prompt(self, cloud=False) -> str:
        s = self.c.settings
        prof, adv = s.get("profile"), s.get("advisory")
        name = prof.get("name") or "the user"
        lines = [
            f"You are Gnosis, {name}'s private personal assistant."
            + ("" if cloud else f" You run entirely on {name}'s own computer; their memory never leaves it."),
            f"Today is {self._now()}.",
        ]
        if not cloud:
            about = []
            if prof.get("name"):
                about.append(f"Name: {prof['name']}")
            for key, label in (("role", "Role"), ("location", "Based in")):
                if prof.get(key):
                    about.append(f"{label}: {prof[key]}")
            if prof.get("about"):
                about.append(f"About: {prof['about']}")
            for l in prof.get("links", [])[:12]:
                about.append(f"{l.get('label') or 'Link'}: {l['url']}")
            if about:
                lines += ["", "ABOUT THE USER", *about]
        lines += ["", "HOW TO ANSWER",
                  "- Sound like a thoughtful, capable human assistant: natural, direct, warm. "
                  "Mirror the user's wording, spelling and formality. No filler openers "
                  "(\"Certainly!\", \"Great question!\").",
                  "- Lead with the answer or recommendation, then the reasoning. Short paragraphs; "
                  "use lists only for genuinely list-like content."]
        if not cloud:
            lines += [
                "- MEMORY EXCERPTS (below) come from the user's own notes, documents and past chats. "
                "Use them whenever they bear on the question and cite the excerpt right after the "
                "claim like [M1]. Cite only excerpts you actually used. Ignore irrelevant ones "
                "without mentioning them.",
                "- Never invent facts about the user. If something personal isn't in the excerpts "
                "or profile, say you don't have it and ask. If excerpts disagree, prefer the "
                "newer one and say so.",
                "- If the user tells you something about themselves, acknowledge it naturally. "
                "They can say \"remember that…\" to save it permanently."]
        if adv.get("style") or adv.get("priorities") or TONES.get(adv.get("tone"), ""):
            lines += ["", "ADVISORY STYLE (set by the user)"]
            if adv.get("style"):
                lines.append(adv["style"])
            if adv.get("priorities"):
                lines.append("Priorities when weighing options: " + ", ".join(adv["priorities"]) + ".")
            if TONES.get(adv.get("tone")):
                lines.append(TONES[adv["tone"]])
        return "\n".join(lines)

    @staticmethod
    def _excerpt(n, h) -> str:
        when = datetime.fromtimestamp(h["date"]).strftime("%d %b %Y") if h.get("date") else ""
        kind = {"chat": "past chat", "note": "note", "file": "document", "link": "web link"}.get(h["kind"], h["kind"])
        head = h["header"] or h["title"]
        return f"[M{n}] {head} ({kind}{', ' + when if when else ''})\n{h['text'][:1400].strip()}"

    def _retrieve(self, conv_id, text, history):
        q = text
        if len(text.split()) < 8:                       # short follow-up: add the prior user turn
            prev = [m["content"] for m in history if m["role"] == "user"]
            if prev:
                q = prev[-1][:300] + " " + text
        try:
            return self.c.retriever.search(q, k=8, conv_exclude=conv_id)
        except Exception:
            return []

    def build(self, conv_id, text, history):
        """Return (messages, sources) fitted to the model's context window."""
        models = self.c.settings.get("models")
        num_ctx = models["num_ctx"]
        reserve = min(2048, num_ctx // 4)
        avail = num_ctx - reserve
        system = self.system_prompt()
        user_tok = est_tokens(text)
        if user_tok > avail // 2:                        # giant paste: keep head & tail
            keep = (avail // 2) * 3
            text = text[: keep // 2] + "\n[…middle trimmed to fit…]\n" + text[-keep // 2:]
            user_tok = est_tokens(text)
        hits = self._retrieve(conv_id, text, history)
        sys_tok = est_tokens(system) + 40
        ctx_budget = max(0, min(int(avail * 0.4), 3500, avail - sys_tok - user_tok - 400))
        blocks, sources, used = [], [], 0
        for h in hits:
            n = len(sources) + 1
            block = self._excerpt(n, h)
            t = est_tokens(block)
            if used + t > ctx_budget:
                continue
            used += t
            blocks.append(block)
            sources.append({"n": n, "ref_type": h["ref_type"], "ref_id": h["ref_id"],
                            "conv_id": h["conv_id"], "kind": h["kind"], "title": h["title"],
                            "header": h["header"], "snippet": re.sub(r"\s+", " ", h["text"])[:240]})
        pinned = self.c.memory.pinned_context()
        extra = ""
        if pinned:
            extra += "\n\nALWAYS-KNOWN NOTES\n" + "\n".join(f"- {t}: {c}" for t, c in pinned)
        extra += ("\n\nMEMORY EXCERPTS\n" + "\n\n".join(blocks)) if blocks else \
            "\n\nMEMORY EXCERPTS\n(none found for this message)"
        system += extra
        hist_budget = avail - est_tokens(system) - user_tok
        kept = []
        for m in reversed(history):
            t = est_tokens(m["content"]) + 4
            if t > hist_budget:
                break
            hist_budget -= t
            kept.append({"role": m["role"], "content": m["content"]})
        kept.reverse()
        msgs = [{"role": "system", "content": system}, *kept, {"role": "user", "content": text}]
        return msgs, sources

    def _options(self):
        m = self.c.settings.get("models")
        return {"num_ctx": m["num_ctx"], "temperature": m["temperature"]}

    # ------------------------------------------------------------------ stream
    def stream(self, conv_id, text, regenerate=False):
        convs, c = self.c.convs, self.c
        if conv_id:
            conv = convs.get(conv_id)
            if not conv:
                yield {"type": "error", "code": "not_found", "message": "That chat no longer exists."}
                return
        else:
            conv = convs.create()
        cid = conv["id"]
        history_all = convs.messages(cid)
        if regenerate:
            while history_all and history_all[-1]["role"] == "assistant":
                convs.delete_message(history_all.pop()["id"])
            if not history_all or history_all[-1]["role"] != "user":
                yield {"type": "error", "code": "bad_request", "message": "Nothing to regenerate."}
                return
            last = history_all.pop()
            text, user_mid = last["content"], last["id"]
            captured = None
        else:
            text = (text or "").strip()
            if not text:
                yield {"type": "error", "code": "bad_request", "message": "Type a message first."}
                return
            user_mid = convs.add_message(cid, "user", text)
            captured = None
            fact = detect_capture(text)
            if fact:
                try:
                    mem, created = c.memory.add_note(fact, origin="chat")
                    captured = {"id": mem["id"], "title": mem["title"], "created": created}
                except ValueError:
                    pass
        first_turn = len(history_all) == 0 and not regenerate
        if first_turn:
            convs.rename(cid, auto_title(text, 48))
        yield {"type": "start", "conv_id": cid, "user_message_id": user_mid,
               "title": convs.get(cid)["title"]}
        if captured:
            yield {"type": "saved", "memory": captured}

        try:
            msgs, sources = self.build(cid, text, history_all)
        except Exception as e:                             # defensive: never break chat on retrieval
            msgs = [{"role": "system", "content": self.system_prompt()},
                    {"role": "user", "content": text}]
            sources = []
        if captured:
            msgs[0]["content"] += ("\n\nNOTE: The user's message has just been saved to their "
                                   "memory. Confirm briefly in your own words; don't repeat it all.")
        yield {"type": "sources", "sources": sources}

        parts, ok, stats = [], False, {}
        models = c.settings.get("models")
        try:
            for ev in c.ollama.chat_stream(msgs, models["chat"], self._options()):
                if "token" in ev:
                    parts.append(ev["token"])
                    yield {"type": "token", "t": ev["token"]}
                elif ev.get("done"):
                    ok, stats = True, ev.get("stats", {})
        except OllamaError as e:
            yield {"type": "error", "code": e.code, "message": e.message, "action": e.action}
        finally:
            reply = "".join(parts).strip()
            mid = None
            if reply:
                meta = {"model": models["chat"], "partial": not ok, **({"saved": captured} if captured else {})}
                used = [s for s in sources if re.search(rf"\[M{s['n']}\]", reply)]
                mid = convs.add_message(cid, "assistant", reply, used or None, meta)
            self._after(cid, user_mid, text, first_turn, bool(captured), reply)
        if ok:
            yield {"type": "done", "message_id": mid, "stats": stats,
                   "sources": [s for s in sources if re.search(rf"\[M{s['n']}\]", reply)]}

    # ------------------------------------------------------------------ after
    def _index_user_message(self, cid, mid, text):
        if len(text) < 30:
            return
        title = self.c.convs.get(cid)["title"]
        self.c.db.execute(
            "INSERT INTO chunks(ref_type, ref_id, conv_id, idx, header, text) VALUES "
            "('message', ?, ?, 0, ?, ?)", (mid, cid, title, text[:1800]))
        self.c.db.bump()
        self.c.indexer.kick()

    def _after(self, cid, user_mid, text, first_turn, captured, reply):
        try:
            if not captured:
                self._index_user_message(cid, user_mid, text)
        except Exception:
            pass
        def work():
            try:
                if first_turn and reply:
                    self._llm_title(cid, text, reply)
                if not captured:
                    self.c.learner.suggest_from(cid, text)
            except Exception:
                pass
        if self.c.background:
            threading.Thread(target=work, daemon=True, name="gnosis-after").start()
        else:
            work()

    def _llm_title(self, cid, text, reply):
        models = self.c.settings.get("models")
        prompt = ("Write a title of 3 to 6 words for this conversation. No quotes, no trailing "
                  f"punctuation. Reply with the title only.\n\nUser: {text[:400]}\nAssistant: {reply[:300]}")
        try:
            t = self.c.ollama.chat([{"role": "user", "content": prompt}], models["chat"],
                                   options={"temperature": 0.2, "num_predict": 20, "num_ctx": 2048},
                                   timeout=60)
        except OllamaError:
            return
        t = re.sub(r"\s+", " ", t.strip().strip("\"'“”.")).strip()
        if 3 <= len(t) <= 70 and "\n" not in t:
            cur = self.c.convs.get(cid)
            if cur and cur["title"] == auto_title(text, 48):   # don't override a user rename
                self.c.convs.rename(cid, t)

    # ------------------------------------------------------------------ cloud
    def cloud_prepare(self, conv_id, text, include_memory=None):
        s = self.c.settings
        cfg = s.get("cloud")
        if not cfg["enabled"]:
            raise PermissionError("Cloud escalation is switched off. Enable it in Settings → Cloud.")
        if not self.c.secrets.get("anthropic"):
            raise PermissionError("Add your cloud API key in Settings → Cloud first.")
        text = (text or "").strip()
        if not text:
            raise ValueError("Type a message first.")
        include = cfg["include_memory"] if include_memory is None else bool(include_memory)
        history = self.c.convs.messages(conv_id)[-6:] if conv_id else []
        red = Redactor(cfg["redact_terms"], s.get("profile").get("name", ""))
        system = self.system_prompt(cloud=True)
        hits = []
        if include:
            hits = self._retrieve(conv_id, text, history)[:5]
            if hits:
                system += "\n\nRELEVANT NOTES FROM THE USER'S MEMORY (cite as [M1] if used)\n" + \
                    "\n\n".join(self._excerpt(i + 1, h) for i, h in enumerate(hits))
        msgs = [{"role": m["role"], "content": m["content"][:3000]} for m in history]
        msgs.append({"role": "user", "content": text})
        msgs = _alternate(msgs)
        r_system = red.redact(system)
        r_msgs = [{"role": m["role"], "content": red.redact(m["content"])} for m in msgs]
        pid = uuid.uuid4().hex
        now = time.time()
        self._pending = {k: v for k, v in self._pending.items() if v["exp"] > now}
        self._pending[pid] = {"exp": now + 600, "system": r_system, "messages": r_msgs,
                              "red": red, "conv_id": conv_id, "text": text, "model": cfg["model"],
                              "sources": [{"n": i + 1, "ref_type": h["ref_type"], "ref_id": h["ref_id"],
                                           "kind": h["kind"], "title": h["title"], "header": h["header"],
                                           "snippet": h["text"][:240]} for i, h in enumerate(hits)]}
        return {"payload_id": pid, "system": r_system, "messages": r_msgs, "model": cfg["model"],
                "redactions": red.summary(), "memory_excerpts": len(hits),
                "characters": len(r_system) + sum(len(m["content"]) for m in r_msgs)}

    def cloud_send(self, payload_id):
        p = self._pending.pop(payload_id, None)
        if not p or p["exp"] < time.time():
            raise KeyError("That preview expired. Preview again before sending.")
        key = self.c.secrets.get("anthropic")
        if not key:
            raise PermissionError("No cloud API key is saved.")
        out = cloudmod.complete(key, p["model"], p["system"], p["messages"])
        reply = p["red"].restore(out["text"]).strip() or "(The cloud model returned an empty reply.)"
        cid = p["conv_id"]
        convs = self.c.convs
        if cid and convs.get(cid):
            first = len(convs.messages(cid)) == 0
        else:
            cid, first = convs.create()["id"], True
        umid = convs.add_message(cid, "user", p["text"])
        if first:
            convs.rename(cid, auto_title(p["text"], 48))
        used = [s for s in p["sources"] if re.search(rf"\[M{s['n']}\]", reply)]
        mid = convs.add_message(cid, "assistant", reply, used or None,
                                {"cloud": True, "model": p["model"],
                                 "redactions": len(p["red"].mapping)})
        self.c.db.log("cloud_send", json.dumps({
            "model": p["model"], "conv_id": cid, "characters": len(p["system"]) +
            sum(len(m["content"]) for m in p["messages"]), "redactions": len(p["red"].mapping)}))
        self._index_user_message(cid, umid, p["text"])
        return {"conv_id": cid, "title": convs.get(cid)["title"], "message_id": mid,
                "content": reply, "sources": used, "cloud": True}


def _alternate(msgs):
    """Anthropic requires strictly alternating roles starting with 'user'."""
    out = []
    for m in msgs:
        if out and out[-1]["role"] == m["role"]:
            out[-1]["content"] += "\n\n" + m["content"]
        else:
            out.append(dict(m))
    while out and out[0]["role"] != "user":
        out.pop(0)
    return out
