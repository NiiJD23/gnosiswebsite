"""Conversation and message persistence."""
from __future__ import annotations

import json
import time


class Conversations:
    def __init__(self, db):
        self.db = db

    def create(self, title="New chat") -> dict:
        now = time.time()
        cur = self.db.execute(
            "INSERT INTO conversations(title, created, updated) VALUES (?,?,?)",
            (title, now, now))
        return self.get(cur.lastrowid)

    def get(self, cid: int):
        r = self.db.one("SELECT * FROM conversations WHERE id=?", (cid,))
        return self._row(r) if r else None

    @staticmethod
    def _row(r):
        return {"id": r["id"], "title": r["title"], "pinned": bool(r["pinned"]),
                "created": r["created"], "updated": r["updated"]}

    def list(self, q=None, limit=500):
        sql = ("SELECT c.*, (SELECT COUNT(*) FROM messages m WHERE m.conv_id=c.id) n "
               "FROM conversations c ")
        args = []
        if q:
            sql += ("WHERE c.title LIKE ? OR EXISTS (SELECT 1 FROM messages m WHERE "
                    "m.conv_id=c.id AND m.content LIKE ?) ")
            like = "%" + q.replace("%", r"\%") + "%"
            args += [like, like]
        sql += "ORDER BY c.pinned DESC, c.updated DESC LIMIT ?"
        args.append(limit)
        out = []
        for r in self.db.query(sql, args):
            d = self._row(r)
            d["messages"] = r["n"]
            out.append(d)
        return out

    def rename(self, cid: int, title: str):
        title = (title or "").strip()[:120]
        if not title:
            raise ValueError("A chat needs a name.")
        self.db.execute("UPDATE conversations SET title=? WHERE id=?", (title, cid))
        self.db.execute("UPDATE chunks SET header=? WHERE ref_type='message' AND conv_id=?",
                        (title, cid))
        return self.get(cid)

    def pin(self, cid: int, pinned: bool):
        self.db.execute("UPDATE conversations SET pinned=? WHERE id=?", (int(bool(pinned)), cid))
        return self.get(cid)

    def touch(self, cid: int):
        self.db.execute("UPDATE conversations SET updated=? WHERE id=?", (time.time(), cid))

    def delete(self, cid: int) -> bool:
        with self.db.tx():
            self.db.execute("DELETE FROM chunks WHERE ref_type='message' AND conv_id=?", (cid,))
            cur = self.db.execute("DELETE FROM conversations WHERE id=?", (cid,))
        self.db.bump()
        return cur.rowcount > 0

    def delete_all(self) -> int:
        with self.db.tx():
            self.db.execute("DELETE FROM chunks WHERE ref_type='message'")
            n = self.db.scalar("SELECT COUNT(*) FROM conversations", default=0)
            self.db.execute("DELETE FROM conversations")
        self.db.bump()
        return n

    def clear(self, cid: int):
        """Remove the messages but keep the (now empty) chat."""
        with self.db.tx():
            self.db.execute("DELETE FROM chunks WHERE ref_type='message' AND conv_id=?", (cid,))
            self.db.execute("DELETE FROM messages WHERE conv_id=?", (cid,))
        self.db.bump()

    # -- messages --------------------------------------------------------------
    def add_message(self, cid: int, role: str, content: str, sources=None, meta=None) -> int:
        cur = self.db.execute(
            "INSERT INTO messages(conv_id, role, content, sources, meta, created) "
            "VALUES (?,?,?,?,?,?)",
            (cid, role, content, json.dumps(sources) if sources else None,
             json.dumps(meta) if meta else None, time.time()))
        self.touch(cid)
        return cur.lastrowid

    def messages(self, cid: int, limit=None):
        sql = "SELECT * FROM messages WHERE conv_id=? ORDER BY id"
        rows = self.db.query(sql, (cid,))
        if limit:
            rows = rows[-limit:]
        out = []
        for r in rows:
            out.append({"id": r["id"], "role": r["role"], "content": r["content"],
                        "sources": json.loads(r["sources"]) if r["sources"] else [],
                        "meta": json.loads(r["meta"]) if r["meta"] else {},
                        "created": r["created"]})
        return out

    def delete_message(self, mid: int):
        self.db.execute("DELETE FROM chunks WHERE ref_type='message' AND ref_id=?", (mid,))
        self.db.execute("DELETE FROM messages WHERE id=?", (mid,))
        self.db.bump()
