"""Wires every component together once; the web layer and tests share it."""
from __future__ import annotations

from .chat.engine import ChatEngine
from .chat.store import Conversations
from .db import DB
from .llm.ollama import Ollama
from .memory.indexer import Indexer
from .memory.learn import Learner
from .memory.retrieval import Retriever
from .memory.store import MemoryStore
from .paths import Paths
from .secrets_store import Secrets
from .settings import Settings


class Context:
    def __init__(self, home=None, background=True):
        self.background = background
        self.paths = Paths(home)
        self.db = DB(self.paths.db)
        self.settings = Settings(self.db)
        self.secrets = Secrets(self.paths.home)
        self.ollama = Ollama(self.settings.ollama_host)
        self.indexer = Indexer(self.db, self.ollama, self.settings)
        self.memory = MemoryStore(self.db, self.paths, self.indexer)
        self.retriever = Retriever(self.db, self.ollama, self.settings)
        self.convs = Conversations(self.db)
        self.learner = Learner(self.db, self.ollama, self.settings)
        self.engine = ChatEngine(self)
        if background:
            self.indexer.start()
            self.indexer.kick()

    def close(self):
        self.indexer.stop()
