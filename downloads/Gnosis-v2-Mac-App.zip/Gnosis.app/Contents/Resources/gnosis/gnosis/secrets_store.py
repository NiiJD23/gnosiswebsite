"""Secret storage (cloud API key).

Order of preference:
  1. The operating system keychain via `keyring` (macOS Keychain, Windows
     Credential Locker, Secret Service).
  2. An encrypted file (Fernet) beside the database, key in a 0600 key-file.
Secrets are never written to the settings table and never included in backups.
"""
from __future__ import annotations

import json
import os
import stat
from pathlib import Path

SERVICE = "gnosis-assistant"


class Secrets:
    def __init__(self, home: Path):
        self.home = Path(home)
        self._kr = self._load_keyring()
        self._enc = self.home / "secrets.enc"
        self._keyfile = self.home / "secret.key"

    @staticmethod
    def _load_keyring():
        if os.environ.get("GNOSIS_NO_KEYRING"):
            return None
        try:
            import keyring
            name = type(keyring.get_keyring()).__name__.lower()
            if "fail" in name or "null" in name:
                return None
            return keyring
        except Exception:
            return None

    @property
    def backend(self) -> str:
        return "os-keychain" if self._kr else "encrypted-file"

    # -- file backend ------------------------------------------------------
    def _fernet(self):
        from cryptography.fernet import Fernet
        if not self._keyfile.exists():
            self._keyfile.write_bytes(Fernet.generate_key())
            try:
                os.chmod(self._keyfile, stat.S_IRUSR | stat.S_IWUSR)
            except OSError:
                pass
        return Fernet(self._keyfile.read_bytes())

    def _file_read(self) -> dict:
        if not self._enc.exists():
            return {}
        try:
            return json.loads(self._fernet().decrypt(self._enc.read_bytes()))
        except Exception:
            return {}

    def _file_write(self, data: dict):
        self._enc.write_bytes(self._fernet().encrypt(json.dumps(data).encode()))
        try:
            os.chmod(self._enc, stat.S_IRUSR | stat.S_IWUSR)
        except OSError:
            pass

    # -- public ------------------------------------------------------------
    def get(self, name: str) -> str | None:
        if self._kr:
            try:
                return self._kr.get_password(SERVICE, name)
            except Exception:
                pass
        return self._file_read().get(name)

    def set(self, name: str, value: str):
        if self._kr:
            try:
                self._kr.set_password(SERVICE, name, value)
                return
            except Exception:
                self._kr = None
        data = self._file_read()
        data[name] = value
        self._file_write(data)

    def delete(self, name: str):
        if self._kr:
            try:
                self._kr.delete_password(SERVICE, name)
            except Exception:
                pass
        data = self._file_read()
        if name in data:
            del data[name]
            self._file_write(data)

    def hint(self, name: str) -> str:
        v = self.get(name)
        return ("…" + v[-4:]) if v and len(v) > 8 else ("set" if v else "")
