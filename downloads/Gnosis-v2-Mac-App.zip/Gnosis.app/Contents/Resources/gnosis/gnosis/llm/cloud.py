"""Optional cloud model (Anthropic Messages API).  Only ever called with a
payload the user has previewed and confirmed (see chat/engine.py)."""
from __future__ import annotations

import json
import os
import ssl
import urllib.error
import urllib.request

API_URL = "https://api.anthropic.com/v1/messages"
API_VERSION = "2023-06-01"


class CloudError(Exception):
    def __init__(self, message):
        super().__init__(message)
        self.message = message


def _ssl_context():
    try:
        import certifi
        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        return ssl.create_default_context()


def complete(api_key: str, model: str, system: str, messages: list, max_tokens=2048,
             timeout=120) -> dict:
    url = os.environ.get("GNOSIS_CLOUD_URL", API_URL)
    body = json.dumps({"model": model, "max_tokens": max_tokens,
                       "system": system, "messages": messages}).encode()
    req = urllib.request.Request(url, data=body, method="POST", headers={
        "content-type": "application/json", "x-api-key": api_key,
        "anthropic-version": API_VERSION})
    ctx = None if url.startswith("http://") else _ssl_context()
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=ctx) as r:
            data = json.load(r)
    except urllib.error.HTTPError as e:
        detail = ""
        try:
            detail = json.loads(e.read().decode()).get("error", {}).get("message", "")
        except Exception:
            pass
        if e.code in (401, 403):
            raise CloudError("The cloud provider rejected your API key. "
                             "Check it in Settings → Cloud.") from e
        if e.code == 429:
            raise CloudError("The cloud provider is rate-limiting you. Try again shortly.") from e
        raise CloudError(detail or f"Cloud request failed (HTTP {e.code}).") from e
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        raise CloudError("Couldn’t reach the cloud provider. Check your internet "
                         "connection — nothing was sent.") from e
    text = "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text")
    return {"text": text, "usage": data.get("usage", {})}
