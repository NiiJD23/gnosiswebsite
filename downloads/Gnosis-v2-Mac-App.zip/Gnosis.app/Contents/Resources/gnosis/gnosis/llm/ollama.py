"""Minimal Ollama client (stdlib only) with friendly, actionable errors."""
from __future__ import annotations

import json
import time
import urllib.error
import urllib.request


class OllamaError(Exception):
    code = "ollama_error"

    def __init__(self, message, action=None, status=None):
        super().__init__(message)
        self.message = message
        self.action = action
        self.status = status


class OllamaDown(OllamaError):
    code = "ollama_down"


class ModelMissing(OllamaError):
    code = "model_missing"

    def __init__(self, model):
        super().__init__(f"The model “{model}” isn’t installed yet.",
                         action={"type": "pull", "model": model})
        self.model = model


def norm(name: str) -> str:
    name = (name or "").strip()
    return name if ":" in name else name + ":latest"


class Ollama:
    def __init__(self, host_fn):
        self._host_fn = host_fn
        self._tags_cache = (0.0, None)

    @property
    def host(self) -> str:
        return self._host_fn()

    # -- plumbing ----------------------------------------------------------
    def _open(self, path, payload=None, timeout=120):
        url = self.host + path
        data = json.dumps(payload).encode() if payload is not None else None
        req = urllib.request.Request(url, data=data,
                                     headers={"Content-Type": "application/json"},
                                     method="POST" if data is not None else "GET")
        try:
            return urllib.request.urlopen(req, timeout=timeout)
        except urllib.error.HTTPError as e:
            body = ""
            try:
                body = e.read().decode("utf-8", "replace")
                body = json.loads(body).get("error", body)
            except Exception:
                pass
            self._raise_for(e.code, str(body), payload)
        except (urllib.error.URLError, ConnectionError, TimeoutError, OSError) as e:
            raise OllamaDown(
                "Gnosis can’t reach Ollama. Open the Ollama app (or run `ollama serve`) "
                f"and try again. ({self.host})") from e

    def _raise_for(self, status, body, payload):
        low = body.lower()
        model = (payload or {}).get("model", "")
        if status == 404 and "not found" in low and "model" in low:
            raise ModelMissing(model or "the requested model")
        if "context length" in low or "exceeds" in low:
            raise OllamaError("That conversation is too long for the model’s memory window. "
                              "Start a new chat or raise the context size in Settings → Models.",
                              status=status)
        raise OllamaError(body or f"Ollama returned HTTP {status}", status=status)

    # -- API ---------------------------------------------------------------
    def tags(self, max_age=0.0, timeout=2.5):
        t, cached = self._tags_cache
        if cached is not None and time.time() - t < max_age:
            return cached
        with self._open("/api/tags", timeout=timeout) as r:
            names = [m["name"] for m in json.load(r).get("models", [])]
        self._tags_cache = (time.time(), names)
        return names

    def has(self, model: str, names=None) -> bool:
        names = names if names is not None else self.tags()
        want = norm(model)
        return any(norm(n) == want for n in names)

    def status(self, chat_model: str, embed_model: str) -> dict:
        try:
            names = self.tags()
        except OllamaError as e:
            return {"running": False, "models": [], "chat_ok": False, "embed_ok": False,
                    "message": e.message, "host": self.host}
        return {"running": True, "models": names, "host": self.host,
                "chat_ok": self.has(chat_model, names),
                "embed_ok": self.has(embed_model, names)}

    def chat_stream(self, messages, model, options=None, keep_alive="30m"):
        payload = {"model": model, "messages": messages, "stream": True,
                   "keep_alive": keep_alive, "options": options or {}}
        resp = self._open("/api/chat", payload, timeout=600)
        with resp:
            for raw in resp:
                raw = raw.strip()
                if not raw:
                    continue
                try:
                    obj = json.loads(raw)
                except ValueError:
                    continue
                if obj.get("error"):
                    self._raise_for(500, obj["error"], payload)
                piece = (obj.get("message") or {}).get("content", "")
                if piece:
                    yield {"token": piece}
                if obj.get("done"):
                    yield {"done": True, "stats": {
                        k: obj.get(k) for k in ("prompt_eval_count", "eval_count")}}
                    return

    def chat(self, messages, model, options=None, fmt=None, timeout=300) -> str:
        payload = {"model": model, "messages": messages, "stream": False,
                   "keep_alive": "30m", "options": options or {}}
        if fmt:
            payload["format"] = fmt
        with self._open("/api/chat", payload, timeout=timeout) as r:
            return (json.load(r).get("message") or {}).get("content", "")

    def embed(self, texts, model, timeout=120):
        if not texts:
            return []
        payload = {"model": model, "input": list(texts)}
        try:
            with self._open("/api/embed", payload, timeout=timeout) as r:
                return json.load(r)["embeddings"]
        except ModelMissing:
            raise
        except OllamaError as e:
            if e.code != "ollama_error" or e.status != 404:
                raise
        # Older Ollama: one request per text on the legacy endpoint.
        out = []
        for t in texts:
            with self._open("/api/embeddings", {"model": model, "prompt": t},
                            timeout=timeout) as r:
                out.append(json.load(r)["embedding"])
        return out

    def pull_stream(self, model):
        payload = {"model": model, "stream": True}
        with self._open("/api/pull", payload, timeout=3600) as r:
            for raw in r:
                raw = raw.strip()
                if raw:
                    try:
                        yield json.loads(raw)
                    except ValueError:
                        continue
        self._tags_cache = (0.0, None)
