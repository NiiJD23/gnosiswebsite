# Gnosis

**A private personal assistant that lives on your computer.**
Your memories, files, chats and settings stay on your machine. Gnosis answers with a local model (via [Ollama](https://ollama.com)) and — only if you switch it on, and only after you review a redacted preview — can ask a stronger cloud model.

![Gnosis](static/favicon.svg)

## What it does

| | |
|---|---|
| **Chat** | Multiple conversations with history (rename, pin, search, clear, delete, hide the list). Streaming answers, stop/regenerate, `[1]` source chips showing which memories were used. |
| **Memory** | Add notes, upload *any* file (PDF, Word, PowerPoint, Excel, text, Markdown, CSV, HTML, images via OCR, audio/video via Whisper), save links and social accounts. Edit, download or delete anything. |
| **"Remember that…"** | Say it in chat and it is saved instantly. Gnosis also *suggests* facts it noticed — you accept or dismiss; nothing is memorised silently. |
| **Recall** | Hybrid search (keywords + meaning) over everything, including your past chats, so answers use what you have told it. |
| **Profile & advisory style** | Who you are, how you like to be advised, your priorities — applied to every answer. |
| **Privacy** | Local-first. Cloud is off by default; when on, you see exactly what is sent, with names/emails/phones/etc. replaced by placeholders and restored in the reply. |
| **Move laptops** | One password-encrypted backup file. |

## Quick start

1. Install **Ollama** from <https://ollama.com/download> and open it once.
2. **Mac:** double-click `start.command` (first time: right-click → Open). **Windows:** double-click `start.bat`.
   Or from a terminal: `python run.py` (after `pip install -r requirements.txt`).
3. Your browser opens at <http://127.0.0.1:5177>. If a model is missing, Gnosis shows an **Install** button and downloads it for you (chat model ≈ 5 GB, memory model ≈ 270 MB — once).

Step-by-step instructions with troubleshooting: [`docs/USER_GUIDE.md`](docs/USER_GUIDE.md).

Prefer an app icon? `bash packaging/build_mac_app.sh --dmg` builds **Gnosis.app** / **Gnosis.dmg** on a Mac.

## Where is my data?

| OS | Folder |
|---|---|
| macOS | `~/Library/Application Support/Gnosis` |
| Windows | `%LOCALAPPDATA%\Gnosis` |
| Linux | `~/.local/share/gnosis` |

Override with `GNOSIS_HOME`. It is deliberately *outside* Documents/OneDrive/iCloud, which corrupt live databases.

## Project layout

```
run.py                      launcher (port selection, --import-folder)
gnosis/                     Python package
  app.py                    Flask API (127.0.0.1 only)
  context.py                wires components together
  db.py  settings.py  secrets_store.py  paths.py
  llm/        ollama.py (local)   cloud.py (optional)
  memory/     store · ingest · chunker · indexer · retrieval · learn
  chat/       engine (prompting, budgeting, streaming, cloud flow) · store
  privacy/    redact · backup · security
  insights.py
static/                     single-page UI (vanilla JS modules, no CDN, works offline)
tests/                      pytest: 44 backend tests + 13 real-browser tests
docs/                       architecture, user guide, upgrade notes
packaging/                  Mac app/DMG builder, icons
```

## Development

```bash
pip install -r requirements-dev.txt
python -m pytest            # uses a mock Ollama — no models needed
```

Docs: [User guide](docs/USER_GUIDE.md) · [Architecture](docs/ARCHITECTURE.md) · [What changed in v2](docs/REDESIGN.md)
