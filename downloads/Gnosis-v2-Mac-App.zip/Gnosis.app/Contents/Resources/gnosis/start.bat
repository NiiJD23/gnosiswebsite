@echo off
rem Gnosis launcher for Windows - double-click start.bat
cd /d "%~dp0"
set "DATA=%LOCALAPPDATA%\Gnosis"
set "VENV=%DATA%\venv"
if not exist "%DATA%" mkdir "%DATA%"

set "PY="
where py >nul 2>nul && py -3 -c "import sys" >nul 2>nul && set "PY=py -3"
if not defined PY (
  where python >nul 2>nul && python -c "import sys" >nul 2>nul && set "PY=python"
)
if not defined PY (
  echo Python 3 is required. Install it from https://www.python.org/downloads/ ^(tick "Add python.exe to PATH"^) and run this again.
  start https://www.python.org/downloads/
  pause & exit /b 1
)
if not exist "%VENV%\Scripts\python.exe" (
  echo First run: creating a private environment ^(one-off, about a minute^)...
  %PY% -m venv "%VENV%" || (echo Could not create the environment. & pause & exit /b 1)
)
"%VENV%\Scripts\python.exe" -c "import flask, numpy, cryptography, pdfplumber, docx" >nul 2>nul
if errorlevel 1 (
  echo Installing Gnosis components ^(needs internet, one-off^)...
  "%VENV%\Scripts\python.exe" -m pip install --upgrade pip -q
  "%VENV%\Scripts\python.exe" -m pip install -r requirements.txt || (echo Install failed. Check your internet connection. & pause & exit /b 1)
)
"%VENV%\Scripts\python.exe" run.py %*
pause
