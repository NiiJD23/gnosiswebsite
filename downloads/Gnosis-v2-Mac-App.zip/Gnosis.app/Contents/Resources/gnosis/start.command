#!/bin/bash
# Gnosis launcher for macOS — double-click, or run:  bash start.command
cd "$(dirname "$0")" || exit 1
DATA="$HOME/Library/Application Support/Gnosis"
VENV="$DATA/venv"
mkdir -p "$DATA"
if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 is required. Install it from https://www.python.org/downloads/ and run this again."; read -r -p "Press Return…"; exit 1
fi
if [ ! -x "$VENV/bin/python" ]; then
  echo "First run: creating a private environment (one-off, ~1 minute)…"
  python3 -m venv "$VENV" || { echo "Could not create the environment."; read -r -p "Press Return…"; exit 1; }
fi
STAMP="$VENV/.requirements.sha"
HASH=$(shasum requirements.txt | cut -d' ' -f1)
if [ "$(cat "$STAMP" 2>/dev/null)" != "$HASH" ]; then
  "$VENV/bin/python" -m pip install --upgrade pip -q
  "$VENV/bin/python" -m pip install -r requirements.txt || { echo "Install failed."; read -r -p "Press Return…"; exit 1; }
  echo "$HASH" > "$STAMP"
fi
exec "$VENV/bin/python" run.py "$@"
