#!/usr/bin/env python3
"""Start Gnosis:  python run.py   (opens http://127.0.0.1:5177)"""
import argparse
import os
import socket
import sys
import threading
import time
import webbrowser

if sys.version_info < (3, 9):
    sys.exit("Gnosis needs Python 3.9 or newer.")

try:
    from werkzeug.serving import make_server
    from gnosis.app import create_app
    from gnosis.context import Context
    from gnosis import __version__
except ImportError as e:          # pragma: no cover
    sys.exit(f"Missing dependency ({e}).\nRun start.command (Mac) / start.bat (Windows), "
             "or:  python -m pip install -r requirements.txt")


def free_port(start):
    for p in range(start, start + 30):
        with socket.socket() as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                s.bind(("127.0.0.1", p))
                return p
            except OSError:
                continue
    sys.exit("No free port found near %d." % start)


def main():
    ap = argparse.ArgumentParser(description="Gnosis — your private assistant")
    ap.add_argument("--port", type=int, default=int(os.environ.get("GNOSIS_PORT", 5177)))
    ap.add_argument("--home", help="data folder (default: your OS application-data folder)")
    ap.add_argument("--no-browser", action="store_true")
    ap.add_argument("--import-folder", metavar="DIR",
                    help="add every file in DIR (recursively) to Memory, then exit")
    a = ap.parse_args()

    ctx = Context(a.home)
    if a.import_folder:
        n = 0
        for root, _d, files in os.walk(a.import_folder):
            for f in files:
                if f.startswith("."):
                    continue
                with open(os.path.join(root, f), "rb") as fh:
                    ctx.memory.add_file(fh, f)
                n += 1
        ctx.memory.wait_idle(600)
        print(f"Imported {n} file(s) into Memory at {ctx.paths.home}")
        return

    port = free_port(a.port)
    app = create_app(ctx, port=port)
    server = make_server("127.0.0.1", port, app, threaded=True)
    url = f"http://127.0.0.1:{port}"
    print(f"\n  Gnosis {__version__} is running at {url}")
    print(f"  Your data lives in: {ctx.paths.home}")
    print("  Keep this window open while you use Gnosis. Press Ctrl+C to quit.\n")
    if not a.no_browser:
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n  Goodbye.")
    finally:
        ctx.close()


if __name__ == "__main__":
    main()
