import { api } from "./api.js";
import { S, saveSettings, refreshStatus, refreshSettings, refreshConvs, pullModel, emit, on } from "./state.js";
import { h, icon, clear, toast, confirmBox, dialog, fmtDate, switchEl } from "./util.js";

const TABS = [
  ["profile", "Profile", "user"], ["appearance", "Appearance", "palette"], ["models", "Models", "cpu"],
  ["cloud", "Cloud", "cloud"], ["advisory", "Advisory style", "compass"], ["data", "Data & backup", "database"],
];
const field = (label, input, help) => h("div", { class: "field" }, h("label", {}, label), input, help && h("div", { class: "help" }, help));
const saveBar = (run, label = "Save changes") => h("div", { class: "row end" },
  h("button", { class: "btn primary", onclick: async e => { const b = e.currentTarget; b.disabled = true; try { await run(); toast("Saved"); } catch (err) { toast(err.message, { error: true }); } finally { b.disabled = false; } } }, label));

export function createSettings(root) {
  const nav = h("nav", { class: "settings-nav", role: "tablist", "aria-label": "Settings sections" });
  const pane = h("div");
  const st = { tab: "profile" };
  root.append(h("div", { class: "page" }, h("div", { class: "page-in" },
    h("div", { class: "page-head" }, h("div", {}, h("h1", {}, "Settings"), h("p", {}, "Everything here is stored on this computer."))),
    h("div", { class: "settings" }, nav, pane))));

  function show(tab) {
    if (tab && tab !== st.tab) st.draft = null;
    if (tab) st.tab = tab;
    clear(nav).append(...TABS.map(([id, label, ic]) => h("button", { role: "tab", "aria-selected": String(st.tab === id), onclick: () => show(id) }, icon(ic, "sm"), label)));
    clear(pane);
    ({ profile, appearance, models, cloud, advisory, data })[st.tab]();
  }

  // ---- profile ----
  function profile() {
    const p = S.settings.profile;
    const name = h("input", { type: "text", class: "input", value: p.name, placeholder: "How should Gnosis address you?" });
    const role = h("input", { type: "text", class: "input", value: p.role, placeholder: "e.g. Project manager, coach, PhD candidate" });
    const loc = h("input", { type: "text", class: "input", value: p.location, placeholder: "e.g. Belfast, UK" });
    const about = h("textarea", { class: "input", rows: 5, placeholder: "Anything that helps Gnosis help you: your work, goals, how you like to be advised, what matters to you…" }); about.value = p.about;
    const links = [...p.links];
    const linkBox = h("div");
    const drawLinks = () => {
      clear(linkBox);
      links.forEach((l, i) => linkBox.append(h("div", { class: "link-row" },
        h("input", { type: "text", class: "input", value: l.label, placeholder: "LinkedIn, X, GitHub…", "aria-label": "Label", oninput: e => { l.label = e.target.value; } }),
        h("input", { type: "url", class: "input", value: l.url, placeholder: "https://…", "aria-label": "Address", oninput: e => { l.url = e.target.value; } }),
        h("button", { class: "icon-btn", "aria-label": "Remove", onclick: () => { links.splice(i, 1); drawLinks(); } }, icon("x")))));
      linkBox.append(h("button", { class: "btn sm", onclick: () => { links.push({ label: "", url: "" }); drawLinks(); } }, icon("plus", "sm"), "Add account or link"));
    };
    drawLinks();
    pane.append(h("div", { class: "card" }, h("h3", {}, "Your profile"), h("div", { class: "sub" }, "Gnosis reads this at the start of every chat so it always knows who you are."),
      field("Name", name), field("Role", role), field("Location", loc), field("About you", about),
      h("div", { class: "field" }, h("div", { class: "lbl" }, "Social accounts & links"), h("div", { class: "help" }, "Gnosis knows these exist (it can’t log in to them). Add the page itself in Memory if you want its text searchable."), linkBox),
      saveBar(() => saveSettings({ profile: { name: name.value, role: role.value, location: loc.value, about: about.value, links: links.filter(l => l.url.trim()) } }))));
  }

  // ---- appearance ----
  function appearance() {
    const cur = S.settings.appearance.theme;
    const card = (id, label, a, b) => h("button", { class: "theme-card", "aria-pressed": String(cur === id), onclick: async () => { await saveSettings({ appearance: { theme: id } }); show(); } },
      h("div", { class: "sw" }, (() => { const x = h("i"), y = h("i"); x.style.background = a; y.style.background = b; return [x, y]; })()), h("b", {}, label));
    pane.append(h("div", { class: "card" }, h("h3", {}, "Theme"), h("div", { class: "sub" }, "Light, dark, or follow your computer."),
      h("div", { class: "theme-cards" }, card("light", "Light", "#faf9fc", "#26105a"), card("dark", "Dark", "#15112b", "#a995ee"), card("system", "Match system", "linear-gradient(90deg,#faf9fc,#15112b)", "#26105a"))));
  }

  // ---- models ----
  async function models() {
    await refreshStatus();
    const s = S.status, o = s.ollama, m = S.settings.models;
    const chat = h("input", { type: "text", class: "input", value: m.chat, list: "installed-models" });
    const embed = h("input", { type: "text", class: "input", value: m.embed, list: "installed-models" });
    const dl = h("datalist", { id: "installed-models" }, (o.models || []).map(n => h("option", { value: n })));
    const ctx = h("select", {}, [4096, 8192, 16384, 32768].map(v => h("option", { value: v, selected: v === m.num_ctx }, `${v.toLocaleString()} tokens${v === 8192 ? " (recommended)" : ""}`)));
    const temp = h("input", { type: "range", min: 0, max: 1.2, step: 0.1, value: m.temperature });
    const tl = h("span", { class: "help" }, `Creativity ${m.temperature}`);
    temp.addEventListener("input", () => { tl.textContent = "Creativity " + temp.value; });
    const host = h("input", { type: "text", class: "input", value: S.settings.ollama_host || "", placeholder: o.host || "http://127.0.0.1:11434" });
    const bar = h("i"), prog = h("div", { class: "progress", hidden: true }, bar), plabel = h("div", { class: "help" });
    const pullIn = h("input", { type: "text", class: "input", placeholder: "e.g. llama3.1:8b, qwen2.5:7b, mistral" });
    const doPull = async name => {
      name = name.trim(); if (!name) return;
      prog.hidden = false;
      try { await pullModel(name, (pct, label) => { if (pct != null) bar.style.width = pct + "%"; plabel.textContent = label + (pct != null ? ` · ${pct}%` : ""); }); toast(name + " installed"); show("models"); }
      catch (e) { toast(e.message, { error: true }); prog.hidden = true; }
    };
    const ix = s.index;
    pane.append(
      h("div", { class: "card" }, h("h3", {}, "Local AI (Ollama)"),
        h("div", { class: "row" }, h("span", { class: "status-dot " + (o.running ? "ok" : "bad") }), h("b", {}, o.running ? "Running" : "Not running"), h("span", { class: "help" }, o.running ? o.host : o.message)),
        o.running && h("div", { class: "chips" }, (o.models || []).map(n => h("span", { class: "chip" }, n))),
        h("dl", { class: "kv" }, h("dt", {}, "Chat model"), h("dd", {}, o.chat_ok ? "Installed ✓" : "Not installed"), h("dt", {}, "Memory model"), h("dd", {}, o.embed_ok ? "Installed ✓" : "Not installed — keyword search only"),
          h("dt", {}, "Recall index"), h("dd", {}, ix.total ? `${ix.embedded} of ${ix.total} passages${ix.busy ? " · indexing…" : ""}` : "Empty"))),
      h("div", { class: "card" }, h("h3", {}, "Choose models"), dl,
        field("Chat model", chat, "The model that talks with you. Bigger models answer better but need more memory."), field("Memory (embedding) model", embed, "Changing this re-indexes your memory automatically in the background."),
        field("Context window", ctx, "How much text the model can consider at once. Higher uses more RAM."), h("div", { class: "field" }, tl, temp),
        field("Ollama address", host, "Leave empty for the default on this computer."),
        saveBar(() => saveSettings({ models: { chat: chat.value, embed: embed.value, num_ctx: +ctx.value, temperature: +temp.value }, ollama_host: host.value }).then(() => show("models")))),
      h("div", { class: "card" }, h("h3", {}, "Install a model"), h("div", { class: "sub" }, "Downloads through Ollama onto this computer (needs internet once)."),
        h("div", { class: "row" }, h("div", { class: "grow" }, pullIn), h("button", { class: "btn primary", onclick: () => doPull(pullIn.value) }, icon("download", "sm"), "Install")),
        !o.chat_ok && h("div", { class: "row" }, h("button", { class: "btn sm", onclick: () => doPull(m.chat) }, `Install ${m.chat}`)),
        !o.embed_ok && h("div", { class: "row" }, h("button", { class: "btn sm", onclick: () => doPull(m.embed) }, `Install ${m.embed}`)), prog, plabel));
  }

  // ---- cloud ----
  async function cloud() {
    await refreshStatus();
    const c = S.settings.cloud, cs = S.status.cloud;
    const dr = st.draft = st.draft || { enabled: c.enabled, inc: c.include_memory, model: c.model, terms: c.redact_terms.join("\n") };
    let enabled = dr.enabled, inc = dr.inc;
    const key = h("input", { type: "password", class: "input", placeholder: cs.has_key ? `Saved (${cs.key_hint}) — paste a new key to replace` : "sk-ant-…", autocomplete: "off", spellcheck: false });
    const model = h("input", { type: "text", class: "input", value: dr.model, oninput: e => { dr.model = e.target.value; } });
    const terms = h("textarea", { class: "input", rows: 4, placeholder: "One per line — e.g. a client name, project codename, your address", oninput: e => { dr.terms = e.target.value; } }); terms.value = dr.terms;
    const logBox = h("div", { class: "log" });
    api.get("/api/privacy/log").then(r => { clear(logBox); if (!r.items.length) logBox.append(h("div", { class: "help" }, "Nothing has ever been sent to the cloud.")); r.items.forEach(i => logBox.append(h("div", {}, h("time", {}, fmtDate(i.ts)), `Sent to ${i.detail.model} · ${i.detail.characters?.toLocaleString()} characters · ${i.detail.redactions} details hidden`))); }).catch(() => {});
    pane.append(
      h("div", { class: "card" }, h("h3", {}, "Cloud answers (optional)"), h("div", { class: "sub" }, "Gnosis works fully offline. For harder questions you can ask a stronger cloud model — only after you review a redacted preview of exactly what is sent."),
        h("div", { class: "toggle-row" }, h("div", { class: "txt" }, h("b", {}, "Allow cloud answers"), h("span", {}, "Off by default. Nothing is ever sent unless you press “Send to cloud” on a preview.")), switchEl(enabled, v => { enabled = dr.enabled = v; }, "Allow cloud")),
        field("API key", key, `Stored in your ${cs.key_storage === "os-keychain" ? "system keychain" : "encrypted local file"}. Never shown again, never included in backups.`),
        h("div", { class: "row" }, h("button", { class: "btn", onclick: async () => { if (key.value.trim().length < 12) return toast("Paste your API key first.", { error: true }); try { await api.put("/api/secrets/cloud-key", { key: key.value.trim() }); key.value = ""; toast("Key saved securely"); show("cloud"); } catch (e) { toast(e.message, { error: true }); } } }, icon("lock", "sm"), "Save key"),
          cs.has_key && h("button", { class: "btn danger", onclick: async () => { await api.del("/api/secrets/cloud-key"); toast("Key removed"); show("cloud"); } }, "Remove key")),
        field("Cloud model", model)),
      h("div", { class: "card" }, h("h3", {}, "What gets hidden"), h("div", { class: "sub" }, "Emails, phone numbers, postcodes, card and ID numbers, web addresses and your name are always replaced. Add anything else below."),
        field("Always hide these words", terms),
        h("div", { class: "toggle-row" }, h("div", { class: "txt" }, h("b", {}, "Include memory excerpts by default"), h("span", {}, "Lets the cloud model see short, redacted extracts of relevant notes. You can still switch it off per message.")), switchEl(inc, v => { inc = dr.inc = v; }, "Include memory")),
        saveBar(() => saveSettings({ cloud: { enabled, model: model.value, include_memory: inc, redact_terms: terms.value.split("\n").map(t => t.trim()).filter(Boolean) } }).then(() => { st.draft = null; show("cloud"); }))),
      h("div", { class: "card" }, h("h3", {}, "Cloud activity log"), h("div", { class: "sub" }, "Every message that left this computer (metadata only — never the content)."), logBox));
  }

  // ---- advisory ----
  function advisory() {
    const a = S.settings.advisory;
    const style = h("textarea", { class: "input", rows: 6, placeholder: "e.g. Frame trade-offs like a PRINCE2 risk register. Challenge my assumptions. Give me a recommendation first, then the reasoning." }); style.value = a.style;
    const tone = h("select", {}, [["balanced", "Balanced"], ["concise", "Concise"], ["warm", "Warm & encouraging"], ["formal", "Formal"], ["coach", "Coach — asks sharp questions"]].map(([v, l]) => h("option", { value: v, selected: v === a.tone }, l)));
    const pri = h("input", { type: "text", class: "input", value: a.priorities.join(", "), placeholder: "Career growth, Family time, Financial security" });
    pane.append(h("div", { class: "card" }, h("h3", {}, "How Gnosis advises you"), h("div", { class: "sub" }, "Written by you, applied to every answer — explicit rather than guessed."),
      field("Your decision style", style), field("Tone", tone), field("Priorities when weighing options", pri, "Comma-separated, most important first."),
      saveBar(() => saveSettings({ advisory: { style: style.value, tone: tone.value, priorities: pri.value.split(",").map(t => t.trim()).filter(Boolean) } }))));
  }

  // ---- data ----
  async function data() {
    await refreshStatus();
    const pw = h("input", { type: "password", class: "input", placeholder: "At least 8 characters", autocomplete: "new-password" });
    const pw2 = h("input", { type: "password", class: "input", placeholder: "Repeat password", autocomplete: "new-password" });
    const ipw = h("input", { type: "password", class: "input", placeholder: "Backup password", autocomplete: "off" });
    const file = h("input", { type: "file", accept: ".gnosis", class: "input" });
    pane.append(
      h("div", { class: "card" }, h("h3", {}, "Move to a new computer"), h("div", { class: "sub" }, "One encrypted file with all your memories, files, chats and settings."),
        h("div", { class: "notice" }, icon("alert"), h("div", {}, h("b", {}, "There is no password recovery."), " If you forget the password, the backup can’t be opened by anyone — including us.")),
        field("Password", pw), field("Repeat password", pw2),
        h("div", { class: "row" }, h("button", { class: "btn primary", onclick: async e => {
          if (pw.value !== pw2.value) return toast("The passwords don’t match.", { error: true });
          const b = e.currentTarget; b.disabled = true;
          try { await api.download("/api/backup/export", "gnosis-backup.gnosis", { password: pw.value }); toast("Backup downloaded — keep it somewhere safe."); pw.value = pw2.value = ""; } catch (err) { toast(err.message, { error: true }); } finally { b.disabled = false; } } }, icon("download", "sm"), "Export encrypted backup"))),
      h("div", { class: "card" }, h("h3", {}, "Restore from a backup"), h("div", { class: "sub" }, "Replaces what is on this computer with the backup. A safety copy of the current data is kept first."),
        field("Backup file (.gnosis)", file), field("Password", ipw),
        h("div", { class: "row" }, h("button", { class: "btn", onclick: async e => {
          if (!file.files[0]) return toast("Choose a backup file first.", { error: true });
          if (!await confirmBox({ title: "Replace current data?", message: "Everything now in Gnosis on this computer will be replaced by the backup. A safety copy is kept.", confirm: "Restore backup", danger: true })) return;
          const fd = new FormData(); fd.append("file", file.files[0]); fd.append("password", ipw.value);
          const b = e.currentTarget; b.disabled = true;
          try { await api.upload("/api/backup/import", fd); toast("Backup restored."); await refreshSettings(); await refreshConvs(); emit("new-chat"); emit("memory-changed"); show("data"); } catch (err) { toast(err.message, { error: true }); } finally { b.disabled = false; } } }, icon("upload", "sm"), "Restore backup"))),
      h("div", { class: "card" }, h("h3", {}, "Where your data lives"), h("dl", { class: "kv" }, h("dt", {}, "Folder"), h("dd", {}, S.status.home), h("dt", {}, "Secrets"), h("dd", {}, S.status.cloud.key_storage === "os-keychain" ? "System keychain" : "Encrypted file"), h("dt", {}, "Version"), h("dd", {}, S.status.version))),
      h("div", { class: "card" }, h("h3", {}, "Danger zone"),
        h("div", { class: "row" },
          h("button", { class: "btn danger", onclick: async () => { if (!await confirmBox({ title: "Delete all chats?", message: "Every conversation will be permanently deleted. Your memories stay.", confirm: "Delete all chats", danger: true })) return; await api.del("/api/conversations", { confirm: "DELETE" }); await refreshConvs(); emit("new-chat"); toast("All chats deleted"); } }, icon("trash", "sm"), "Delete all chats"),
          h("button", { class: "btn danger", onclick: wipe }, icon("trash", "sm"), "Erase everything"))));
  }
  function wipe() {
    const inp = h("input", { type: "text", class: "input", placeholder: "Type DELETE", autocomplete: "off" });
    dialog({ title: "Erase everything?", body: h("div", {}, h("p", { class: "prose" }, "This permanently deletes all memories, files, chats and suggestions from this computer. Settings and your API key are kept. Export a backup first if you might want them."), field("Type DELETE to confirm", inp)),
      actions: [{ label: "Cancel", value: "" }, { label: "Erase everything", kind: "danger", run: async () => { if (inp.value !== "DELETE") throw new Error("Type DELETE exactly to confirm."); await api.post("/api/data/wipe", { confirm: "DELETE" }); await refreshConvs(); emit("new-chat"); emit("memory-changed"); toast("Everything was erased."); } }] });
  }

  on("settings", () => { if (!root.hidden && st.tab === "appearance") show(); });
  return { show };
}
