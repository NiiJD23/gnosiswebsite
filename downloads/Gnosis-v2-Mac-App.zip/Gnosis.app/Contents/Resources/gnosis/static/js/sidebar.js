import { api } from "./api.js";
import { S, on, emit, refreshConvs, displayName } from "./state.js";
import { h, icon, clear, group, menu, promptBox, confirmBox, toast, debounce } from "./util.js";

export function createSidebar(root, { go, toggle }) {
  let collapsedRecents = false, q = "";
  try { collapsedRecents = localStorage.getItem("gnosis-recents") === "0"; } catch { /* ignore */ }

  const brand = h("div", { class: "brand" }, h("img", { src: "/static/favicon.svg", alt: "" }), h("span", { class: "wordmark" }, "Gnosis"));
  const head = h("div", { class: "side-head" }, brand, h("span", { class: "grow" }),
    h("button", { class: "icon-btn", "aria-label": "Hide sidebar", title: "Hide sidebar", onclick: toggle }, icon("panel")));
  const newBtn = h("button", { class: "new-chat", onclick: () => { emit("new-chat"); go("chat"); emit("focus-composer"); } }, icon("plus"), "New chat");
  const navBox = h("nav", { class: "nav", "aria-label": "Main" });
  const search = h("input", { type: "search", placeholder: "Search chats", "aria-label": "Search chats", oninput: debounce(async e => { q = e.target.value.trim(); await refreshConvs(q); }, 220) });
  const list = h("div", { class: "recents" }, h("div", { class: "search" }, icon("search", "sm"), search), h("div", { id: "chat-list" }));
  const recHead = h("div", { class: "recents-head" }, "Chats", h("button", { "aria-expanded": String(!collapsedRecents), onclick: () => { collapsedRecents = !collapsedRecents; try { localStorage.setItem("gnosis-recents", collapsedRecents ? "0" : "1"); } catch { /* ignore */ } renderRecents(); } }));
  const foot = h("div", { class: "side-foot" });
  root.append(head, newBtn, navBox, recHead, list, foot);

  const NAV = [["chat", "Chat", "chat"], ["memory", "Memory", "memory"], ["insights", "Insights", "insights"], ["settings", "Settings", "settings"]];
  function renderNav() {
    clear(navBox).append(...NAV.map(([id, label, ic]) => {
      const sug = id === "memory" ? (S.status?.suggestions || 0) : 0;
      return h("button", { "aria-current": S.view === id ? "page" : null, onclick: () => go(id) }, icon(ic), label,
        sug ? h("span", { class: "dot", title: `${sug} suggestion${sug > 1 ? "s" : ""} to review` }, sug) : (id === "memory" && S.status?.memories?.total ? h("span", { class: "count" }, S.status.memories.total) : null));
    }));
  }
  function renderRecents() {
    list.classList.toggle("collapsed", collapsedRecents);
    const btn = recHead.querySelector("button");
    clear(btn).append(icon(collapsedRecents ? "right" : "down", "sm"), collapsedRecents ? "Show" : "Hide");
    btn.setAttribute("aria-expanded", String(!collapsedRecents));
    const box = list.querySelector("#chat-list"); clear(box);
    if (!S.convs.length) { box.append(h("div", { class: "empty-note" }, q ? "No chats match." : "Your conversations will appear here.")); return; }
    let lastG = null;
    const pinned = S.convs.filter(c => c.pinned);
    const rest = S.convs.filter(c => !c.pinned);
    if (pinned.length) { box.append(h("div", { class: "group-label" }, "Pinned"), ...pinned.map(item)); }
    rest.forEach(c => { const g = group(c.updated); if (g !== lastG) { box.append(h("div", { class: "group-label" }, g)); lastG = g; } box.append(item(c)); });
  }
  function item(c) {
    const more = h("button", { class: "icon-btn sm more", "aria-label": "Options for " + c.title, onclick: e => { e.stopPropagation(); menu(e.currentTarget, [
      { label: "Rename", icon: "edit", run: async () => { const t = await promptBox({ title: "Rename chat", label: "Chat name", value: c.title }); if (t) { try { await api.patch("/api/conversations/" + c.id, { title: t }); refreshConvs(q); } catch (err) { toast(err.message, { error: true }); } } } },
      { label: c.pinned ? "Unpin" : "Pin to top", icon: "pin", run: async () => { await api.patch("/api/conversations/" + c.id, { pinned: !c.pinned }); refreshConvs(q); } },
      { label: "Clear messages", icon: "refresh", run: async () => { if (await confirmBox({ title: "Clear this chat?", message: "Messages are removed; the chat stays.", confirm: "Clear messages", danger: true })) { await api.post(`/api/conversations/${c.id}/clear`); emit("conv-cleared", c.id); refreshConvs(q); } } },
      "-",
      { label: "Delete", icon: "trash", danger: true, run: async () => { if (await confirmBox({ title: "Delete this chat?", message: "This permanently removes the chat from your device.", confirm: "Delete chat", danger: true })) { try { await api.del("/api/conversations/" + c.id); } catch (err) { if (err.status !== 404) return toast(err.message, { error: true }); } emit("conv-deleted", c.id); refreshConvs(q); } } },
    ]); } }, icon("more", "sm"));
    return h("div", { class: "chat-item" + (c.id === S.convId ? " active" : ""), tabindex: 0, role: "button", title: c.title,
      onclick: () => { emit("open-conv", c.id); if (innerWidth <= 860) toggle(); }, onkeydown: e => { if (e.key === "Enter") emit("open-conv", c.id); } },
      c.pinned && h("span", { class: "pin" }, icon("pin", "sm")), h("span", { class: "t" }, c.title), more);
  }
  function renderFoot() {
    const name = S.settings?.profile?.name || "";
    const o = S.status?.ollama;
    const state = S.offline ? ["bad", "Gnosis is not responding"] : !o ? ["warn", "Checking…"] : !o.running ? ["warn", "Ollama is not running"] : !o.chat_ok ? ["warn", "Chat model not installed"] : ["ok", "Private · running on this device"];
    clear(foot).append(
      h("div", { class: "privacy-pill" }, h("span", { class: "status-dot " + state[0] }), state[1]),
      h("button", { class: "profile-chip", onclick: () => go("settings", { tab: "profile" }) },
        h("span", { class: "avatar" }, (name || "You").trim()[0].toUpperCase()),
        h("span", { class: "who" }, h("b", {}, name || "Set up your profile"), h("span", {}, S.settings?.profile?.role || "Profile & settings"))));
  }
  const all = () => { renderNav(); renderRecents(); renderFoot(); };
  on("convs", renderRecents); on("status", () => { renderNav(); renderFoot(); }); on("settings", renderFoot);
  on("current", renderRecents); on("view", renderNav);
  all();
  return { render: all };
}
