import { api } from "./api.js";
import { on, emit } from "./state.js";
import { h, icon, clear, md, toast, fmtDate } from "./util.js";
import { openMemory } from "./memory.js";

export function createInsights(root) {
  const page = h("div", { class: "page-in" });
  root.append(h("div", { class: "page" }, page));

  async function show() {
    let d;
    try { d = await api.get("/api/insights"); } catch (e) { return toast(e.message, { error: true }); }
    clear(page);
    const m = d.memories;
    const max = Math.max(1, ...d.activity.map(a => a.n));
    const bars = h("div", { class: "bars", role: "img", "aria-label": "Activity over the last 28 days" });
    d.activity.forEach(a => { const i = h("i", { class: a.n ? "" : "zero", title: `${a.day}: ${a.n}` }); i.style.height = Math.max(3, Math.round(a.n / max * 100)) + "%"; bars.append(i); });
    const out = h("div", { class: "prose" });
    const reflectBtn = h("button", { class: "btn primary", onclick: async e => {
      const b = e.currentTarget; b.disabled = true; b.textContent = "Thinking…";
      try { const r = await api.post("/api/insights/reflect"); out.innerHTML = md(r.text); } catch (err) { toast(err.message, { error: true }); }
      b.disabled = false; clear(b).append(icon("sparkle", "sm"), "Reflect again");
    } }, icon("sparkle", "sm"), "Reflect on my recent notes");
    const ix = d.index;
    page.append(
      h("div", { class: "page-head" }, h("div", {}, h("h1", {}, "Insights"), h("p", {}, "Patterns Gnosis can see in your own words — worked out on this computer, never sent anywhere."))),
      h("div", { class: "stats" },
        stat(m.total, "memories"), stat(m.note, "notes"), stat(m.file, "files"), stat(m.link, "links"), stat(d.conversations, "chats")),
      h("div", { class: "grid" },
        h("div", { class: "card" }, h("h3", {}, "Activity"), h("div", { class: "sub" }, "Notes saved and messages sent, last 28 days"), bars),
        h("div", { class: "card" }, h("h3", {}, "What keeps coming up"), h("div", { class: "sub" }, "Frequent words across your notes and messages"),
          d.topics.length ? h("div", { class: "chips" }, d.topics.map(t => h("span", { class: "chip accent" }, `${t.term} · ${t.count}`))) : h("div", { class: "help" }, "Topics appear once you’ve added a few notes or chatted a bit.")),
        h("div", { class: "card" }, h("h3", {}, "Recently added"), h("div", { class: "sub" }, "Your latest memories"),
          d.recent.length ? h("div", { class: "log" }, d.recent.map(r => h("div", {}, h("time", {}, fmtDate(r.updated)), h("a", { href: "#", onclick: e => { e.preventDefault(); openMemory(r.id); } }, r.title)))) : h("div", { class: "help" }, "Nothing yet.")),
        h("div", { class: "card" }, h("h3", {}, "Privacy"), h("div", { class: "sub" }, "What has left this computer"),
          h("dl", { class: "kv" },
            h("dt", {}, "Cloud messages"), h("dd", {}, d.privacy.cloud_sends ? `${d.privacy.cloud_sends} sent (last ${fmtDate(d.privacy.last_cloud_send)})` : "None — everything stayed on this device"),
            h("dt", {}, "Recall index"), h("dd", {}, ix.total ? `${ix.embedded}/${ix.total} passages indexed${ix.error ? " · " + ix.error : ""}` : "Empty"),
            h("dt", {}, "Search"), h("dd", {}, ix.pending ? "Keywords now; meaning-based once indexing finishes" : "Keywords + meaning (hybrid)")))),
      h("div", { class: "card", style: null }, h("div", { class: "row" }, h("div", { class: "grow" }, h("h3", {}, "Reflection"), h("div", { class: "sub" }, "Gnosis re-reads your recent notes and messages and suggests themes and open loops.")), reflectBtn), out));
  }
  function stat(n, label) { return h("div", { class: "card stat" }, h("b", {}, n ?? 0), h("span", {}, label)); }
  on("memory-changed", () => { if (!root.hidden) show(); });
  return { show };
}
