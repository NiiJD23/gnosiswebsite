// Gnosis — bootstrap, layout and routing.
import { api } from "./api.js";
import { S, on, emit, refreshStatus, refreshSettings, refreshConvs, saveSettings } from "./state.js";
import { h, toast } from "./util.js";
import { createSidebar } from "./sidebar.js";
import { createChat } from "./chat.js";
import { createMemoryView } from "./memory.js";
import { createInsights } from "./insights.js";
import { createSettings } from "./settings.js";

const app = document.getElementById("app");

async function boot() {
  try { await Promise.all([refreshSettings(), refreshStatus()]); }
  catch (e) {
    app.append(h("div", { class: "hero" }, h("h1", {}, "Gnosis can’t start"), h("p", {}, e.message), h("button", { class: "btn primary", onclick: () => location.reload() }, "Reload")));
    return;
  }
  await refreshConvs();

  const sidebarEl = h("aside", { id: "sidebar", "aria-label": "Sidebar" });
  const main = h("main", { id: "main" });
  const scrim = h("div", { class: "scrim", onclick: toggleSidebar });
  app.append(sidebarEl, main, scrim);
  if (innerWidth <= 860 || localStorage.getItem("gnosis-side") === "0") app.classList.add("side-closed");

  function toggleSidebar() {
    app.classList.toggle("side-closed");
    try { localStorage.setItem("gnosis-side", app.classList.contains("side-closed") ? "0" : "1"); } catch { /* ignore */ }
  }

  const sections = {};
  for (const id of ["chat", "memory", "insights", "settings"]) {
    sections[id] = h("section", { class: "view", hidden: id !== "chat" });
    main.append(sections[id]);
  }
  const opener = h("button", { class: "icon-btn side-open", "aria-label": "Show sidebar", title: "Show sidebar", onclick: toggleSidebar });
  main.append(opener);

  const chat = createChat(sections.chat, { toggleSidebar });
  const views = { memory: createMemoryView(sections.memory), insights: createInsights(sections.insights), settings: createSettings(sections.settings) };
  import("./util.js").then(u => opener.append(u.icon("panel")));

  function go(view, opts = {}) {
    if (!sections[view]) view = "chat";
    S.view = view;
    for (const [id, el] of Object.entries(sections)) el.hidden = id !== view;
    app.classList.toggle("view-chat", view === "chat");
    if (view !== "chat" && views[view]) views[view].show(opts.tab);
    emit("view", view);
    document.title = view === "chat" ? "Gnosis" : "Gnosis · " + view[0].toUpperCase() + view.slice(1);
  }
  const side = createSidebar(sidebarEl, { go: (v, o) => go(v, o), toggle: toggleSidebar });
  on("go", d => go(d.view, d));
  go("chat");

  // keep status fresh (cheap): every 20 s while the tab is visible
  setInterval(() => { if (!document.hidden) refreshStatus(); }, 20000);
  document.addEventListener("visibilitychange", () => { if (!document.hidden) refreshStatus(); });
  document.addEventListener("keydown", e => {
    const mod = e.metaKey || e.ctrlKey;
    if (mod && e.key.toLowerCase() === "k") { e.preventDefault(); emit("new-chat"); go("chat"); emit("focus-composer"); }
    if (mod && e.key === "\\") { e.preventDefault(); toggleSidebar(); }
  });
  window.__gnosis = { go, chat, S };      // handy for debugging in the console
}

boot();
