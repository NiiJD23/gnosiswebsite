// Shared app state + tiny event bus.
import { api } from "./api.js";

export const S = { status: null, settings: null, convs: [], convId: null, view: "chat" };

const bus = new EventTarget();
export const on = (name, fn) => bus.addEventListener(name, e => fn(e.detail));
export const emit = (name, detail) => bus.dispatchEvent(new CustomEvent(name, { detail }));

export async function refreshStatus() {
  try { S.status = await api.get("/api/status"); S.offline = false; }
  catch (e) { S.offline = true; S.statusError = e.message; }
  emit("status", S.status);
  return S.status;
}
export async function refreshSettings() {
  S.settings = await api.get("/api/settings");
  applyTheme(S.settings.appearance.theme);
  emit("settings", S.settings);
  return S.settings;
}
export async function saveSettings(patch) {
  S.settings = await api.put("/api/settings", patch);
  applyTheme(S.settings.appearance.theme);
  emit("settings", S.settings);
  refreshStatus();
  return S.settings;
}
export async function refreshConvs(q) {
  S.convs = await api.get("/api/conversations" + (q ? "?q=" + encodeURIComponent(q) : ""));
  emit("convs", S.convs);
  return S.convs;
}

export function applyTheme(t) {
  const root = document.documentElement;
  if (t === "light" || t === "dark") root.setAttribute("data-theme", t);
  else root.removeAttribute("data-theme");
  try { t === "system" ? localStorage.removeItem("gnosis-theme") : localStorage.setItem("gnosis-theme", t); } catch { /* private mode */ }
}

/** Download a model through Ollama, reporting 0-100 progress. */
export async function pullModel(model, onProgress) {
  let last = "";
  await api.stream("/api/models/pull", { model }, ev => {
    if (ev.error) throw new Error(ev.error);
    last = ev.status || last;
    if (ev.total) onProgress && onProgress(Math.round((ev.completed || 0) / ev.total * 100), last);
    else onProgress && onProgress(null, last);
  });
  await refreshStatus();
}

export function displayName() { return (S.settings?.profile?.name || "").split(" ")[0]; }
