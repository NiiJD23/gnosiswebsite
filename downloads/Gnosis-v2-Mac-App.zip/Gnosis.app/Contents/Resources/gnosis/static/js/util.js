// DOM helpers, icons, safe markdown, dialogs, toasts. No innerHTML with untrusted text.

export function h(tag, props, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(props || {})) {
    if (v == null || v === false) continue;
    if (k === "class") el.className = v;
    else if (k.startsWith("on") && typeof v === "function") el.addEventListener(k.slice(2).toLowerCase(), v);
    else if (k === "data") Object.assign(el.dataset, v);
    else if (k in el && k !== "list" && k !== "type" && k !== "form") el[k] = v;
    else el.setAttribute(k, v === true ? "" : v);
  }
  append(el, kids);
  return el;
}
function append(el, kids) {
  for (const k of kids.flat(Infinity)) {
    if (k == null || k === false) continue;
    el.append(k instanceof Node ? k : document.createTextNode(String(k)));
  }
}
export const $ = (s, r = document) => r.querySelector(s);
export const $$ = (s, r = document) => [...r.querySelectorAll(s)];
export function clear(el) { while (el.firstChild) el.removeChild(el.firstChild); return el; }

// ---- icons (Lucide-style strokes) ---------------------------------------
const P = {
  plus: "M12 5v14M5 12h14",
  chat: "M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12z",
  memory: "M12 3a6 6 0 0 0-6 6c0 1.5.5 2.5 1.2 3.5.7 1 .8 1.700.8 2.500V16h8v-1c0-.8.1-1.500.8-2.500C17.500 11.500 18 10.500 18 9a6 6 0 0 0-6-6zM9.500 19h5M10.500 22h3",
  insights: "M3 3v18h18M7 15l4-5 3 3 5-7",
  settings: "M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM19.400 15a1.700 1.700 0 0 0 .3 1.800l.1.100a2 2 0 1 1-2.800 2.800l-.1-.1a1.700 1.700 0 0 0-1.800-.3 1.700 1.700 0 0 0-1 1.500V21a2 2 0 1 1-4 0v-.1a1.700 1.700 0 0 0-1.100-1.500 1.700 1.700 0 0 0-1.800.3l-.1.1a2 2 0 1 1-2.800-2.800l.1-.1a1.700 1.700 0 0 0 .3-1.800 1.700 1.700 0 0 0-1.500-1H3a2 2 0 1 1 0-4h.1a1.700 1.700 0 0 0 1.500-1.100 1.700 1.700 0 0 0-.3-1.800l-.1-.1a2 2 0 1 1 2.800-2.800l.1.1a1.700 1.700 0 0 0 1.800.3H9a1.700 1.700 0 0 0 1-1.500V3a2 2 0 1 1 4 0v.1a1.700 1.700 0 0 0 1 1.500 1.700 1.700 0 0 0 1.800-.3l.1-.1a2 2 0 1 1 2.800 2.800l-.1.100a1.700 1.700 0 0 0-.3 1.800V9a1.700 1.700 0 0 0 1.500 1H21a2 2 0 1 1 0 4h-.1a1.700 1.700 0 0 0-1.500 1z",
  search: "M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16zM21 21l-4.300-4.300",
  clip: "M21.400 11.600l-9.200 9.200a6 6 0 0 1-8.500-8.500l9.200-9.200a4 4 0 0 1 5.700 5.700l-9.200 9.200a2 2 0 0 1-2.800-2.800l8.500-8.500",
  send: "M12 19V5M5 12l7-7 7 7",
  stop: "M6 6h12v12H6z",
  copy: "M9 9h11v11H9zM5 15H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v1",
  refresh: "M21 12a9 9 0 0 1-15.500 6.200M3 12A9 9 0 0 1 18.500 5.800M18 2v4h-4M6 22v-4h4",
  trash: "M3 6h18M8 6V4a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6M10 11v6M14 11v6",
  edit: "M12 20h9M16.500 3.500a2.100 2.100 0 0 1 3 3L7 19l-4 1 1-4z",
  download: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3",
  upload: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12",
  file: "M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8zM14 2v6h6M8 13h8M8 17h5",
  link: "M10 13a5 5 0 0 0 7.500.5l3-3a5 5 0 0 0-7-7l-1.700 1.700M14 11a5 5 0 0 0-7.500-.5l-3 3a5 5 0 0 0 7 7l1.700-1.700",
  note: "M4 4h16v16H4zM8 9h8M8 13h8M8 17h4",
  x: "M18 6L6 18M6 6l12 12",
  down: "M6 9l6 6 6-6",
  right: "M9 6l6 6-6 6",
  panel: "M3 4h18v16H3zM9 4v16",
  more: "M5 12h.01M12 12h.01M19 12h.01",
  sun: "M12 17a5 5 0 1 0 0-10 5 5 0 0 0 0 10zM12 1v2M12 21v2M4.200 4.200l1.400 1.400M18.400 18.400l1.400 1.400M1 12h2M21 12h2M4.200 19.800l1.400-1.400M18.400 5.600l1.400-1.400",
  moon: "M21 12.800A9 9 0 1 1 11.200 3a7 7 0 0 0 9.800 9.800z",
  shield: "M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10zM9 12l2 2 4-4",
  check: "M20 6L9 17l-5-5",
  pin: "M12 17v5M9 3h6l-1 7 3 3v2H7v-2l3-3z",
  sparkle: "M12 3l1.900 5.100L19 10l-5.100 1.900L12 17l-1.900-5.100L5 10l5.100-1.900zM19 3v4M21 5h-4",
  alert: "M12 9v4M12 17h.01M10.300 3.900L1.800 18a2 2 0 0 0 1.700 3h17a2 2 0 0 0 1.700-3L13.700 3.900a2 2 0 0 0-3.400 0z",
  user: "M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2M12 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8z",
  palette: "M12 22a10 10 0 1 1 10-10c0 2.500-2 3-4 3h-2a2 2 0 0 0-1.500 3.300A2 2 0 0 1 12 22zM7.500 11h.01M10 7h.01M15 7h.01M17.500 11h.01",
  cpu: "M6 6h12v12H6zM9 9h6v6H9zM9 2v4M15 2v4M9 18v4M15 18v4M2 9h4M2 15h4M18 9h4M18 15h4",
  cloud: "M18 10h-1.300A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z",
  compass: "M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20zM16.200 7.800l-2.100 6.300-6.300 2.100 2.100-6.300z",
  database: "M12 8c4.400 0 8-1.300 8-3s-3.600-3-8-3-8 1.300-8 3 3.600 3 8 3zM4 5v14c0 1.700 3.600 3 8 3s8-1.300 8-3V5M4 12c0 1.700 3.600 3 8 3s8-1.300 8-3",
  lock: "M5 11h14v10H5zM8 11V7a4 4 0 0 1 8 0v4",
  loader: "M21 12a9 9 0 1 1-6.200-8.600",
};
export function icon(name, cls = "") {
  const NS = "http://www.w3.org/2000/svg";
  const s = document.createElementNS(NS, "svg");
  s.setAttribute("viewBox", "0 0 24 24");
  s.setAttribute("class", "i " + cls);
  s.setAttribute("aria-hidden", "true");
  const p = document.createElementNS(NS, "path");
  p.setAttribute("d", P[name] || P.sparkle);
  s.append(p);
  return s;
}

// ---- formatting -----------------------------------------------------------
export function fmtDate(ts) {
  if (!ts) return "";
  const d = new Date(ts * 1000), now = new Date();
  const same = d.toDateString() === now.toDateString();
  if (same) return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  const opts = d.getFullYear() === now.getFullYear() ? { day: "numeric", month: "short" } : { day: "numeric", month: "short", year: "numeric" };
  return d.toLocaleDateString([], opts);
}
export function fmtSize(n) {
  if (!n) return "";
  const u = ["B", "KB", "MB", "GB"]; let i = 0;
  while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; }
  return (i ? n.toFixed(n < 10 ? 1 : 0) : n) + " " + u[i];
}
export function group(ts) {
  const d = new Date(ts * 1000), now = new Date();
  const day = x => new Date(x.getFullYear(), x.getMonth(), x.getDate());
  const diff = Math.round((day(now) - day(d)) / 86400000);
  if (diff <= 0) return "Today";
  if (diff === 1) return "Yesterday";
  if (diff < 8) return "Previous 7 days";
  if (diff < 31) return "Previous 30 days";
  return "Older";
}
export function greeting(name) {
  const hr = new Date().getHours();
  const p = hr < 5 ? "Working late" : hr < 12 ? "Good morning" : hr < 18 ? "Good afternoon" : "Good evening";
  return name ? `${p}, ${name}` : p;
}
export const debounce = (fn, ms = 250) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };

// ---- safe markdown ---------------------------------------------------------
const esc = s => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

function inline(s, stash) {
  s = s.replace(/`([^`\n]+)`/g, (_, c) => stash(`<code>${c}</code>`));
  s = s.replace(/\[M(\d{1,2})\]/g, (_, n) => stash(`<button class="cite" data-n="${n}" title="Show source ${n}">${n}</button>`));
  s = s.replace(/\[([^\]\n]+)\]\((https?:\/\/[^\s)]+)\)/g, (_, t, u) =>
    stash(`<a href="${u}" target="_blank" rel="noopener noreferrer">${t}</a>`));
  s = s.replace(/(^|[\s(])(https?:\/\/[^\s<)]+[^\s<).,;:!?])/g, (_, p, u) =>
    p + stash(`<a href="${u}" target="_blank" rel="noopener noreferrer">${u}</a>`));
  s = s.replace(/\*\*([^*\n]+)\*\*/g, "<strong>$1</strong>").replace(/__([^_\n]+)__/g, "<strong>$1</strong>");
  s = s.replace(/(^|[^*\w])\*([^*\n]+)\*(?!\w)/g, "$1<em>$2</em>").replace(/(^|[^_\w])_([^_\n]+)_(?!\w)/g, "$1<em>$2</em>");
  return s;
}

export function md(src) {
  const stash = [];
  const keep = html => { stash.push(html); return `\u0000${stash.length - 1}\u0000`; };
  let text = esc(String(src ?? "").replace(/\r\n?/g, "\n"));
  // fenced code (also handle an unterminated fence while streaming)
  text = text.replace(/```([\w+-]*)\n([\s\S]*?)(```|$)/g, (_, lang, code) => keep(`<pre><code>${code.replace(/\n$/, "")}</code></pre>`));
  const lines = text.split("\n");
  const out = [];
  let i = 0;
  const flushPara = buf => { if (buf.length) out.push(`<p>${inline(buf.join("<br>"), keep)}</p>`); buf.length = 0; };
  const para = [];
  while (i < lines.length) {
    const ln = lines[i];
    let m;
    if (/^\s*$/.test(ln)) { flushPara(para); i++; continue; }
    if (/^\u0000\d+\u0000$/.test(ln.trim())) { flushPara(para); out.push(ln.trim()); i++; continue; }
    if ((m = ln.match(/^(#{1,4})\s+(.*)$/))) { flushPara(para); out.push(`<h${m[1].length}>${inline(m[2], keep)}</h${m[1].length}>`); i++; continue; }
    if (/^\s*([-*_])(\s*\1){2,}\s*$/.test(ln)) { flushPara(para); out.push("<hr>"); i++; continue; }
    if (/^&gt;\s?/.test(ln)) {
      flushPara(para); const q = [];
      while (i < lines.length && /^&gt;\s?/.test(lines[i])) q.push(lines[i++].replace(/^&gt;\s?/, ""));
      out.push(`<blockquote>${inline(q.join("<br>"), keep)}</blockquote>`); continue;
    }
    if (/^\s*([-*+•])\s+/.test(ln) || /^\s*\d+[.)]\s+/.test(ln)) {
      flushPara(para);
      const ordered = /^\s*\d+[.)]\s+/.test(ln);
      const re = ordered ? /^\s*\d+[.)]\s+(.*)$/ : /^\s*[-*+•]\s+(.*)$/;
      const items = [];
      while (i < lines.length && re.test(lines[i])) {
        let item = lines[i++].match(re)[1];
        while (i < lines.length && /^\s{2,}\S/.test(lines[i]) && !re.test(lines[i])) item += "<br>" + lines[i++].trim();
        items.push(`<li>${inline(item, keep)}</li>`);
      }
      out.push(`<${ordered ? "ol" : "ul"}>${items.join("")}</${ordered ? "ol" : "ul"}>`); continue;
    }
    if (/^\s*\|.*\|\s*$/.test(ln) && i + 1 < lines.length && /^\s*\|?\s*:?-{2,}/.test(lines[i + 1])) {
      flushPara(para);
      const cells = r => r.trim().replace(/^\||\|$/g, "").split("|").map(c => inline(c.trim(), keep));
      const head = cells(ln); i += 2; const rows = [];
      while (i < lines.length && /^\s*\|.*\|\s*$/.test(lines[i])) rows.push(cells(lines[i++]));
      out.push(`<table><thead><tr>${head.map(c => `<th>${c}</th>`).join("")}</tr></thead><tbody>${rows.map(r => `<tr>${r.map(c => `<td>${c}</td>`).join("")}</tr>`).join("")}</tbody></table>`);
      continue;
    }
    para.push(ln); i++;
  }
  flushPara(para);
  let html = out.join("");
  for (let n = 0; n < 4 && html.includes("\u0000"); n++)
    html = html.replace(/\u0000(\d+)\u0000/g, (_, k) => stash[+k]);
  return html;
}

// ---- toasts ------------------------------------------------------------------
export function toast(msg, { error = false, action = null, ms = 4200 } = {}) {
  const box = document.getElementById("toasts");
  const t = h("div", { class: "toast" + (error ? " err" : "") }, msg,
    action && h("button", { onclick: () => { action.run(); t.remove(); } }, action.label));
  box.append(t);
  setTimeout(() => t.remove(), error ? ms + 2500 : ms);
}

// ---- dialogs -----------------------------------------------------------------
export function dialog({ title, body, actions = [], wide = false, onClose }) {
  const dlg = h("dialog", { class: wide ? "wide" : "" });
  const close = v => { dlg.close(v); };
  const foot = h("div", { class: "dlg-foot" }, ...actions.map(a =>
    a === "spacer" ? h("span", { class: "grow" }) :
    h("button", { class: "btn " + (a.kind || ""), disabled: !!a.disabled, id: a.id,
      onclick: async e => {
        if (!a.run) return close(a.value);
        const btn = e.currentTarget; btn.disabled = true;
        try { const r = await a.run(dlg, close); if (r !== false && a.close !== false) close(r); }
        catch (err) { toast(err.message || String(err), { error: true }); }
        finally { btn.disabled = false; }
      } }, a.icon && icon(a.icon, "sm"), a.label)));
  dlg.append(h("div", { class: "dlg" },
    h("div", { class: "dlg-head" }, h("h2", {}, title),
      h("button", { class: "icon-btn sm", "aria-label": "Close", onclick: () => close() }, icon("x"))),
    h("div", { class: "dlg-body" }, body), actions.length ? foot : null));
  dlg.addEventListener("close", () => { dlg.remove(); onClose && onClose(dlg.returnValue); });
  dlg.addEventListener("click", e => { if (e.target === dlg) close(); });
  document.body.append(dlg);
  dlg.showModal();
  return dlg;
}
export function confirmBox({ title, message, confirm = "Confirm", danger = false }) {
  return new Promise(res => {
    dialog({ title, body: h("p", { class: "prose" }, message),
      actions: [{ label: "Cancel", value: "no" }, { label: confirm, kind: danger ? "danger" : "primary", value: "yes" }],
      onClose: v => res(v === "yes") });
  });
}
export function promptBox({ title, label, value = "", placeholder = "", confirm = "Save" }) {
  return new Promise(res => {
    const inp = h("input", { type: "text", class: "input", value, placeholder, maxLength: 120 });
    const d = dialog({ title, body: h("div", { class: "field" }, h("label", {}, label), inp),
      actions: [{ label: "Cancel", value: "" }, { label: confirm, kind: "primary", run: () => inp.value.trim() || false }],
      onClose: v => res(v || null) });
    inp.addEventListener("keydown", e => { if (e.key === "Enter") { d.close(inp.value.trim()); } });
    setTimeout(() => { inp.focus(); inp.select(); }, 30);
  });
}

// ---- context menu ---------------------------------------------------------------
export function menu(anchor, items) {
  document.querySelectorAll(".menu").forEach(m => m.remove());
  const m = h("div", { class: "menu", role: "menu" }, items.map(it => it === "-" ? h("hr") :
    h("button", { role: "menuitem", class: it.danger ? "danger" : "", onclick: () => { m.remove(); it.run(); } }, it.icon && icon(it.icon, "sm"), it.label)));
  document.body.append(m);
  const r = anchor.getBoundingClientRect();
  const w = m.offsetWidth, hgt = m.offsetHeight;
  m.style.left = Math.max(8, Math.min(innerWidth - w - 8, r.right - w)) + "px";
  m.style.top = Math.max(8, Math.min(innerHeight - hgt - 8, r.bottom + 4)) + "px";
  const off = e => { if (!m.contains(e.target)) { m.remove(); document.removeEventListener("mousedown", off, true); } };
  setTimeout(() => document.addEventListener("mousedown", off, true), 0);
  document.addEventListener("keydown", function esc(e) { if (e.key === "Escape") { m.remove(); document.removeEventListener("keydown", esc); } });
}

export function switchEl(checked, onchange, label) {
  const input = h("input", { type: "checkbox", checked: !!checked, "aria-label": label || "toggle", onchange: e => onchange(e.target.checked) });
  return h("span", { class: "switch" }, input, h("i"));
}
