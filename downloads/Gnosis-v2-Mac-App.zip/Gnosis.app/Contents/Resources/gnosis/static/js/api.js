// Thin fetch wrapper: adds the per-run token, normalises errors, reads NDJSON streams.

const TOKEN = document.querySelector('meta[name="gnosis-token"]')?.content || "";

export class ApiError extends Error {
  constructor(message, status, data) { super(message); this.status = status; this.data = data || {}; }
}

async function request(method, url, body, opts = {}) {
  const headers = { "X-Gnosis-Token": TOKEN };
  let payload;
  if (body instanceof FormData) payload = body;
  else if (body !== undefined) { headers["Content-Type"] = "application/json"; payload = JSON.stringify(body); }
  let res;
  try {
    res = await fetch(url, { method, headers, body: payload, signal: opts.signal });
  } catch (e) {
    if (e.name === "AbortError") throw e;
    throw new ApiError("Can’t reach Gnosis. Is the Gnosis window (terminal) still open?", 0);
  }
  if (opts.raw) {
    if (!res.ok) throw await asError(res);
    return res;
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new ApiError(data.error || `Request failed (${res.status})`, res.status, data);
  return data;
}
async function asError(res) {
  const d = await res.json().catch(() => ({}));
  return new ApiError(d.error || `Request failed (${res.status})`, res.status, d);
}

export const api = {
  get: (u, o) => request("GET", u, undefined, o),
  post: (u, b, o) => request("POST", u, b ?? {}, o),
  put: (u, b) => request("PUT", u, b ?? {}),
  patch: (u, b) => request("PATCH", u, b ?? {}),
  del: (u, b) => request("DELETE", u, b),
  upload: (u, form) => request("POST", u, form),
  /** Stream NDJSON; calls onEvent for each object. */
  async stream(url, body, onEvent, signal) {
    const res = await request("POST", url, body, { raw: true, signal });
    const reader = res.body.getReader();
    const dec = new TextDecoder();
    let buf = "";
    for (;;) {
      const { value, done } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      let nl;
      while ((nl = buf.indexOf("\n")) >= 0) {
        const line = buf.slice(0, nl).trim(); buf = buf.slice(nl + 1);
        if (line) { let o; try { o = JSON.parse(line); } catch { o = null; } if (o) onEvent(o); }
      }
    }
    if (buf.trim()) { let o; try { o = JSON.parse(buf); } catch { o = null; } if (o) onEvent(o); }
  },
  /** Fetch a file with the token header and save it. */
  async download(url, fallbackName, body) {
    const res = await request(body ? "POST" : "GET", url, body, { raw: true });
    const blob = await res.blob();
    let name = fallbackName;
    const cd = res.headers.get("Content-Disposition") || "";
    const m = cd.match(/filename\*=UTF-8''([^;]+)/i) || cd.match(/filename="?([^";]+)"?/i);
    if (m) { try { name = decodeURIComponent(m[1]); } catch { name = m[1]; } }
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob); a.download = name;
    document.body.append(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  },
};
