// Memory: notes, files, links — create, search, edit, download, delete.
import { api } from "./api.js";
import { S, on, emit } from "./state.js";
import { h, icon, clear, toast, dialog, confirmBox, fmtDate, fmtSize, debounce, switchEl } from "./util.js";

const KIND_ICON = { note: "note", file: "file", link: "link" };
const KIND_LABEL = { note: "Note", file: "File", link: "Link" };

// ---------- dialogs (also used from chat source chips) ----------
export async function openMemory(id) {
  let m;
  try { m = await api.get("/api/memories/" + id); } catch (e) { return toast(e.message, { error: true }); }
  const title = h("input", { type: "text", class: "input", value: m.title, maxLength: 200, "aria-label": "Title" });
  const content = h("textarea", { class: "input", rows: 12, "aria-label": "Content" }); content.value = m.content;
  content.style.minHeight = "220px";
  const tags = h("input", { type: "text", class: "input", value: m.tags.join(", "), placeholder: "e.g. work, phd, family" });
  let pinned = m.pinned;
  const meta = [KIND_LABEL[m.kind], m.filename && m.filename !== m.title ? m.filename : null, fmtSize(m.size), "Saved " + fmtDate(m.created),
    m.origin === "chat" ? "from chat" : m.origin === "suggestion" ? "from a suggestion" : null].filter(Boolean).join(" · ");
  const body = h("div", {},
    h("div", { class: "help", style: null }, meta),
    m.status === "failed" && h("div", { class: "notice" }, icon("alert"), h("div", {}, m.error || "This file couldn’t be read.",
      m.downloadable && h("span", {}, " ", h("button", { class: "btn sm", onclick: async () => { await api.post(`/api/memories/${m.id}/reprocess`); toast("Trying again…"); emit("memory-changed"); d.close(); } }, "Try again")))),
    m.status === "processing" && h("div", { class: "notice" }, icon("loader", "spin"), "Gnosis is still reading this file…"),
    m.kind === "link" && m.url && h("div", { class: "field" }, h("div", { class: "lbl" }, "Address"), h("a", { href: m.url, target: "_blank", rel: "noopener noreferrer" }, m.url),
      h("div", {}, h("button", { class: "btn sm", onclick: async () => { await api.post(`/api/memories/${m.id}/fetch`); toast("Reading the page… (one request to that website)"); setTimeout(() => emit("memory-changed"), 2500); } }, icon("download", "sm"), "Read page text into memory"))),
    h("div", { class: "field" }, h("label", {}, "Title"), title),
    h("div", { class: "field" }, h("label", {}, m.kind === "file" ? "Extracted text (editable — this is what Gnosis searches)" : "Content"), content),
    h("div", { class: "field" }, h("label", {}, "Tags"), tags),
    h("div", { class: "toggle-row" }, h("div", { class: "txt" }, h("b", {}, "Always keep in mind"), h("span", {}, "Pinned memories are given to Gnosis in every chat. Best for short, important facts.")),
      switchEl(pinned, v => { pinned = v; }, "Pin")));
  const d = dialog({ title: m.kind === "note" ? "Edit note" : "Memory details", body, wide: true, actions: [
    { label: "Delete", kind: "danger", icon: "trash", close: false, run: async () => {
      if (!await confirmBox({ title: "Delete this memory?", message: "It will be removed from your device and Gnosis will forget it.", confirm: "Delete", danger: true })) return false;
      await api.del("/api/memories/" + m.id); toast("Memory deleted"); emit("memory-changed"); d.close(); return false; } },
    "spacer",
    m.kind === "file" || true ? { label: "Download", icon: "download", close: false, run: async () => { await api.download(`/api/memories/${m.id}/download`, m.filename || m.title + ".md"); return false; } } : null,
    { label: "Save changes", kind: "primary", run: async () => {
      await api.patch("/api/memories/" + m.id, { title: title.value, content: content.value, tags: tags.value.split(",").map(t => t.trim()).filter(Boolean), pinned });
      toast("Saved"); emit("memory-changed"); } },
  ].filter(Boolean) });
}

export function newNote() {
  const content = h("textarea", { class: "input", rows: 7, placeholder: "e.g. My daughter’s birthday is 3 June. I prefer morning meetings. The PhD supervisor is Prof. Hughes…", "aria-label": "Note" });
  const title = h("input", { type: "text", class: "input", placeholder: "Optional — Gnosis will name it for you", maxLength: 200 });
  let pinned = false;
  const d = dialog({ title: "Add a memory", body: h("div", {},
    h("p", { class: "help" }, "Write it the way you’d say it. Gnosis will recall it whenever it’s relevant."),
    h("div", { class: "field" }, h("label", {}, "What should Gnosis remember?"), content),
    h("div", { class: "field" }, h("label", {}, "Title"), title),
    h("div", { class: "toggle-row" }, h("div", { class: "txt" }, h("b", {}, "Always keep in mind"), h("span", {}, "Include in every chat (use sparingly).")), switchEl(false, v => { pinned = v; }, "Pin"))),
    actions: [{ label: "Cancel", value: "" }, { label: "Save to memory", kind: "primary", run: async () => {
      if (!content.value.trim()) throw new Error("Write something to remember first.");
      await api.post("/api/memories", { content: content.value, title: title.value, pinned }); toast("Saved to memory"); emit("memory-changed"); } }] });
  setTimeout(() => content.focus(), 40);
  return d;
}

export function newLink() {
  const url = h("input", { type: "url", class: "input", placeholder: "https://www.linkedin.com/in/…", "aria-label": "Web address" });
  const title = h("input", { type: "text", class: "input", placeholder: "e.g. My LinkedIn, Google Scholar, portfolio" });
  const note = h("textarea", { class: "input", rows: 3, placeholder: "What is this? (optional) e.g. “My professional profile — keep my headline up to date”" });
  let fetch = false;
  dialog({ title: "Save a link or social account", body: h("div", {},
    h("div", { class: "field" }, h("label", {}, "Web address"), url),
    h("div", { class: "field" }, h("label", {}, "Name"), title),
    h("div", { class: "field" }, h("label", {}, "Notes"), note),
    h("div", { class: "toggle-row" }, h("div", { class: "txt" }, h("b", {}, "Also read the page text now"), h("span", {}, "Makes one request to that website from your computer. Off by default — most social sites need a login and won’t work.")), switchEl(false, v => { fetch = v; }, "Fetch"))),
    actions: [{ label: "Cancel", value: "" }, { label: "Save link", kind: "primary", run: async () => {
      await api.post("/api/memories/link", { url: url.value, title: title.value, note: note.value, fetch }); toast("Link saved"); emit("memory-changed"); } }] });
  setTimeout(() => url.focus(), 40);
}

// ---------- the Memory page ----------
export function createMemoryView(root) {
  const st = { kind: "", q: "", items: [], counts: {}, sugg: [], timer: 0 };
  const fileIn = h("input", { type: "file", multiple: true, class: "sr", tabindex: -1, onchange: e => { upload(e.target.files); e.target.value = ""; } });
  const suggBox = h("div");
  const drop = h("div", { class: "dropzone", tabindex: 0, role: "button", "aria-label": "Upload files",
    onclick: () => fileIn.click(), onkeydown: e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); fileIn.click(); } } },
    icon("upload", "lg"), h("b", {}, "Drop files here, or click to choose"),
    h("small", {}, "Documents (PDF, Word, PowerPoint, Excel, text, Markdown, CSV, HTML), images (text is read with OCR), and audio or video (transcribed on this computer)."));
  ["dragenter", "dragover"].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.add("over"); }));
  ["dragleave", "drop"].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.remove("over"); }));
  drop.addEventListener("drop", e => upload(e.dataTransfer.files));
  const search = h("input", { type: "search", placeholder: "Search your memory…", "aria-label": "Search memory", oninput: debounce(e => { st.q = e.target.value.trim(); load(); }, 250) });
  const tabsEl = h("div", { class: "tabs", role: "tablist" });
  const grid = h("div", { class: "grid" });
  const sub = h("p");
  const head = h("div", { class: "page-head" }, h("div", { class: "grow" }, h("h1", {}, "Memory"), sub),
    h("div", { class: "row" },
      h("button", { class: "btn", onclick: newLink }, icon("link", "sm"), "Add link"),
      h("button", { class: "btn", onclick: () => fileIn.click() }, icon("upload", "sm"), "Upload files"),
      h("button", { class: "btn primary", onclick: newNote }, icon("plus", "sm"), "Add memory")));
  root.append(h("div", { class: "page" }, h("div", { class: "page-in" }, head, suggBox, drop, fileIn,
    h("div", { class: "toolbar" }, h("div", { class: "search" }, icon("search", "sm"), search), tabsEl), grid)));

  async function load() {
    try {
      const qs = new URLSearchParams(); if (st.kind) qs.set("kind", st.kind); if (st.q) qs.set("q", st.q);
      const r = await api.get("/api/memories?" + qs);
      st.items = r.items; st.counts = r.counts;
      const s = await api.get("/api/suggestions"); st.sugg = s.items;
    } catch (e) { return toast(e.message, { error: true }); }
    render();
    clearTimeout(st.timer);
    if (st.items.some(i => i.status === "processing")) st.timer = setTimeout(load, 1500);
  }

  function render() {
    const c = st.counts;
    sub.textContent = c.total ? `${c.total} ${c.total === 1 ? "memory" : "memories"} · stored only on this computer` : "Everything Gnosis knows about you lives here — only on this computer.";
    clear(tabsEl).append(...[["", "All", c.total], ["note", "Notes", c.note], ["file", "Files", c.file], ["link", "Links", c.link]].map(([k, l, n]) =>
      h("button", { role: "tab", "aria-selected": String(st.kind === k), onclick: () => { st.kind = k; load(); } }, `${l}${n ? " " + n : ""}`)));
    clear(suggBox);
    st.sugg.slice(0, 4).forEach(s => suggBox.append(h("div", { class: "suggest" }, icon("sparkle"),
      h("div", { class: "txt" }, s.text, h("small", {}, "Gnosis noticed this in your chat. Save it to memory?")),
      h("button", { class: "btn sm primary", onclick: async () => { try { await api.post(`/api/suggestions/${s.id}/accept`, {}); toast("Saved to memory"); load(); emit("memory-changed"); } catch (e) { toast(e.message, { error: true }); } } }, "Save"),
      h("button", { class: "btn sm ghost", onclick: async () => { await api.post(`/api/suggestions/${s.id}/dismiss`); load(); emit("memory-changed"); } }, "Dismiss"))));
    clear(grid);
    if (!st.items.length) {
      grid.append(h("div", { class: "empty-note card", style: null }, st.q ? `Nothing matches “${st.q}”.` :
        "Nothing here yet. Add a note, drop in a CV or certificate, save a link — or just tell Gnosis in chat: “Remember that…”"));
      return;
    }
    st.items.forEach(m => grid.append(card(m)));
  }

  function card(m) {
    const status = m.status === "processing" ? h("span", { class: "status processing" }, "Reading…") : m.status === "failed" ? h("span", { class: "status failed", title: m.error || "" }, "Needs attention") : null;
    return h("article", { class: "mem", tabindex: 0, onclick: () => openMemory(m.id), onkeydown: e => { if (e.key === "Enter") openMemory(m.id); } },
      h("div", { class: "mem-top" }, h("span", { class: "kind " + m.kind }, icon(KIND_ICON[m.kind])), h("h4", { title: m.title }, m.title),
        m.pinned && h("span", { class: "chip accent", title: "Always kept in mind" }, icon("pin", "sm"))),
      h("p", {}, m.snippet || (m.status === "processing" ? "Gnosis is reading this file…" : m.error || "No text")),
      h("div", { class: "mem-foot" }, h("span", { class: "grow" }, [KIND_LABEL[m.kind], fmtSize(m.size), fmtDate(m.updated)].filter(Boolean).join(" · ")), status,
        h("div", { class: "mem-actions", onclick: e => e.stopPropagation() },
          h("button", { class: "icon-btn sm", title: "Edit", "aria-label": "Edit " + m.title, onclick: () => openMemory(m.id) }, icon("edit", "sm")),
          h("button", { class: "icon-btn sm", title: "Download", "aria-label": "Download " + m.title, onclick: () => api.download(`/api/memories/${m.id}/download`, m.filename || m.title + ".md").catch(e => toast(e.message, { error: true })) }, icon("download", "sm")),
          h("button", { class: "icon-btn sm", title: "Delete", "aria-label": "Delete " + m.title, onclick: async () => {
            if (!await confirmBox({ title: "Delete this memory?", message: `“${m.title}” will be removed from your device and Gnosis will forget it.`, confirm: "Delete", danger: true })) return;
            try { await api.del("/api/memories/" + m.id); toast("Memory deleted"); load(); emit("memory-changed"); } catch (e) { toast(e.message, { error: true }); } } }, icon("trash", "sm")))));
  }

  async function upload(files) {
    if (!files || !files.length) return;
    const fd = new FormData(); [...files].forEach(f => fd.append("files", f));
    toast(`Uploading ${files.length} file${files.length > 1 ? "s" : ""}…`);
    try { const r = await api.upload("/api/memories/upload", fd); toast(`Added ${r.items.length} — Gnosis is reading ${r.items.length > 1 ? "them" : "it"} now.`); load(); emit("memory-changed"); }
    catch (e) { toast(e.message, { error: true }); }
  }

  on("memory-changed", () => { if (!root.hidden) load(); });
  return { show: load };
}
