// The chat view: conversation, streaming, sources, cloud preview, model setup banners.
import { api, ApiError } from "./api.js";
import { S, on, emit, refreshConvs, refreshStatus, pullModel, displayName } from "./state.js";
import { h, icon, md, clear, toast, dialog, confirmBox, promptBox, menu, greeting, switchEl } from "./util.js";
import { openMemory } from "./memory.js";

const STARTERS = [
  "What do you remember about me?",
  "Help me plan my week",
  "Summarise my recent notes",
  "Draft a message for me",
];

export function createChat(root, { toggleSidebar }) {
  const st = { convId: null, msgs: [], streaming: false, abort: null, mode: "local", title: "New chat", pull: null, dismissedEmbed: false };

  // ---------- skeleton ----------
  const titleBtn = h("button", { class: "title", title: "Rename chat", onclick: rename }, "New chat");
  const moreBtn = h("button", { class: "icon-btn", "aria-label": "Chat options", onclick: e => chatMenu(e.currentTarget) }, icon("more"));
  const sideBtn = h("button", { class: "icon-btn", "aria-label": "Toggle sidebar", onclick: toggleSidebar }, icon("panel"));
  const pill = h("span", { class: "pill ok" });
  const topbar = h("div", { class: "topbar" }, sideBtn, titleBtn, h("span", { class: "grow" }), pill, moreBtn);
  const col = h("div", { class: "chat-col" });
  const hero = h("div", { class: "hero" });
  const scroll = h("div", { class: "chat-scroll" }, hero, col);
  const bannerBox = h("div");
  const ta = h("textarea", { rows: 1, placeholder: "Message Gnosis…", "aria-label": "Message", maxLength: 20000,
    onkeydown: e => { if (e.key === "Enter" && !e.shiftKey && !e.isComposing) { e.preventDefault(); submit(); } },
    oninput: grow });
  const fileIn = h("input", { type: "file", multiple: true, class: "sr", tabindex: -1, onchange: e => { attach(e.target.files); e.target.value = ""; } });
  const attachBtn = h("button", { class: "icon-btn", title: "Add files to memory", "aria-label": "Add files to memory", onclick: () => fileIn.click() }, icon("clip"));
  const localBtn = h("button", { "aria-pressed": "true", onclick: () => setMode("local") }, icon("lock", "sm"), "Private");
  const cloudBtn = h("button", { "aria-pressed": "false", onclick: () => setMode("cloud") }, icon("cloud", "sm"), "Cloud");
  const seg = h("div", { class: "seg", role: "group", "aria-label": "Where to answer" }, localBtn, cloudBtn);
  const sendBtn = h("button", { class: "send", "aria-label": "Send", onclick: () => (st.streaming ? stop() : submit()) }, icon("send"));
  const composer = h("div", { class: "composer" }, ta, h("div", { class: "composer-row" }, attachBtn, fileIn, seg, h("span", { class: "grow" }), sendBtn));
  const hint = h("div", { class: "hint" });
  root.append(topbar, scroll, h("div", { class: "composer-wrap" }, bannerBox, composer, hint));

  // ---------- helpers ----------
  function grow() { ta.style.height = "auto"; ta.style.height = Math.min(ta.scrollHeight, 220) + "px"; }
  const nearBottom = () => scroll.scrollHeight - scroll.scrollTop - scroll.clientHeight < 140;
  const toBottom = (force) => { if (force || nearBottom()) scroll.scrollTop = scroll.scrollHeight; };

  function setMode(m) {
    const cloudOn = S.settings?.cloud?.enabled && S.status?.cloud?.has_key;
    if (m === "cloud" && !cloudOn) {
      toast(S.settings?.cloud?.enabled ? "Add your cloud API key in Settings → Cloud first." : "Cloud answers are off. You can switch them on in Settings → Cloud.", { action: { label: "Open settings", run: () => emit("go", { view: "settings", tab: "cloud" }) } });
      return;
    }
    st.mode = m;
    renderChrome();
  }

  function renderChrome() {
    const cloudOn = !!(S.settings?.cloud?.enabled && S.status?.cloud?.has_key);
    if (!cloudOn && st.mode === "cloud") st.mode = "local";
    localBtn.setAttribute("aria-pressed", String(st.mode === "local"));
    cloudBtn.setAttribute("aria-pressed", String(st.mode === "cloud"));
    cloudBtn.title = cloudOn ? "Ask a cloud model — you review a redacted preview first" : "Off. Enable in Settings → Cloud";
    cloudBtn.classList.toggle("off", !cloudOn);
    cloudBtn.style.opacity = cloudOn ? "" : ".55";
    clear(sendBtn).append(icon(st.streaming ? "stop" : "send"));
    sendBtn.setAttribute("aria-label", st.streaming ? "Stop" : "Send");
    sendBtn.disabled = false;
    titleBtn.textContent = st.title;
    const m = S.settings?.models?.chat || "";
    const o = S.status?.ollama;
    clear(pill);
    if (st.mode === "cloud") { pill.className = "pill warn"; pill.append(icon("cloud", "sm"), "Cloud · redacted preview"); }
    else if (S.offline) { pill.className = "pill warn"; pill.append("Not connected"); }
    else if (o && !o.running) { pill.className = "pill warn"; pill.append("Ollama not running"); }
    else { pill.className = "pill ok"; pill.append(icon("lock", "sm"), "On this device" + (m ? " · " + m : "")); }
    hint.textContent = st.mode === "cloud"
      ? "Cloud mode: you’ll see exactly what is sent, with personal details replaced, before anything leaves."
      : "Gnosis answers on your device using your memory. Enter to send · Shift+Enter for a new line.";
    const empty = st.msgs.length === 0;
    hero.hidden = !empty;
    col.hidden = empty;
    moreBtn.hidden = !st.convId;
    renderBanner();
  }

  function renderHero() {
    clear(hero).append(
      h("img", { class: "mark", src: "/static/favicon.svg", alt: "" }),
      h("h1", {}, greeting(displayName())),
      h("p", {}, "Ask anything. I’ll use what you’ve told me and saved — privately, on this computer."),
      h("div", { class: "starters" }, STARTERS.map(s => h("button", { onclick: () => submit(s) }, s))));
  }

  // ---------- banners (setup & health) ----------
  function renderBanner() {
    clear(bannerBox);
    const s = S.status, o = s?.ollama, m = S.settings?.models;
    if (!s || !m) return;
    if (st.pull) {
      bannerBox.append(h("div", { class: "banner" }, icon("download"), h("div", { class: "grow" },
        h("b", {}, `Installing ${st.pull.model}…`), h("small", {}, st.pull.label || "Starting download"),
        h("div", { class: "progress" }, (st.pull.bar = h("i")))), null));
      if (st.pull.pct != null) st.pull.bar.style.width = st.pull.pct + "%";
      return;
    }
    if (!o.running) {
      bannerBox.append(h("div", { class: "banner bad" }, icon("alert"), h("div", { class: "grow" },
        h("b", {}, "Ollama isn’t running"), h("small", {}, "Open the Ollama app (Mac: Applications → Ollama; Windows: Start menu → Ollama). It runs the AI on your computer.")),
        h("button", { class: "btn sm", onclick: async () => { await refreshStatus(); if (!S.status.ollama.running) toast("Still can’t reach Ollama.", { error: true }); } }, "Check again")));
    } else if (!o.chat_ok) {
      bannerBox.append(h("div", { class: "banner" }, icon("download"), h("div", { class: "grow" },
        h("b", {}, `One-time setup: install the chat model “${m.chat}”`), h("small", {}, "About 5 GB, downloaded once, then works offline.")),
        h("button", { class: "btn primary sm", onclick: () => install(m.chat) }, "Install")));
    } else if (!o.embed_ok && !st.dismissedEmbed) {
      bannerBox.append(h("div", { class: "banner" }, icon("memory"), h("div", { class: "grow" },
        h("b", {}, "Install the memory model for smarter recall"), h("small", {}, `“${m.embed}” (~270 MB). Until then Gnosis finds memories by keywords only.`)),
        h("button", { class: "btn primary sm", onclick: () => install(m.embed) }, "Install"),
        h("button", { class: "icon-btn sm", "aria-label": "Dismiss", onclick: () => { st.dismissedEmbed = true; renderBanner(); } }, icon("x"))));
    }
  }
  async function install(model) {
    st.pull = { model, pct: null, label: "Starting…" };
    renderBanner();
    try {
      await pullModel(model, (pct, label) => {
        st.pull.pct = pct; st.pull.label = label + (pct != null ? ` · ${pct}%` : "");
        if (st.pull.bar) { if (pct != null) st.pull.bar.style.width = pct + "%"; st.pull.bar.parentElement.previousSibling.textContent = st.pull.label; }
      });
      toast(`${model} is ready.`);
    } catch (e) { toast(e.message, { error: true }); }
    st.pull = null; renderChrome();
  }

  // ---------- messages ----------
  function msgEl(m, last) {
    if (m.role === "user") return h("div", { class: "msg user" }, h("div", { class: "bubble" }, m.content));
    const body = h("div", { class: "prose" });
    body.innerHTML = md(m.content);                  // md() escapes all input
    const el = h("div", { class: "msg assistant" + (last ? " last" : "") },
      h("img", { class: "av", src: "/static/favicon.svg", alt: "" }),
      h("div", { class: "body" }, body, sourcesRow(m), toolsRow(m, body)));
    el._m = m;
    return el;
  }
  function sourcesRow(m) {
    const used = m.sources || [];
    if (!used.length) return null;
    return h("div", { class: "src-row" }, used.map(s => h("button", { class: "src", title: s.header || s.title, onclick: () => openSource(s) },
      h("b", {}, s.n), h("span", {}, s.title))));
  }
  function toolsRow(m, body) {
    const meta = m.meta || {};
    return h("div", { class: "msg-tools" },
      meta.cloud && h("span", { class: "badge cloud" }, icon("cloud", "sm"), `Cloud · ${meta.redactions || 0} details hidden`),
      meta.saved && h("span", { class: "badge saved" }, icon("check", "sm"), "Saved to memory"),
      meta.partial && h("span", { class: "badge" }, "Stopped"),
      h("button", { class: "icon-btn sm", title: "Copy", "aria-label": "Copy answer", onclick: async () => { try { await navigator.clipboard.writeText(m.content); toast("Copied"); } catch { toast("Couldn’t copy", { error: true }); } } }, icon("copy", "sm")),
      h("button", { class: "icon-btn sm", title: "Try again", "aria-label": "Regenerate answer", onclick: () => regenerate() }, icon("refresh", "sm")));
  }
  async function openSource(s) {
    if (s.ref_type === "memory") openMemory(s.ref_id);
    else if (s.conv_id) emit("open-conv", s.conv_id);
  }
  col.addEventListener("click", e => {
    const b = e.target.closest(".cite");
    if (!b) return;
    const msg = b.closest(".msg")?._m;
    const pool = [...(msg?.sources || []), ...(msg?.allSources || [])];
    const s = pool.find(x => x.n === +b.dataset.n);
    if (s) openSource(s); else toast("That source is no longer available.");
  });

  function renderAll() {
    clear(col);
    st.msgs.forEach((m, i) => col.append(msgEl(m, i === st.msgs.length - 1)));
    renderChrome();
    toBottom(true);
  }

  // ---------- conversation lifecycle ----------
  async function open(id) {
    if (st.streaming) { toast("Wait for the current answer to finish, or press Stop."); return; }
    try {
      const c = await api.get("/api/conversations/" + id);
      st.convId = c.id; st.title = c.title; st.msgs = c.messages_list;
      S.convId = c.id; emit("current", c.id);
      renderAll(); emit("go", { view: "chat" });
    } catch (e) { toast(e.message, { error: true }); if (e.status === 404) { newChat(); refreshConvs(); } }
  }
  function newChat() {
    if (st.streaming) stop();
    st.convId = null; st.title = "New chat"; st.msgs = [];
    S.convId = null; emit("current", null);
    renderHero(); renderAll(); emit("go", { view: "chat" });
    setTimeout(() => ta.focus(), 50);
  }
  async function rename() {
    if (!st.convId) return;
    const t = await promptBox({ title: "Rename chat", label: "Chat name", value: st.title });
    if (!t) return;
    try { await api.patch("/api/conversations/" + st.convId, { title: t }); st.title = t; renderChrome(); refreshConvs(); } catch (e) { toast(e.message, { error: true }); }
  }
  function chatMenu(anchor) {
    const c = S.convs.find(x => x.id === st.convId);
    menu(anchor, [
      { label: "Rename", icon: "edit", run: rename },
      { label: c?.pinned ? "Unpin" : "Pin to top", icon: "pin", run: async () => { await api.patch("/api/conversations/" + st.convId, { pinned: !c?.pinned }); refreshConvs(); } },
      { label: "Clear messages", icon: "refresh", run: () => clearMessages(st.convId) },
      "-",
      { label: "Delete chat", icon: "trash", danger: true, run: () => deleteChat(st.convId) },
    ]);
  }
  async function clearMessages(id) {
    if (!await confirmBox({ title: "Clear this chat?", message: "All messages in this chat will be removed. Anything you saved to Memory stays.", confirm: "Clear messages", danger: true })) return;
    await api.post(`/api/conversations/${id}/clear`);
    if (id === st.convId) { st.msgs = []; renderHero(); renderAll(); }
    refreshConvs();
  }
  async function deleteChat(id) {
    if (!await confirmBox({ title: "Delete this chat?", message: "This permanently removes the chat from your device.", confirm: "Delete chat", danger: true })) return;
    try { await api.del("/api/conversations/" + id); } catch (e) { if (e.status !== 404) return toast(e.message, { error: true }); }
    if (id === st.convId) newChat();
    refreshConvs();
  }

  // ---------- sending ----------
  function submit(text) {
    text = (text ?? ta.value).trim();
    if (!text) return;
    if (st.streaming) return toast("Gnosis is still answering. Press Stop to interrupt.");
    if (st.mode === "cloud") return cloudSend(text);
    ta.value = ""; grow();
    send(text);
  }
  function stop() { st.abort && st.abort.abort(); }

  async function send(text, regen = false) {
    if (!regen) { st.msgs.push({ role: "user", content: text }); }
    const draft = { role: "assistant", content: "", sources: [], allSources: [], meta: {} };
    st.msgs.push(draft);
    renderAll();
    const el = col.lastElementChild;
    const body = el.querySelector(".prose");
    body.replaceChildren(h("span", { class: "typing", "aria-label": "Gnosis is thinking" }, h("i"), h("i"), h("i")));
    st.streaming = true; st.abort = new AbortController(); renderChrome();
    let raf = 0, started = false, failed = false;
    const paint = () => { raf = 0; body.innerHTML = md(draft.content); toBottom(); };
    try {
      await api.stream("/api/chat", { conv_id: st.convId, text, regenerate: regen }, ev => {
        switch (ev.type) {
          case "start": if (!st.convId) { st.convId = ev.conv_id; S.convId = ev.conv_id; emit("current", ev.conv_id); } st.title = ev.title; titleBtn.textContent = st.title; refreshConvs(); break;
          case "saved": draft.meta.saved = ev.memory; emit("memory-changed"); break;
          case "sources": draft.allSources = ev.sources; break;
          case "token": started = true; draft.content += ev.t; if (!raf) raf = requestAnimationFrame(paint); break;
          case "done": draft.sources = ev.sources || []; break;
          case "error": failed = true; showError(el, body, ev, draft); break;
        }
      }, st.abort.signal);
    } catch (e) {
      if (e.name === "AbortError") { draft.meta.partial = true; }
      else { failed = true; showError(el, body, { message: e.message, code: "network" }, draft); }
    } finally {
      cancelAnimationFrame(raf);
      st.streaming = false; st.abort = null;
      if (!draft.content) { st.msgs.pop(); }
      if (draft.content) {
        const fresh = msgEl(draft, true);
        el.replaceWith(fresh);
      } else if (!failed) { el.remove(); }
      col.querySelectorAll(".msg.last").forEach(x => { if (x !== col.lastElementChild) x.classList.remove("last"); });
      renderChrome(); toBottom(true);
      refreshConvs(); setTimeout(refreshConvs, 5000); setTimeout(() => { emit("memory-changed"); }, 1500);
    }
  }
  function showError(el, body, ev, draft) {
    const actions = [];
    if (ev.action?.type === "pull") actions.push(h("button", { class: "btn primary sm", onclick: async () => { await install(ev.action.model); regenerate(); } }, `Install ${ev.action.model}`));
    else actions.push(h("button", { class: "btn sm", onclick: () => regenerate() }, "Try again"));
    body.replaceChildren(h("div", { class: "err-card", role: "alert" }, icon("alert"), h("div", { class: "msg-text" }, ev.message), ...actions));
    refreshStatus().then(renderChrome);
  }
  function regenerate() {
    if (st.streaming || !st.convId) return;
    // drop the failed/last assistant message locally; server removes it too
    while (st.msgs.length && st.msgs[st.msgs.length - 1].role === "assistant") st.msgs.pop();
    const last = st.msgs[st.msgs.length - 1];
    if (!last) return;
    send(last.content, true);
  }

  // ---------- cloud ----------
  async function cloudSend(text) {
    let include = null;
    const render = async () => api.post("/api/chat/cloud/preview", { conv_id: st.convId, text, include_memory: include });
    let pv;
    try { pv = await render(); } catch (e) { return toast(e.message, { error: true }); }
    const holder = h("div");
    const draw = () => {
      clear(holder).append(
        h("div", { class: "notice" }, icon("alert"), h("div", {}, h("b", {}, "This will leave your device."), " Review exactly what is sent. Names, emails, phone numbers and other details are replaced with placeholders, and put back in the answer here.")),
        h("div", { class: "toggle-row" }, h("div", { class: "txt" }, h("b", {}, "Include relevant memory excerpts"), h("span", {}, "Off by default. When on, short extracts from your notes are included (also redacted).")),
          switchEl(include ?? S.settings.cloud.include_memory, async v => { include = v; try { pv = await render(); draw(); } catch (e) { toast(e.message, { error: true }); } }, "Include memory")),
        h("div", { class: "field" }, h("div", { class: "lbl" }, `Messages (${pv.messages.length})`),
          ...pv.messages.map(m => h("div", { class: "preview-box" }, `${m.role === "user" ? "You" : "Gnosis"}: ${m.content}`))),
        h("details", { class: "field" }, h("summary", {}, "Instructions sent with it"), h("div", { class: "preview-box" }, pv.system)),
        h("div", { class: "field" }, h("div", { class: "lbl" }, `Replaced details (${pv.redactions.length})`),
          pv.redactions.length ? h("table", { class: "red-table" }, pv.redactions.map(r => h("tr", {}, h("td", {}, r.placeholder), h("td", {}, "← " + r.original))))
            : h("div", { class: "help" }, "No personal identifiers were detected. You can add your own words to hide in Settings → Cloud.")),
        h("div", { class: "help" }, `${pv.characters.toLocaleString()} characters · model ${pv.model}`));
    };
    draw();
    dialog({ title: "Review before sending", body: holder, wide: true,
      actions: [{ label: "Cancel", value: "no" }, "spacer",
        { label: "Send to cloud", kind: "primary", icon: "cloud", run: async () => {
          ta.value = ""; grow();
          st.msgs.push({ role: "user", content: text }); renderAll();
          const holderMsg = { role: "assistant", content: "" }; st.msgs.push(holderMsg); renderAll();
          col.lastElementChild.querySelector(".prose").replaceChildren(h("span", { class: "typing" }, h("i"), h("i"), h("i")));
          st.streaming = true; renderChrome();
          try {
            const r = await api.post("/api/chat/cloud/send", { payload_id: pv.payload_id });
            st.convId = r.conv_id; S.convId = r.conv_id; emit("current", r.conv_id); st.title = r.title;
            st.msgs.pop();
            st.msgs.push({ id: r.message_id, role: "assistant", content: r.content, sources: r.sources, meta: { cloud: true, redactions: pv.redactions.length } });
          } catch (e) {
            st.msgs.pop(); st.msgs.pop(); ta.value = text; grow(); toast(e.message, { error: true });
          } finally { st.streaming = false; renderAll(); refreshConvs(); }
        } }] });
  }

  // ---------- attachments ----------
  async function attach(files) {
    if (!files || !files.length) return;
    const fd = new FormData();
    [...files].forEach(f => fd.append("files", f));
    try {
      const r = await api.upload("/api/memories/upload", fd);
      toast(`Added ${r.items.length} file${r.items.length > 1 ? "s" : ""} to Memory — Gnosis is reading ${r.items.length > 1 ? "them" : "it"}.`, { action: { label: "View", run: () => emit("go", { view: "memory" }) } });
      emit("memory-changed");
    } catch (e) { toast(e.message, { error: true }); }
  }
  root.addEventListener("dragover", e => { if (e.dataTransfer?.types?.includes("Files")) e.preventDefault(); });
  root.addEventListener("drop", e => { if (e.dataTransfer?.files?.length) { e.preventDefault(); attach(e.dataTransfer.files); } });

  on("convs", cs => { const c = cs.find(x => x.id === st.convId); if (c && c.title !== st.title) { st.title = c.title; titleBtn.textContent = c.title; } });
  on("status", renderChrome);
  on("settings", () => { renderHero(); renderChrome(); });
  on("open-conv", id => open(id));
  on("new-chat", newChat);
  on("conv-deleted", id => { if (id === st.convId) newChat(); });
  on("conv-cleared", id => { if (id === st.convId) { st.msgs = []; renderHero(); renderAll(); } });
  on("focus-composer", () => setTimeout(() => ta.focus(), 30));
  renderHero(); renderChrome();
  return { open, newChat, clearMessages, deleteChat, focus: () => ta.focus(), state: st };
}
