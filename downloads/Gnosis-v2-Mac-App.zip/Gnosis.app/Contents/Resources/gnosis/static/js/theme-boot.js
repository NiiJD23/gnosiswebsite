// Runs before first paint so there is no light/dark flash.
(function () {
  try {
    var t = localStorage.getItem("gnosis-theme");
    if (t === "light" || t === "dark") document.documentElement.setAttribute("data-theme", t);
  } catch (e) {}
})();
