#!/bin/bash
# Build Gnosis.app (and optionally Gnosis.dmg) from this repository.
# Run on a Mac:   bash packaging/build_mac_app.sh [--dmg]
set -euo pipefail
HERE="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$HERE/dist"
APP="$OUT/Gnosis.app"
VERSION="$(python3 -c "import re;print(re.search(r'\"([\d.]+)\"',open('$HERE/gnosis/__init__.py').read()).group(1))")"
rm -rf "$APP"; mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources/gnosis"

# application code (no tests/docs/dev files)
if command -v rsync >/dev/null 2>&1; then
  rsync -a --exclude '__pycache__' --exclude '.git' --exclude 'tests' --exclude 'dist' \
        --exclude 'docs' --exclude '.pytest_cache' --exclude 'packaging' \
        "$HERE/" "$APP/Contents/Resources/gnosis/"
else
  (cd "$HERE" && tar --exclude='__pycache__' --exclude='.git' --exclude='tests' --exclude='dist' \
      --exclude='docs' --exclude='.pytest_cache' --exclude='packaging' -cf - .) | tar -xf - -C "$APP/Contents/Resources/gnosis"
fi
cp "$HERE/packaging/Gnosis.icns" "$APP/Contents/Resources/Gnosis.icns"

cat > "$APP/Contents/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>CFBundleName</key><string>Gnosis</string>
  <key>CFBundleDisplayName</key><string>Gnosis</string>
  <key>CFBundleIdentifier</key><string>uk.promintal.gnosis</string>
  <key>CFBundleVersion</key><string>$VERSION</string>
  <key>CFBundleShortVersionString</key><string>$VERSION</string>
  <key>CFBundleExecutable</key><string>Gnosis</string>
  <key>CFBundleIconFile</key><string>Gnosis</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>LSMinimumSystemVersion</key><string>11.0</string>
  <key>NSHighResolutionCapable</key><true/>
</dict></plist>
PLIST

cat > "$APP/Contents/MacOS/Gnosis" <<'LAUNCH'
#!/bin/bash
# Gnosis launcher: first run creates a private Python environment, then starts
# the local server (127.0.0.1 only) and opens it in your browser.
APP_DIR="$(cd "$(dirname "$0")/.." && pwd)"
SRC="$APP_DIR/Resources/gnosis"
DATA="$HOME/Library/Application Support/Gnosis"
VENV="$DATA/venv"
LOG="$HOME/Library/Logs/Gnosis.log"
PORT=5177
mkdir -p "$DATA" "$HOME/Library/Logs"
notify() { osascript -e "display notification \"$1\" with title \"Gnosis\"" >/dev/null 2>&1; }
alert()  { osascript -e "display dialog \"$1\" with title \"Gnosis\" buttons {\"OK\"} default button 1 with icon caution" >/dev/null 2>&1; }

# Already running? just open it.
if curl -s -m 1 "http://127.0.0.1:$PORT/" 2>/dev/null | grep -q 'gnosis-token'; then
  open "http://127.0.0.1:$PORT"; exit 0
fi

PY=""
for c in /opt/homebrew/bin/python3 /usr/local/bin/python3 /Library/Frameworks/Python.framework/Versions/Current/bin/python3 /usr/bin/python3; do
  [ -x "$c" ] && "$c" -c 'import sys; sys.exit(0 if sys.version_info>=(3,9) else 1)' 2>/dev/null && PY="$c" && break
done
if [ -z "$PY" ]; then
  alert "Gnosis needs Python 3.9 or newer. Install it from python.org/downloads, then open Gnosis again."
  open "https://www.python.org/downloads/"; exit 1
fi

if [ ! -x "$VENV/bin/python" ]; then
  notify "Setting up Gnosis for the first time — this takes about a minute."
  "$PY" -m venv "$VENV" >> "$LOG" 2>&1 || { alert "Couldn't create Gnosis's environment. See ~/Library/Logs/Gnosis.log"; exit 1; }
fi
STAMP="$VENV/.requirements.sha"; HASH="$(shasum "$SRC/requirements.txt" | cut -d' ' -f1)"
if [ "$(cat "$STAMP" 2>/dev/null)" != "$HASH" ]; then
  notify "Installing Gnosis components…"
  "$VENV/bin/python" -m pip install --upgrade pip >> "$LOG" 2>&1
  "$VENV/bin/python" -m pip install -r "$SRC/requirements.txt" >> "$LOG" 2>&1 \
    || { alert "Installing components failed (is the internet connected?). See ~/Library/Logs/Gnosis.log"; exit 1; }
  echo "$HASH" > "$STAMP"
fi
cd "$SRC" && nohup "$VENV/bin/python" run.py --port "$PORT" >> "$LOG" 2>&1 &
disown
exit 0
LAUNCH
chmod +x "$APP/Contents/MacOS/Gnosis"
echo "Built $APP"

if [ "${1:-}" = "--dmg" ]; then
  STAGE="$OUT/dmg"; rm -rf "$STAGE"; mkdir -p "$STAGE"
  cp -R "$APP" "$STAGE/"; ln -s /Applications "$STAGE/Applications"
  hdiutil create -volname "Gnosis" -srcfolder "$STAGE" -ov -format UDZO "$OUT/Gnosis-$VERSION.dmg"
  rm -rf "$STAGE"; echo "Built $OUT/Gnosis-$VERSION.dmg"
fi
