# Gnosis — User Guide

Gnosis is your private assistant. It runs on your own computer, remembers what you tell it, and uses that memory when it answers.

---

## 1. Install (once)

### Step 1 — Install Ollama (the engine that runs the AI on your computer)
1. Go to **https://ollama.com/download** and download the installer for your computer.
2. Install it and **open it once**. A small llama icon appears in the menu bar (Mac) or system tray (Windows). That means it is running.

### Step 2 — Start Gnosis
**Mac**
1. Open the `Gnosis` folder in Finder.
2. Double-click **`start.command`**. If macOS says it can't be opened, **right-click → Open → Open**.
3. The first time, it prepares itself for about a minute. Then your browser opens Gnosis.

**Windows**
1. Open the `Gnosis` folder.
2. Double-click **`start.bat`**. (If Python is missing it tells you where to get it — tick *Add python.exe to PATH* when installing.)
3. The first time it takes about a minute, then your browser opens Gnosis.

> Keep the black terminal window open while you use Gnosis. Close it (or press **Ctrl+C**) to quit.

**Prefer a normal app?** On a Mac, run `bash packaging/build_mac_app.sh --dmg` once to create **Gnosis.app** and a **.dmg** installer you can drag into Applications.

### Step 3 — Install the models (one click)
If this is your first time, a banner appears above the message box:

* **"Install the chat model"** → click **Install**. (About 5 GB, downloads once, then works offline.)
* **"Install the memory model"** → click **Install**. (About 270 MB; makes recall smarter. Until then Gnosis finds memories by keywords.)

When the banner disappears you're ready.

---

## 2. Your first five minutes

1. **Set up your profile** — click your name at the bottom-left → *Profile*. Add your name, role, a few lines about you and your social links.
2. **Teach it something** — in chat type: *"Remember that my supervisor is Professor Hughes and we meet every second Thursday."* You'll see a green **Saved to memory** tag.
3. **Add a document** — *Memory → Upload files* (or drag a file onto the chat). CVs, certificates, assignments, research papers, spreadsheets, photos of documents, voice notes — all fine.
4. **Ask** — *"When do I meet my supervisor?"* The answer shows small numbered chips — click one to open the memory it used.

---

## 3. Chat

* **New chat** (top-left, or **Ctrl/Cmd+K**) starts a fresh conversation. Every chat is kept in the list on the left, grouped by Today / Yesterday / Previous 7 days.
* Hover a chat and click **⋯** to **rename, pin, clear messages or delete**. *Clear* keeps the chat but removes its messages; *Delete* removes it completely.
* **Hide** (next to "Chats") collapses the list; the panel icon at the top hides the whole sidebar.
* **Stop** interrupts an answer. **↻** tries again. **Copy** copies it.
* **Search chats** finds words inside past conversations.
* Past chats also feed Gnosis's recall — you can say "What did I decide about Lisbon?" and it will find it.

### Saving things from chat
Say it naturally: *"Remember that…"*, *"Note that…"*, *"Save this to memory: …"*, *"Don't forget…"*. Gnosis saves it at once and tells you.
If you just *mention* something important ("I've started a new role at AMIC"), Gnosis may offer it as a **suggestion** — you'll see a purple badge on **Memory**. Review and **Save** or **Dismiss**. Nothing is saved without your say-so.

---

## 4. Memory

Everything Gnosis knows is here, and it is all yours to edit.

* **Add memory** — write a note in your own words.
* **Upload files** — any type. Gnosis reads: PDF, Word (.docx), PowerPoint (.pptx), Excel (.xlsx), text, Markdown, CSV, JSON, HTML, RTF, images (text is read with OCR), and audio/video (transcribed on your computer).
  *Scanned PDFs and photos* need Tesseract OCR (Mac: `brew install tesseract`; Windows: `winget install UB-Mannheim.TesseractOCR`).
  *Audio and video* need `pip install -r requirements-audio.txt` once.
* **Add link** — save LinkedIn, X, GitHub, your website, a paper. Tick *Read the page text now* only if you want Gnosis to download that page (public pages only).
* Click any card to **edit**, **download** or **delete** it. Files keep the original (download gives it back) plus the editable text Gnosis searches.
* **Always keep in mind** (pin) — for short, vital facts that should be in *every* chat.
* If a file shows **Needs attention**, open it: the message says why and often offers **Try again**.

---

## 5. Cloud answers (optional)

Gnosis works fully offline. For harder questions you can ask a stronger cloud model — **only when you choose**.

1. *Settings → Cloud* → switch on **Allow cloud answers**, paste your API key, **Save key**, then **Save changes**.
2. In chat, switch the toggle under the message box from **Private** to **Cloud**.
3. Type your question. A **Review before sending** window shows *exactly* what would leave your computer. Emails, phone numbers, postcodes, card/ID numbers, web addresses and your name are replaced with placeholders like `[EMAIL_1]`; add your own words (client names, project codenames) in *Settings → Cloud → Always hide these words*.
4. Press **Send to cloud**, or **Cancel** — nothing is sent until you press it. The reply arrives with the placeholders swapped back, marked **Cloud**.

Your key is stored in the system keychain (or an encrypted file) and is never included in backups. *Settings → Cloud → Cloud activity log* lists every send (metadata only).

---

## 6. Settings

| Tab | What it does |
|---|---|
| **Profile** | Name, role, location, about you, social accounts. |
| **Appearance** | Light, dark or follow your computer. |
| **Models** | See Ollama status, choose models, context size, install new ones. |
| **Cloud** | Key, redaction words, activity log. |
| **Advisory style** | How you want advice framed (e.g. "recommendation first, then a risk register"), tone, priorities. |
| **Data & backup** | Export/restore, data location, delete chats, erase everything. |

---

## 7. Moving to a new laptop

1. Old laptop: *Settings → Data & backup → Export encrypted backup* — choose a password (**there is no recovery if you forget it**). Keep the `.gnosis` file safe.
2. New laptop: install Ollama and Gnosis (steps above).
3. *Settings → Data & backup → Restore backup* → choose the file, enter the password.

---

## 8. Troubleshooting

| You see | Do this |
|---|---|
| **"Ollama isn't running"** | Open the Ollama app, then click **Check again**. |
| **"The model … isn't installed yet"** | Click **Install** in the banner (or *Settings → Models*). |
| **"Too long for the model's memory window"** | Start a new chat, or raise *Settings → Models → Context window*. |
| Answers feel generic | Add more to Memory; check the numbered source chips; try a larger model in *Settings → Models*. |
| Slow answers | Close other heavy apps; a smaller model (e.g. `llama3.2:3b`) is faster. |
| Page says "Missing or invalid session token" | Reload the page (the token changes each time Gnosis starts). |
| Windows `pip` error about OneDrive paths | Use `start.bat` — it keeps its environment in `%LOCALAPPDATA%`, outside OneDrive. |
| Port already in use | Gnosis automatically picks the next free port — read the address in the terminal. |

Logs: the terminal window (or `~/Library/Logs/Gnosis.log` for the Mac app).

---

## 9. Your privacy, plainly

* Everything is stored in one folder on your computer (see README for the path).
* The web page Gnosis shows is served only to your own computer (`127.0.0.1`) and protected against other websites.
* Nothing goes to the internet unless you (a) press **Send to cloud** after previewing, (b) install a model, or (c) ask it to read a link.
* You can export or erase everything at any time.
