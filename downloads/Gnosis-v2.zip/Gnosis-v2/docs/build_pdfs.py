"""Render the Markdown docs to PDF.   python docs/build_pdfs.py   (needs: markdown, weasyprint)"""
import pathlib
import markdown
from weasyprint import HTML

HERE = pathlib.Path(__file__).parent
CSS = """
@page { size: A4; margin: 22mm 18mm 20mm; @bottom-center { content: counter(page); color:#8b867b; font: 9pt sans-serif; } }
body { font: 10.5pt/1.55 -apple-system, 'Helvetica Neue', Arial, sans-serif; color:#1f1d1a; }
h1 { font: 600 24pt Georgia, serif; color:#4b2fb8; margin: 0 0 6mm; border-bottom: 2px solid #e4e1d8; padding-bottom: 3mm; }
h2 { font: 600 15pt Georgia, serif; margin: 8mm 0 2mm; color:#2c2540; }
h3 { font-size: 11.5pt; margin: 5mm 0 1mm; }
code { font: 9pt Menlo, Consolas, monospace; background:#f0eee8; padding: 0 3px; border-radius: 3px; }
pre { background:#f6f4ee; border:1px solid #e4e1d8; border-radius:6px; padding:8px 10px; font: 8.2pt/1.4 Menlo, Consolas, monospace; white-space: pre-wrap; }
pre code { background:none; padding:0; }
table { border-collapse: collapse; width:100%; margin: 3mm 0; font-size: 9.3pt; }
th, td { border:1px solid #d9d5ca; padding: 4px 7px; vertical-align: top; text-align:left; }
th { background:#efeafc; }
blockquote { border-left: 3px solid #26105a; margin: 3mm 0; padding: 1mm 4mm; color:#5f5b53; background:#faf9f6; }
hr { border:0; border-top:1px solid #e4e1d8; margin: 6mm 0; }
a { color:#26105a; }
"""
for name, out in [("USER_GUIDE.md", "Gnosis_User_Guide.pdf"), ("ARCHITECTURE.md", "Gnosis_Technical_Architecture.pdf"), ("REDESIGN.md", "Gnosis_v2_Redesign_Notes.pdf")]:
    text = (HERE / name).read_text(encoding="utf-8")
    html = markdown.markdown(text, extensions=["tables", "fenced_code", "sane_lists"])
    HTML(string=f"<html><head><meta charset='utf-8'><style>{CSS}</style></head><body>{html}</body></html>").write_pdf(HERE / out)
    print("wrote", out)
