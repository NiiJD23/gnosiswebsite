import io
import json
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer

import pytest

from gnosis.privacy import backup


def test_api_requires_token_and_valid_host(ctx):
    from gnosis.app import create_app
    app = create_app(ctx, port=5177)
    c = app.test_client()
    assert c.get("/api/status", headers={"Host": "127.0.0.1:5177"}).status_code == 403          # no token
    ok = c.get("/api/status", headers={"Host": "127.0.0.1:5177", "X-Gnosis-Token": app.config["GNOSIS_TOKEN"]})
    assert ok.status_code == 200
    rebind = c.get("/api/status", headers={"Host": "evil.example:5177", "X-Gnosis-Token": app.config["GNOSIS_TOKEN"]})
    assert rebind.status_code == 403
    xo = c.get("/api/status", headers={"Host": "127.0.0.1:5177", "Origin": "https://evil.example",
                                       "X-Gnosis-Token": app.config["GNOSIS_TOKEN"]})
    assert xo.status_code == 403


def test_index_injects_token_and_sets_headers(client):
    r = client.get("/")
    html = r.get_data(as_text=True)
    assert client.token in html and "__GNOSIS_TOKEN__" not in html
    assert "script-src 'self'" in r.headers["Content-Security-Policy"]
    assert r.headers["X-Content-Type-Options"] == "nosniff"


def test_backup_roundtrip_and_wrong_password(ctx, client, tmp_path):
    ctx.memory.add_note("Backup me: favourite tea is Assam.")
    ctx.memory.add_file(io.BytesIO(b"file body text"), "f.txt")
    ctx.memory.wait_idle()
    r = client.post("/api/backup/export", json={"password": "short"})
    assert r.status_code == 400
    r = client.post("/api/backup/export", json={"password": "correct horse battery"})
    blob = r.data
    assert blob.startswith(b"GNOSIS2\n") and b"Assam" not in blob
    ctx.memory.delete(1)
    assert ctx.memory.counts()["total"] == 1
    bad = client.post("/api/backup/import", data={"password": "nope nope nope",
                                                  "file": (io.BytesIO(blob), "b.gnosis")})
    assert bad.status_code == 400
    good = client.post("/api/backup/import", data={"password": "correct horse battery",
                                                   "file": (io.BytesIO(blob), "b.gnosis")})
    assert good.status_code == 200, good.data
    assert ctx.memory.counts()["total"] == 2
    assert ctx.retriever.search("Assam tea", use_vectors=False)


def test_backup_rejects_path_traversal(ctx):
    import tarfile, os
    from cryptography.fernet import Fernet
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz") as tar:
        for name in ("gnosis.db", "uploads/../../evil.txt", "/abs.txt"):
            data = b"x"
            ti = tarfile.TarInfo(name)
            ti.size = 1
            tar.addfile(ti, io.BytesIO(data))
    salt = os.urandom(16)
    blob = backup.MAGIC + salt + Fernet(backup._key("password123", salt)).encrypt(buf.getvalue())
    evil = ctx.paths.home.parent / "evil.txt"
    try:
        backup.import_bytes(ctx.db, ctx.paths, blob, "password123")
    except Exception:
        pass
    assert not evil.exists()


def test_secret_never_returned_or_exported(ctx, client):
    key = "sk-ant-test-1234567890abcdef"
    assert client.put("/api/secrets/cloud-key", json={"key": key}).status_code == 200
    for url in ("/api/status", "/api/settings"):
        assert key not in client.get(url).get_data(as_text=True)
    blob = client.post("/api/backup/export", json={"password": "correct horse battery"}).data
    from cryptography.fernet import Fernet
    plain = Fernet(backup._key("correct horse battery", blob[8:24])).decrypt(blob[24:])
    assert key.encode() not in plain
    assert client.get("/api/status").get_json()["cloud"]["key_hint"].endswith("cdef")


class FakeCloud:
    def __init__(self):
        self.bodies = []
        outer = self

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a): pass
            def do_POST(self):
                n = int(self.headers["Content-Length"])
                body = json.loads(self.rfile.read(n))
                outer.bodies.append((dict(self.headers), body))
                text = body["messages"][-1]["content"]
                data = json.dumps({"content": [{"type": "text", "text": "Reply to: " + text}],
                                   "usage": {}}).encode()
                self.send_response(200)
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)
        self.httpd = HTTPServer(("127.0.0.1", 0), H)
        self.url = f"http://127.0.0.1:{self.httpd.server_address[1]}/v1/messages"
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()


def test_cloud_flow_requires_optin_preview_and_redacts(client, ctx, monkeypatch):
    fc = FakeCloud()
    monkeypatch.setenv("GNOSIS_CLOUD_URL", fc.url)
    body = {"text": "Draft a reply to sarah@example.com about Project Falcon, call 07700 900123"}
    assert client.post("/api/chat/cloud/preview", json=body).status_code == 403   # disabled
    client.put("/api/settings", json={"cloud": {"enabled": True, "redact_terms": ["Project Falcon"]},
                                      "profile": {"name": "Jacob Diameh"}})
    assert client.post("/api/chat/cloud/preview", json=body).status_code == 403   # no key
    client.put("/api/secrets/cloud-key", json={"key": "sk-ant-test-1234567890abcdef"})
    p = client.post("/api/chat/cloud/preview", json=body).get_json()
    shown = json.dumps(p["messages"]) + p["system"]
    assert "sarah@example.com" not in shown and "Falcon" not in shown and "7700" not in shown
    assert "Jacob Diameh" not in shown
    assert len(p["redactions"]) >= 3
    assert fc.bodies == []                                    # preview sends nothing
    sent = client.post("/api/chat/cloud/send", json={"payload_id": p["payload_id"]}).get_json()
    assert "sarah@example.com" in sent["content"] and "Project Falcon" in sent["content"]   # restored
    headers, wire = fc.bodies[0]
    assert "sarah@example.com" not in json.dumps(wire) and wire["model"] == "claude-sonnet-5-5"
    assert {k.lower(): v for k, v in headers.items()}.get("x-api-key") == "sk-ant-test-1234567890abcdef"
    # replay of same payload id is refused
    assert client.post("/api/chat/cloud/send", json={"payload_id": p["payload_id"]}).status_code == 404
    log = client.get("/api/privacy/log").get_json()["items"]
    assert log[0]["kind"] == "cloud_send" and "sarah" not in json.dumps(log)
    msgs = client.get(f"/api/conversations/{sent['conv_id']}").get_json()["messages_list"]
    assert msgs[-1]["meta"]["cloud"] is True


def test_models_pull_stream(client, mock):
    r = client.post("/api/models/pull", json={"model": "qwen2.5:7b"})
    lines = [json.loads(l) for l in r.get_data(as_text=True).splitlines() if l]
    assert lines[-1]["status"] == "success" and "qwen2.5:7b" in mock.models


def test_insights_and_wipe(client, ctx):
    ctx.memory.add_note("Thesis chapter on privacy-preserving assistants and thesis writing.")
    ctx.memory.add_note("More thesis writing planned for the weekend.")
    ins = client.get("/api/insights").get_json()
    assert ins["memories"]["note"] == 2 and any(t["term"] == "thesis" for t in ins["topics"])
    assert client.post("/api/insights/reflect").get_json()["text"]
    assert client.post("/api/data/wipe", json={}).status_code == 400
    client.post("/api/data/wipe", json={"confirm": "DELETE"})
    assert client.get("/api/status").get_json()["memories"]["total"] == 0
