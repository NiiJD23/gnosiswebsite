import json


def stream(client, **payload):
    r = client.post("/api/chat", json=payload)
    assert r.status_code == 200
    return [json.loads(l) for l in r.get_data(as_text=True).splitlines() if l.strip()]


def text_of(events):
    return "".join(e["t"] for e in events if e["type"] == "token")


def test_basic_chat_creates_titled_conversation(client, ctx):
    ev = stream(client, text="Plan my week around the PhD deadline")
    assert ev[0]["type"] == "start" and ev[-1]["type"] == "done"
    assert "mock model" in text_of(ev)
    convs = client.get("/api/conversations").get_json()
    assert len(convs) == 1 and convs[0]["messages"] == 2
    assert convs[0]["title"] == "Planning Next Steps"      # LLM title replaced heuristic


def test_memory_is_used_and_cited(client, ctx):
    ctx.memory.add_note("My manager at AMIC is Dr Patricia Lowe.", title="Work")
    ev = stream(client, text="Who is my manager at AMIC?")
    src = next(e for e in ev if e["type"] == "sources")["sources"]
    assert src and src[0]["title"] == "Work"
    assert "Patricia Lowe" in text_of(ev) and "[M1]" in text_of(ev)
    done = ev[-1]
    assert done["sources"][0]["n"] == 1


def test_remember_command_saves_memory_then_recalls_in_new_chat(client, ctx):
    ev = stream(client, text="Remember that my daughter's birthday is 3 June")
    saved = next(e for e in ev if e["type"] == "saved")
    assert saved["memory"]["created"]
    mems = client.get("/api/memories").get_json()["items"]
    assert mems[0]["origin"] == "chat" and "3 June" in client.get(f"/api/memories/{mems[0]['id']}").get_json()["content"]
    ev2 = stream(client, text="When is my daughter's birthday?")
    assert "3 June" in text_of(ev2)


def test_history_is_sent_for_follow_ups(client, ctx, mock):
    ev = stream(client, text="My favourite colour is purple, just so you know")
    cid = ev[0]["conv_id"]
    stream(client, conv_id=cid, text="and why might that matter?")
    last = [p for path, p in mock.requests if path == "/api/chat" and not p.get("format")][-1]
    roles = [m["role"] for m in last["messages"]]
    assert roles[0] == "system" and roles.count("user") == 2 and "assistant" in roles
    assert last["options"]["num_ctx"] == 8192


def test_huge_paste_is_trimmed_not_rejected(client, ctx):
    ev = stream(client, text="Summarise this: " + ("lorem ipsum dolor " * 6000))
    assert ev[-1]["type"] == "done"          # mock would 400 if num_ctx were exceeded


def test_long_history_is_truncated_to_fit(client, ctx):
    client.put("/api/settings", json={"models": {"num_ctx": 2048}})
    cid = None
    for i in range(14):
        ev = stream(client, conv_id=cid, text=f"Message {i}: " + "words " * 120)
        cid = ev[0]["conv_id"]
        assert ev[-1]["type"] == "done", ev[-1]


def test_regenerate_replaces_last_answer(client, ctx):
    ev = stream(client, text="Say something about tea")
    cid = ev[0]["conv_id"]
    stream(client, conv_id=cid, regenerate=True)
    msgs = client.get(f"/api/conversations/{cid}").get_json()["messages_list"]
    assert [m["role"] for m in msgs] == ["user", "assistant"]


def test_model_missing_gives_actionable_error(client, ctx, mock):
    mock.models.remove("llama3.1:8b")
    ev = stream(client, text="hello there")
    err = ev[-1]
    assert err["type"] == "error" and err["code"] == "model_missing"
    assert err["action"] == {"type": "pull", "model": "llama3.1:8b"}
    # user message is kept so nothing is lost
    cid = ev[0]["conv_id"]
    assert client.get(f"/api/conversations/{cid}").get_json()["messages_list"][0]["role"] == "user"


def test_ollama_down_message(client, ctx, mock):
    ctx.settings.update({"ollama_host": "http://127.0.0.1:9"})
    ev = stream(client, text="hello there")
    assert ev[-1]["code"] == "ollama_down" and "Ollama" in ev[-1]["message"]
    st = client.get("/api/status").get_json()
    assert st["ollama"]["running"] is False


def test_suggestions_flow(client, ctx):
    stream(client, text="I work at AMIC in Belfast and my wife is called Sarah")
    sug = client.get("/api/suggestions").get_json()["items"]
    assert len(sug) == 1
    mem = client.post(f"/api/suggestions/{sug[0]['id']}/accept", json={}).get_json()
    assert mem["origin"] == "suggestion"
    assert client.get("/api/suggestions").get_json()["items"] == []


def test_conversation_management(client, ctx):
    a = stream(client, text="First topic about gardening and tomatoes")[0]["conv_id"]
    b = stream(client, text="Second topic about taxes and invoices")[0]["conv_id"]
    assert client.patch(f"/api/conversations/{a}", json={"title": "Garden"}).get_json()["title"] == "Garden"
    assert client.patch(f"/api/conversations/{b}", json={"pinned": True}).get_json()["pinned"]
    assert client.get("/api/conversations").get_json()[0]["id"] == b          # pinned first
    assert a in [c["id"] for c in client.get("/api/conversations?q=tomatoes").get_json()]
    client.post(f"/api/conversations/{a}/clear")
    assert client.get(f"/api/conversations/{a}").get_json()["messages_list"] == []
    assert client.delete(f"/api/conversations/{b}").status_code == 200
    assert client.delete("/api/conversations", json={}).status_code == 400
    assert client.delete("/api/conversations", json={"confirm": "DELETE"}).get_json()["deleted"] == 1


def test_past_chats_become_searchable_but_not_current_chat(client, ctx):
    a = stream(client, text="I am considering moving to Lisbon next spring for work")[0]["conv_id"]
    ev = stream(client, text="What was I considering about Lisbon?")      # new chat
    src = next(e for e in ev if e["type"] == "sources")["sources"]
    assert any(s["kind"] == "chat" for s in src)
    # same conversation: its own earlier message must not be retrieved as 'memory'
    ev = stream(client, conv_id=a, text="Remind me about Lisbon and spring plans")
    src = next(e for e in ev if e["type"] == "sources")["sources"]
    assert not any(s["conv_id"] == a for s in src)


def test_profile_and_advisory_reach_the_prompt(client, ctx, mock):
    client.put("/api/settings", json={"profile": {"name": "Jacob", "role": "PM"},
                                      "advisory": {"style": "Frame trade-offs as a PRINCE2 risk register",
                                                   "priorities": ["Family time"], "tone": "coach"}})
    stream(client, text="Should I take the new contract?")
    sysmsg = [p for path, p in mock.requests if path == "/api/chat" and p["messages"][0]["role"] == "system"][-1]["messages"][0]["content"]
    assert "Jacob" in sysmsg
    assert "PRINCE2" in sysmsg and "Family time" in sysmsg and "coach" in sysmsg.lower()


def test_pinned_memory_is_always_in_prompt(client, ctx, mock):
    ctx.memory.add_note("Never schedule meetings before 9am.", title="Rule", pinned=True)
    stream(client, text="What colour is the sky today?")
    sysmsg = [p for path, p in mock.requests if path == "/api/chat" and p["messages"][0]["role"] == "system"][-1]["messages"][0]["content"]
    assert "ALWAYS-KNOWN NOTES" in sysmsg and "before 9am" in sysmsg


def test_note_download_and_dismiss_suggestion(client, ctx):
    m = client.post("/api/memories", json={"content": "Download me please", "title": "Dl"}).get_json()
    r = client.get(f"/api/memories/{m['id']}/download")
    assert r.status_code == 200 and b"Download me please" in r.data and "attachment" in r.headers["Content-Disposition"]
    ctx.db.execute("INSERT INTO suggestions(text, created) VALUES ('x fact here ok', 1)")
    sid = client.get("/api/suggestions").get_json()["items"][0]["id"]
    assert client.post(f"/api/suggestions/{sid}/dismiss").status_code == 200
    assert client.get("/api/suggestions").get_json()["items"] == []


def test_failed_upload_can_be_reprocessed(client, ctx):
    import io
    r = client.post("/api/memories/upload", data={"files": (io.BytesIO(b"\x00\x01" * 400), "x.bin")},
                    content_type="multipart/form-data")
    mid = r.get_json()["items"][0]["id"]
    ctx.memory.wait_idle()
    assert client.get(f"/api/memories/{mid}").get_json()["status"] == "failed"
    assert client.post(f"/api/memories/{mid}/reprocess").status_code == 200
    ctx.memory.wait_idle()
    assert client.get(f"/api/memories/{mid}").get_json()["status"] == "failed"      # still unreadable, no crash
    assert client.get(f"/api/memories/{mid}/download").status_code == 200           # original still downloadable
