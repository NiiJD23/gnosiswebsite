from gnosis.memory.chunker import chunk_text
from gnosis.memory.learn import detect_capture, looks_personal
from gnosis.privacy.redact import Redactor
from gnosis.settings import Settings


def test_chunker_headers_and_overlap():
    para = "Sentence number one is here. " * 40
    text = "# Intro\n\n" + para + "\n\n[Page 2]\n\n" + para + "\n\n" + para
    chunks = chunk_text("My CV", text)
    assert len(chunks) >= 4
    assert chunks[0][0].startswith("My CV")
    assert any("Page 2" in h for h, _ in chunks)
    assert all(len(t) <= 1500 for _, t in chunks)


def test_chunker_hard_split_without_punctuation():
    chunks = chunk_text("t", "word " * 1000)
    assert len(chunks) > 2 and all(len(t) <= 1500 for _, t in chunks)


def test_chunker_empty():
    assert chunk_text("x", "   ") == []


def test_capture_patterns():
    assert detect_capture("Remember that my sister's name is Anna") == "my sister's name is Anna"
    assert detect_capture("please save this to memory: I prefer morning meetings") == "I prefer morning meetings"
    assert detect_capture("Can you remember that the PhD deadline is 5 March?") is None  # question
    assert detect_capture("My passport expires in May, remember that.") == "My passport expires in May"
    assert detect_capture("What do you remember about me?") is None
    assert detect_capture("hello there") is None


def test_looks_personal():
    assert looks_personal("I work at AMIC as a project manager in Belfast")
    assert not looks_personal("What is the capital of France?")
    assert not looks_personal("ok")


def test_redaction_round_trip():
    r = Redactor(terms=["Project Falcon"], name="Jacob Diameh")
    src = ("Email jacob@example.com or call +44 7700 900123. Card 4111 1111 1111 1111, "
           "postcode BT7 1NN, NI AB123456C. Jacob Diameh runs Project Falcon from 10.0.0.12. "
           "See https://example.com/a?b=1")
    out = r.redact(src)
    for secret in ("jacob@example.com", "7700", "4111", "BT7 1NN", "AB123456C", "Diameh",
                   "Falcon", "10.0.0.12", "example.com/a"):
        assert secret not in out, secret
    assert r.restore(out) == src
    # model echoing placeholder in different case still restores
    ph = next(iter(r.mapping))
    assert r.restore(ph.lower()) == r.mapping[ph]


def test_redaction_does_not_touch_ordinary_numbers():
    r = Redactor()
    s = "We have 12 people, 2026 budget 150000 and version 1.2.3"
    assert r.redact(s) == s


def test_settings_validation(ctx):
    s = Settings(ctx.db)
    out = s.update({"models": {"num_ctx": 99, "temperature": 9}, "appearance": {"theme": "neon"}})
    assert out["models"]["num_ctx"] == 2048 and out["models"]["temperature"] == 1.5
    assert out["appearance"]["theme"] == "system"
    s.update({"ollama_host": "localhost:11434"})
    assert s.ollama_host() == "http://localhost:11434"
    import pytest
    with pytest.raises(ValueError):
        s.update({"ollama_host": "ftp://x"})


def test_email_with_apostrophe_is_fully_hidden():
    r = Redactor()
    out = r.redact("write to sarah.o'neil@example.com today")
    assert "neil" not in out and "sarah" not in out and "[EMAIL_1]" in out
