import io
import json

import docx


def embed_all(ctx):
    while ctx.indexer.run_once():
        pass


def test_note_is_searchable_immediately_without_ollama_embeddings(ctx):
    ctx.memory.add_note("My sister Anna lives in Dublin and works as a nurse.", title="Family")
    hits = ctx.retriever.search("where does my sister live", use_vectors=False)
    assert hits and "Anna" in hits[0]["text"]


def test_hybrid_search_after_embedding(ctx):
    ctx.memory.add_note("The PhD supervisor is Professor Hughes at Queen's University.")
    ctx.memory.add_note("Grocery list: eggs, milk, bread and coffee beans.")
    embed_all(ctx)
    assert ctx.indexer.progress()["pending"] == 0
    hits = ctx.retriever.search("who is my PhD supervisor")
    assert ctx.retriever.last_mode == "hybrid"
    assert "Hughes" in hits[0]["text"]


def test_edit_rechunks_and_reembeds_only_changed(ctx):
    m, _ = ctx.memory.add_note("Original text about kayaking trips.")
    embed_all(ctx)
    ctx.memory.update(m["id"], title="Climbing", content="Updated text about climbing trips and ropes.")
    assert ctx.indexer.progress()["pending"] >= 1
    embed_all(ctx)
    assert not ctx.retriever.search("kayaking", use_vectors=False)
    assert ctx.retriever.search("climbing", use_vectors=False)


def test_delete_removes_chunks_and_file(ctx):
    m = ctx.memory.add_file(io.BytesIO(b"secret plan alpha bravo"), "plan.txt")
    ctx.memory.wait_idle()
    path = ctx.memory.file_path(m["id"])["path"]
    assert path.exists()
    assert ctx.retriever.search("alpha bravo", use_vectors=False)
    ctx.memory.delete(m["id"])
    assert not path.exists()
    assert not ctx.retriever.search("alpha bravo", use_vectors=False)
    assert ctx.db.scalar("SELECT COUNT(*) FROM chunks") == 0


def test_dedupe_notes(ctx):
    a, created_a = ctx.memory.add_note("I prefer tea over coffee.")
    b, created_b = ctx.memory.add_note("i prefer tea over coffee")
    assert created_a and not created_b and a["id"] == b["id"]


def test_ingest_docx_txt_json_html_and_unknown(ctx, tmp_path):
    d = docx.Document()
    d.add_heading("Cover letter", 1)
    d.add_paragraph("I am applying for the programme manager role at Invest NI.")
    p = tmp_path / "cl.docx"
    d.save(p)
    uploads = {
        "cl.docx": p.read_bytes(),
        "notes.md": b"# Goals\nFinish thesis chapter three by December.",
        "data.json": json.dumps({"award": "Best Paper 2025"}).encode(),
        "page.html": b"<html><title>Talk</title><body><script>x()</script><p>Keynote in Lisbon</p></body></html>",
        "blob.bin": b"\x00\x01\x02\x03" * 100,
    }
    ids = {}
    for name, data in uploads.items():
        ids[name] = ctx.memory.add_file(io.BytesIO(data), name)["id"]
    assert ctx.memory.wait_idle()
    st = {n: ctx.memory.get(i, full=True) for n, i in ids.items()}
    assert st["cl.docx"]["status"] == "ready" and "Invest NI" in st["cl.docx"]["content"]
    assert "Finish thesis" in st["notes.md"]["content"]
    assert "Best Paper" in st["data.json"]["content"]
    assert "Keynote in Lisbon" in st["page.html"]["content"] and "x()" not in st["page.html"]["content"]
    assert st["blob.bin"]["status"] == "failed" and st["blob.bin"]["downloadable"]
    assert ctx.retriever.search("Invest NI role", use_vectors=False)


def test_pdf_ingest(ctx, tmp_path):
    import weasyprint
    pdf = weasyprint.HTML(string="<h1>Certificate</h1><p>Awarded to Jacob for PRINCE2 Practitioner.</p>").write_pdf()
    m = ctx.memory.add_file(io.BytesIO(pdf), "cert.pdf")
    ctx.memory.wait_idle()
    got = ctx.memory.get(m["id"], full=True)
    assert got["status"] == "ready" and "PRINCE2" in got["content"]


def test_upload_path_is_sanitised(ctx):
    m = ctx.memory.add_file(io.BytesIO(b"hello"), "../../etc/passwd")
    ctx.memory.wait_idle()
    assert m["filename"] == "passwd"
    assert ".." not in ctx.db.scalar("SELECT stored_as FROM memories WHERE id=?", (m["id"],))


def test_link_rejects_private_hosts_and_bad_urls(ctx):
    import pytest
    with pytest.raises(ValueError):
        ctx.memory.add_link("javascript:alert(1)")
    l = ctx.memory.add_link("http://127.0.0.1:9/x", fetch=False)
    with pytest.raises(ValueError):
        ctx.memory._public_host("127.0.0.1")
    assert l["kind"] == "link"


def test_legacy_ollama_embeddings_endpoint_fallback(tmp_path):
    import os
    from gnosis.context import Context
    from mock_ollama import MockOllama
    m = MockOllama(legacy_embed=True).start()
    os.environ["GNOSIS_OLLAMA_HOST"] = m.url
    c = Context(tmp_path / "h", background=False)
    try:
        c.memory.add_note("Legacy servers still get semantic recall via the old endpoint.")
        while c.indexer.run_once():
            pass
        assert c.indexer.progress()["pending"] == 0
    finally:
        c.close(); m.stop()


def test_restore_closes_other_thread_connections(ctx):
    import threading
    ctx.memory.add_note("thread note")
    done = threading.Event()
    def other():
        ctx.db.query("SELECT 1")
        done.set()
    t = threading.Thread(target=other); t.start(); t.join()
    assert len(ctx.db._all) >= 2
    ctx.db.release()
    assert ctx.db._all == []
    ctx.db.reopen_all()
    assert ctx.db.scalar("SELECT COUNT(*) FROM memories") == 1
