"""Start Gnosis against a mock Ollama on a fixed port for browser tests/screenshots."""
import os, sys, tempfile, threading
from pathlib import Path
os.environ["GNOSIS_NO_KEYRING"] = "1"
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from werkzeug.serving import make_server
from gnosis.app import create_app
from gnosis.context import Context
from mock_ollama import MockOllama


def start(port=5199, seed=True, models=None, reply_delay=0.0):
    mock = MockOllama(**({"models": models} if models is not None else {}), reply_delay=reply_delay).start()
    os.environ["GNOSIS_OLLAMA_HOST"] = mock.url
    home = tempfile.mkdtemp(prefix="gnosis-ui-")
    ctx = Context(home, background=True)
    if seed:
        ctx.settings.update({"profile": {"name": "Jacob Diameh", "role": "Project manager & coach", "location": "Belfast"}})
        ctx.memory.add_note("My PhD supervisor is Professor Hughes at Queen's University Belfast. We meet every second Thursday.", title="PhD supervisor", pinned=False)
        ctx.memory.add_note("Midpoint Career and Business Coaching is my coaching practice. I prefer evening sessions on Tuesdays and Thursdays.", title="Coaching practice")
        ctx.memory.add_link("https://www.linkedin.com/in/example", title="LinkedIn", note="My professional profile")
        c = ctx.convs.create("Planning the PhD literature review")
        ctx.convs.add_message(c["id"], "user", "Help me structure chapter two of my thesis")
        ctx.convs.add_message(c["id"], "assistant", "Start with a **thematic** structure:\n\n1. Privacy-preserving assistants\n2. Local LLM deployment\n3. Personal knowledge management\n\nThen close with a gap analysis [M1].")
        c2 = ctx.convs.create("Tuesday coaching prep")
        ctx.convs.add_message(c2["id"], "user", "Prepare questions for a career transition client")
        c3 = ctx.convs.create("Weekend plans")
        ctx.convs.pin(c3["id"], True)
        ctx.db.execute("UPDATE conversations SET updated=updated-200000 WHERE id=?", (c2["id"],))
        ctx.db.execute("INSERT INTO suggestions(text, conv_id, created) VALUES (?,?,strftime('%s','now'))", ("Jacob is planning a research visit to Dublin in November.", c["id"]))
    app = create_app(ctx, port=port)
    srv = make_server("127.0.0.1", port, app, threaded=True)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return ctx, mock, srv, f"http://127.0.0.1:{port}"
