import os
import sys
from pathlib import Path

os.environ["GNOSIS_NO_KEYRING"] = "1"
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import pytest

from gnosis.app import create_app
from gnosis.context import Context
from mock_ollama import MockOllama


@pytest.fixture()
def mock():
    m = MockOllama().start()
    yield m
    m.stop()


@pytest.fixture()
def ctx(tmp_path, mock):
    os.environ["GNOSIS_OLLAMA_HOST"] = mock.url
    c = Context(tmp_path / "home", background=False)   # synchronous: deterministic tests
    yield c
    c.close()


@pytest.fixture()
def client(ctx):
    app = create_app(ctx, port=5177)
    app.testing = True
    cl = app.test_client()
    cl.environ_base["HTTP_HOST"] = "127.0.0.1:5177"
    cl.token = app.config["GNOSIS_TOKEN"]
    cl.environ_base["HTTP_X_GNOSIS_TOKEN"] = cl.token
    return cl
