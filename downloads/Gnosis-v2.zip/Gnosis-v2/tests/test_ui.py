"""Real-browser end-to-end tests (Playwright + Chromium) against a mock Ollama."""
import json
import re
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer

import pytest

pw = pytest.importorskip("playwright.sync_api")
import ui_harness  # noqa: E402

PORTS = iter(range(5210, 5260))


@pytest.fixture(scope="module")
def browser():
    with pw.sync_playwright() as p:
        b = p.chromium.launch()
        yield b
        b.close()


@pytest.fixture()
def app(browser, tmp_path, monkeypatch):
    ctx, mock, srv, url = ui_harness.start(port=next(PORTS))
    page = browser.new_context(viewport={"width": 1280, "height": 820}, accept_downloads=True, bypass_csp=True).new_page()
    errors = []
    page.on("pageerror", lambda e: errors.append(str(e)))
    page.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)
    page.goto(url)
    page.wait_for_selector(".hero h1")
    yield type("A", (), dict(page=page, ctx=ctx, mock=mock, url=url, errors=errors, tmp=tmp_path))
    srv.shutdown()
    ctx.close()
    mock.stop()
    assert not errors, errors


def send(page, text):
    page.fill("textarea", text)
    page.keyboard.press("Enter")


def test_greeting_uses_profile_name(app):
    assert "Jacob" in app.page.inner_text(".hero h1")


def test_chat_stream_sources_and_cite_opens_memory(app):
    p = app.page
    send(p, "Who is my PhD supervisor?")
    p.wait_for_selector(".msg.assistant .src")
    assert "Hughes" in p.inner_text(".msg.assistant .prose")
    p.click(".msg.assistant .cite")
    p.wait_for_selector("dialog[open]")
    assert p.input_value("dialog input[type=text]") == "PhD supervisor"
    p.keyboard.press("Escape")


def test_remember_in_chat_shows_saved_badge_and_memory_page_lists_it(app):
    p = app.page
    send(p, "Remember that my passport expires in May 2028")
    p.wait_for_selector(".badge.saved", timeout=10000)
    p.click(".nav button:has-text('Memory')")
    p.wait_for_selector(".mem:has-text('passport')")


def test_new_note_edit_download_delete(app):
    p = app.page
    p.click(".nav button:has-text('Memory')")
    p.click("button:has-text('Add memory')")
    p.fill("dialog textarea", "Favourite coffee is a flat white.")
    p.click("dialog button:has-text('Save to memory')")
    p.wait_for_selector(".mem:has-text('flat white')")
    p.click(".mem:has-text('flat white')")
    p.fill("dialog textarea", "Favourite coffee is an oat flat white.")
    p.click("dialog button:has-text('Save changes')")
    p.keyboard.press("Escape")
    p.wait_for_selector(".mem:has-text('oat flat white')")
    with p.expect_download() as dl:
        p.click(".mem:has-text('oat flat white') button[aria-label^='Download']")
    assert dl.value.suggested_filename.endswith(".md")
    p.click(".mem:has-text('oat flat white') button[aria-label^='Delete']")
    p.click("dialog button:has-text('Delete')")
    p.wait_for_selector(".mem:has-text('oat flat white')", state="detached")


def test_upload_files_of_many_types(app):
    import docx
    p = app.page
    d = docx.Document(); d.add_paragraph("Certificate of completion for Leadership Programme 2025."); f1 = app.tmp / "cert.docx"; d.save(f1)
    f2 = app.tmp / "notes.md"; f2.write_text("# Research\nInterview schedule for November.")
    f3 = app.tmp / "mystery.bin"; f3.write_bytes(b"\x00\x01" * 500)
    p.click(".nav button:has-text('Memory')")
    p.set_input_files(".page input[type=file]", [str(f1), str(f2), str(f3)])
    p.wait_for_selector(".mem:has-text('Leadership Programme')", timeout=10000)
    p.wait_for_selector(".mem:has-text('Interview schedule')")
    p.wait_for_selector(".mem .status.failed")        # unreadable binary is flagged, not silently dropped
    p.fill("input[aria-label='Search memory']", "leadership")
    p.wait_for_function("document.querySelectorAll('.mem').length === 1")
    assert "Leadership" in p.inner_text(".mem")


def test_sidebar_history_rename_pin_clear_delete_hide(app):
    p = app.page
    item = p.locator(".chat-item", has_text="Tuesday coaching prep")
    item.hover(); item.locator(".more").click()
    p.click(".menu button:has-text('Rename')")
    p.fill("dialog input", "Coaching prep renamed"); p.click("dialog button:has-text('Save')")
    p.wait_for_selector(".chat-item:has-text('Coaching prep renamed')")
    item = p.locator(".chat-item", has_text="Coaching prep renamed")
    item.hover(); item.locator(".more").click()
    p.click(".menu button:has-text('Delete')")
    p.click("dialog button:has-text('Delete chat')")
    p.wait_for_selector(".chat-item:has-text('Coaching prep renamed')", state="detached")
    p.click(".chat-item:has-text('PhD literature')")
    p.wait_for_selector(".msg.assistant")
    p.click(".topbar button[aria-label='Chat options']"); p.click(".menu button:has-text('Clear messages')")
    p.click("dialog button:has-text('Clear messages')")
    p.wait_for_selector(".hero h1")
    p.click(".recents-head button")
    assert not p.locator(".recents").is_visible()
    p.click(".recents-head button")
    assert p.locator(".recents").is_visible()


def test_message_text_is_left_aligned_and_markdown_safe(app):
    p = app.page
    app.mock.requests.clear()
    send(p, "<img src=x onerror=alert(1)> **bold**")
    p.wait_for_selector(".msg.assistant")
    assert p.locator(".msg.user .bubble").evaluate("e => getComputedStyle(e).textAlign") in ("left", "start")
    assert p.locator("img[src=x]").count() == 0


def test_ollama_down_banner_and_model_install_flow(app):
    p = app.page
    app.mock.models.remove("llama3.1:8b")
    p.click(".nav button:has-text('Settings')"); p.click(".nav button:has-text('Chat')")
    app.page.evaluate("window.__gnosis && 0")
    p.reload(); p.wait_for_selector(".hero h1")
    p.wait_for_selector(".banner:has-text('chat model')")
    p.click(".banner button:has-text('Install')")
    p.wait_for_function("!document.querySelector('.banner') || !document.querySelector('.banner').innerText.includes('Installing')", timeout=10000)
    assert "llama3.1:8b" in app.mock.models
    send(p, "hello there friend")
    p.wait_for_selector(".msg.assistant .prose:not(:empty)")
    assert not p.locator(".err-card").count()


def test_error_card_when_ollama_unreachable_then_retry(app):
    p = app.page
    app.ctx.settings.update({"ollama_host": "http://127.0.0.1:9"})
    send(p, "are you there?")
    p.wait_for_selector(".err-card:has-text('Ollama')")
    app.ctx.settings.update({"ollama_host": app.mock.url})
    p.click(".err-card button:has-text('Try again')")
    p.wait_for_selector(".msg.assistant .prose:has-text('mock model')")
    assert p.locator(".msg.user").count() == 1       # retry does not duplicate the question


def test_settings_profile_theme_and_persistence(app):
    p = app.page
    p.click(".nav button:has-text('Settings')")
    p.fill("input[placeholder^='How should']", "Jay")
    p.click("button:has-text('Save changes')")
    p.click(".settings-nav button:has-text('Appearance')"); p.click(".theme-card:has-text('Dark')")
    p.wait_for_function("document.documentElement.getAttribute('data-theme') === 'dark'")
    p.wait_for_function("document.querySelector('.theme-card[aria-pressed=true]').innerText.includes('Dark')")
    p.reload(); p.wait_for_selector(".hero h1")
    assert "Jay" in p.inner_text(".hero h1")
    assert p.evaluate("document.documentElement.getAttribute('data-theme')") == "dark"


def test_cloud_flow_in_browser(app, monkeypatch):
    seen = []
    class H(BaseHTTPRequestHandler):
        def log_message(self, *a): pass
        def do_POST(self):
            body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
            seen.append(body)
            data = json.dumps({"content": [{"type": "text", "text": "Cloud says hi to [NAME_1]"}]}).encode()
            self.send_response(200); self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data)
    srv = HTTPServer(("127.0.0.1", 0), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
    monkeypatch.setenv("GNOSIS_CLOUD_URL", f"http://127.0.0.1:{srv.server_address[1]}/v1/messages")
    p = app.page
    p.click(".nav button:has-text('Settings')"); p.click(".settings-nav button:has-text('Cloud')")
    p.click(".toggle-row:has-text('Allow cloud answers') .switch")
    p.fill("input[type=password]", "sk-ant-browser-test-key-123456")
    p.click("button:has-text('Save key')")
    p.wait_for_selector("input[placeholder^='Saved']")
    p.click("button:has-text('Save changes')")
    p.click(".nav button:has-text('Chat')")
    p.click(".seg button:has-text('Cloud')")
    send(p, "Email jacob.diameh@gmail.com about the plan")
    p.wait_for_selector("dialog[open] .notice")
    assert "jacob.diameh@gmail.com" not in p.inner_text("dialog")
    assert seen == []
    p.click("dialog button:has-text('Send to cloud')")
    p.wait_for_selector(".badge.cloud")
    assert "Cloud says hi to Jacob" in p.inner_text(".msg.assistant .prose")     # placeholder restored locally
    assert "jacob.diameh@gmail.com" not in json.dumps(seen)
    srv.shutdown()


def test_backup_export_download(app):
    p = app.page
    p.click(".nav button:has-text('Settings')"); p.click(".settings-nav button:has-text('Data')")
    p.fill("input[placeholder='At least 8 characters']", "correct horse battery")
    p.fill("input[placeholder='Repeat password']", "correct horse battery")
    with p.expect_download() as dl:
        p.click("button:has-text('Export encrypted backup')")
    path = dl.value.path()
    assert open(path, "rb").read(8) == b"GNOSIS2\n"


def test_mobile_layout_has_no_horizontal_scroll(browser, app):
    ctx = browser.new_context(viewport={"width": 390, "height": 800})
    pg = ctx.new_page(); pg.goto(app.url); pg.wait_for_selector(".hero h1")
    assert pg.evaluate("document.documentElement.scrollWidth <= innerWidth + 1")
    pg.click("button[aria-label='Toggle sidebar']"); pg.wait_for_selector("#sidebar", state="visible")
    pg.click(".nav button:has-text('Memory')"); pg.wait_for_selector(".mem")
    assert pg.evaluate("document.documentElement.scrollWidth <= innerWidth + 1")
    ctx.close()
