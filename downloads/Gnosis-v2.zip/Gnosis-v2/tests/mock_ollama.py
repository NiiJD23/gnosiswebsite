"""A tiny fake Ollama for tests and UI screenshots (no GPU, no downloads)."""
from __future__ import annotations

import hashlib
import json
import re
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

DIM = 64


def embed_text(t: str):
    v = [0.0] * DIM
    for w in re.findall(r"\w+", t.lower()):
        if len(w) < 3:
            continue
        h = int(hashlib.md5(w.encode()).hexdigest(), 16)
        v[h % DIM] += 1.0
    n = sum(x * x for x in v) ** 0.5 or 1.0
    return [x / n for x in v]


class MockOllama:
    def __init__(self, models=("llama3.1:8b", "nomic-embed-text:latest"), reply_delay=0.0, legacy_embed=False):
        self.legacy_embed = legacy_embed
        self.models = list(models)
        self.requests = []
        self.reply_delay = reply_delay
        self.fail_chat = None
        outer = self

        class H(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.0"

            def log_message(self, *a):
                pass

            def _json(self, obj, code=200):
                data = json.dumps(obj).encode()
                self.send_response(code)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)

            def do_GET(self):
                if self.path == "/api/tags":
                    return self._json({"models": [{"name": m} for m in outer.models]})
                self._json({"error": "nope"}, 404)

            def do_POST(self):
                n = int(self.headers.get("Content-Length", 0))
                p = json.loads(self.rfile.read(n) or b"{}")
                outer.requests.append((self.path, p))
                if outer.legacy_embed and self.path == "/api/embed":
                    body = b"404 page not found"
                    self.send_response(404); self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body); return
                if self.path == "/api/embeddings":
                    return self._json({"embedding": embed_text(p["prompt"])})
                if self.path == "/api/embed":
                    if not any(m.split(":")[0] == p["model"].split(":")[0] for m in outer.models):
                        return self._json({"error": f"model \"{p['model']}\" not found, try pulling it first"}, 404)
                    return self._json({"embeddings": [embed_text(t) for t in p["input"]]})
                if self.path == "/api/pull":
                    self.send_response(200)
                    self.end_headers()
                    for line in ({"status": "pulling manifest"},
                                 {"status": "downloading", "total": 100, "completed": 50},
                                 {"status": "success"}):
                        self.wfile.write((json.dumps(line) + "\n").encode())
                    outer.models.append(p["model"])
                    return
                if self.path == "/api/chat":
                    return self._chat(p)
                self._json({"error": "unknown"}, 404)

            def _chat(self, p):
                if outer.fail_chat:
                    return self._json({"error": outer.fail_chat}, 500)
                if not any(m.split(":")[0] == p["model"].split(":")[0] for m in outer.models):
                    return self._json({"error": f"model \"{p['model']}\" not found, try pulling it first"}, 404)
                msgs = p["messages"]
                ctx = p.get("options", {}).get("num_ctx", 2048)
                if sum(len(m["content"]) for m in msgs) / 3.0 > ctx:
                    return self._json({"error": "the input length exceeds the context length"}, 400)
                last = msgs[-1]["content"]
                if p.get("format") == "json":
                    facts = []
                    if "i work" in last.lower() or "my wife" in last.lower():
                        m = re.search(r"Message:\n(.*)", last, re.S)
                        facts = [("The user said: " + (m.group(1) if m else last).strip())[:120]]
                    reply = json.dumps({"facts": facts})
                elif "title of 3 to 6 words" in last:
                    reply = "Planning Next Steps"
                elif "reflection" in last:
                    reply = "**Themes**\n- Work and family.\n**Open loops**\n- None.\n**Worth a thought**\n- Rest."
                else:
                    sysm = msgs[0]["content"] if msgs[0]["role"] == "system" else ""
                    m = re.search(r"^\[M1\] [^\n]*\n(.+)", sysm, re.M)
                    if m:
                        reply = f"From your memory: {m.group(1)[:140]} [M1]"
                    else:
                        reply = "Hello! I'm the mock model. You said: " + last[:80]
                if outer.reply_delay:
                    import time
                    time.sleep(outer.reply_delay)
                if not p.get("stream", True):
                    return self._json({"message": {"role": "assistant", "content": reply}, "done": True})
                self.send_response(200)
                self.end_headers()
                try:
                    words = re.findall(r"\S+\s*", reply)
                    for w in words:
                        self.wfile.write((json.dumps({"message": {"role": "assistant", "content": w}, "done": False}) + "\n").encode())
                    self.wfile.write((json.dumps({"done": True, "prompt_eval_count": 10, "eval_count": len(words)}) + "\n").encode())
                except (BrokenPipeError, ConnectionResetError):
                    pass

        self.httpd = ThreadingHTTPServer(("127.0.0.1", 0), H)
        self.url = f"http://127.0.0.1:{self.httpd.server_address[1]}"
        self._t = threading.Thread(target=self.httpd.serve_forever, daemon=True)

    def start(self):
        self._t.start()
        return self

    def stop(self):
        self.httpd.shutdown()
        self.httpd.server_close()
